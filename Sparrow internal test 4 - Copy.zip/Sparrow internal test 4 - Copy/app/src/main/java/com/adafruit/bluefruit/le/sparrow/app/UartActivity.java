package com.adafruit.bluefruit.le.sparrow.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothGattCharacteristic;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.SuperscriptSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.R;
import com.adafruit.bluefruit.le.sparrow.app.settings.ConnectedSettingsActivity;
import com.adafruit.bluefruit.le.sparrow.app.settings.MqttUartSettingsActivity;
import com.adafruit.bluefruit.le.sparrow.app.settings.PreferencesFragment;
import com.adafruit.bluefruit.le.sparrow.ble.BleManager;
import com.adafruit.bluefruit.le.sparrow.ble.BleUtils;
import com.adafruit.bluefruit.le.sparrow.mqtt.MqttManager;
import com.adafruit.bluefruit.le.sparrow.mqtt.MqttSettings;

import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static android.Manifest.permission.SEND_SMS;


public class UartActivity extends UartInterfaceActivity implements MqttManager.MqttManagerListener {
    // Log
    private final static String TAG = UartActivity.class.getSimpleName();

    // Configuration
    private final static boolean kUseColorsForData = true;
    public final static int kDefaultMaxPacketsToPaintAsText = 500;
    private final static int kInfoColor = Color.parseColor("#F21625");

    // Activity request codes (used for onActivityResult)
    private static final int kActivityRequestCode_ConnectedSettingsActivity = 0;
    private static final int kActivityRequestCode_MqttSettingsActivity = 1;

    // Constants
    private final static String kPreferences = "UartActivity_prefs";
    private final static String kPreferences_eol = "eol";
    private final static String kPreferences_eolCharactersId = "eolCharactersId";
    private final static String kPreferences_echo = "echo";
    private final static String kPreferences_asciiMode = "ascii";
    private final static String kPreferences_timestampDisplayMode = "timestampdisplaymode";

    // Colors
    private int mTxColor;
    private int mRxColor;

    // UI
    private EditText mBufferTextView;
    private ListView mBufferListView;
    private TimestampListAdapter mBufferListAdapter;
    private EditText mSendEditText;
    private MenuItem mMqttMenuItem;
    private Handler mMqttMenuItemAnimationHandler;
    private TextView mSentBytesTextView;
    private TextView mReceivedBytesTextView;

    // UI TextBuffer (refreshing the text buffer is managed with a timer because a lot of changes can arrive really fast and could stall the main thread)
    private Handler mUIRefreshTimerHandler = new Handler();
    private Runnable mUIRefreshTimerRunnable = new Runnable() {
        @Override
        public void run() {
            if (isUITimerRunning) {
                updateTextDataUI();
                // Log.d(TAG, "updateDataUI");
                mUIRefreshTimerHandler.postDelayed(this, 200);
            }
        }
    };
    private boolean isUITimerRunning = false;

    // Data
    private boolean mShowDataInHexFormat;
    private boolean mIsTimestampDisplayMode;
    private boolean mIsEchoEnabled;
    private boolean mIsEolEnabled;
    private int mEolCharactersId;

    private volatile SpannableStringBuilder mTextSpanBuffer;
    private volatile ArrayList<UartDataChunk> mDataBuffer;
    private volatile int mSentBytes;
    private volatile int mReceivedBytes;

    private DataFragment mRetainedDataFragment;

    private MqttManager mMqttManager;

    private int maxPacketsToPaintAsText;


    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    private Button startStopBtn, logBtn, secondActivitybtn, connectBtn, setAddressBtn, alertHistoryBtn, COInfoBtn;
    private ImageButton myDataImageBtn, alertHistoryImageBtn, learnAboutCOImageBtn, eventsImageBtn;

    private ListView logListView;
    private ArrayList<String> rxData = new ArrayList<String>();


    private EditText addressEditText;
    private Intent graphIntent, alertHistoryIntent, settingsIntent;
    private Intent connectIntent;

    boolean isBound = false;
    private int counts = 0;
    private int rxCounts = 0;
    private int lines;
    private int sparrowLogRate = 3333;  // = (# of seconds logging)/(# of lines outputted) approximate, may need to lower by ~10ms
    private double maxNumberOfLines = 40700.0;      //constant limited by sparrow memory, fluctuates between 40500 and 40800
    private long maxSparrowRecordingTime = (long)sparrowLogRate*(long)maxNumberOfLines;

    private boolean startSingleRead = false;    //turns true after not recieiving data for 5 seconds
    private long currentTimeMillis;
    private long timeOnLastReceive;     //time since last byte was recieved, used to determine how long it as been since sparrow log stopped outputting, used to start enabling single read
    private long timeOnDisconnect;      //used to keep track of when sparrow disconnected, used as the base for writing timestamps for logs read from sparrow
    private long timeSinceLastText;
    private long timeSinceLastAlert;

    private TextView units1TextView;
    private TextView units2TextView;
    private TextView units3TextView;
    private TextView units5TextView;
    private TextView TWATextView;

    private FrameLayout frameLayout1;
    private FrameLayout frameLayout2;
    private FrameLayout frameLayout3;
    private FrameLayout frameLayout4;
    private FrameLayout frameLayout5;
    private FrameLayout frameLayout6;

    private Drawable blueRectangle, greenRectangle, yellowRectangle, redRectangle, darkRedRectangle;

    private LocationManager locationManager;
    private LocationListener locationListener;
    private Geocoder geocoder;
    private List<Address> addresses;
    public static double latitude = 0.0;    //accessed by fetchData class
    public static double longitude = 0.0;   //accessed by fetchData class
    public static String currentCOppm, currentRH, currentTemp;       //accessed by getCurrentValues class
    public static boolean zeroCommand, restoreDefaultsCommand, enableUSBCommand, verySensitiveCommand;

    private Vibrator vibrator;
    private TextToSpeech mTTS;
    private boolean enableTTS = false;
    private boolean enableLogDownload = false;

    public static final String CHANNEL_1_ID = "channel1";
    public static final String CHANNEL_2_ID = "channel2";
    private NotificationManagerCompat notificationManager;

    private String eventsString;

    private String filepath = "SparrowFolder";
    private File myLogFile;
    private File myAlertFile;
    private File myEventFile;

    private Thread t;
    private Runnable runnable;


    public static String apiCallValue = ""; //modified by fetchData class
    public static String apiMajorPollutant = ""; //modifed by fetchData
    public static String apiCallLocation = ""; //modified by fetchData class
    public static String apiLevel = "";
    private String apiCallTime = "";

    private String currentDate = "0";
    private TextView messageTextView;

    //used in MySparrrow activity initialized on device connect

    public static String sensor1ID = "";
    public static String sensor2ID = "";
    public static String hwVersion = "";
    public static String fwVersion = "";

    //Settings strings for shared preferences
    private String userName;
    private String userGender;
    private String emergencyContactName1;
    private String emergencyContactName2;
    private String emergencyContactNumber1;
    private String emergencyContactNumber2;



    private int logRate;
    private String mainDisplaySetting;
    private String concentrationUnitCO;
    private String concentrationUnitO3;
    private boolean disconnectVibrateSetting;
    private boolean alertVibrateSetting;
    private boolean alertSpeakSettings;
    private boolean autoReconnectSetting;
    private boolean showTWA;
    private boolean TWAalert;
    private boolean TWAVoiceAlert;
    private boolean enableEmergencyContact1;
    private boolean enableEmergencyContact2;
    private boolean enableAlertsAlways; //even in "low" or "medium" level environments
    private String temperatureUnitSetting;
    private String sensitivityModeSetting;

    private int moderateCO = 15;
    private int unhealthyCO = 35;
    private int hazardousCO = 70;

    private int moderateO3 = 75;
    private int unhealthyO3 = 96;
    private int hazardousO3 = 400;

    private int moderateAQI = 50;
    private int unhealthyAQI = 150;
    private int hazardousAQI = 250;

    private double COppmTWA24Hours = 0.0;
    private double COppmTWA8Hours = 0.0;
    private double COppmTWA15Minutes = 0.0;

    public static String TWA15Minutes, TWA8Hours, TWA24Hours;

    private int COppmTWA24HoursCounter = 0;
    private int COppmTWA8HoursCounter = 0;
    private int COppmTWA15MinutesCounter = 0;

    private double COppmTWA24HoursAmount = 0;
    private double COppmTWA8HoursAmount = 0;
    private double COppmTWA15MinutesAmount = 0;

    private ArrayList<Double> COppmTWA24HoursList = new ArrayList<Double>();
    private ArrayList<Double> COppmTWA8HoursList = new ArrayList<Double>();
    private ArrayList<Double> COppmTWA15MinutesList = new ArrayList<Double>();



    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uart);

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setHomeButtonEnabled(false);
        getSupportActionBar().setSubtitle(" Home");
        getSupportActionBar().setTitle(" SPARROW");
        getSupportActionBar().setLogo(R.mipmap.sparrow_icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(0);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavViewBar);


        Menu bottomMenu = bottomNavigationView.getMenu();
        MenuItem bottomMenuItem = bottomMenu.getItem(0);
        bottomMenuItem.setChecked(true);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.homeBarBtn:
                        break;

                    case R.id.myDataBarBtn:
                        Intent intent2 = new Intent(UartActivity.this    , GraphActivity.class);
                        intent2.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent2);



                        UartActivity.this.overridePendingTransition(0,0);
                        break;

                    case R.id.myAlertBarBtn:
                        Intent intent3 = new Intent(UartActivity.this    , AlertHistoryActivity.class);
                        intent3.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent3);
                        UartActivity.this.overridePendingTransition(0,0);
                        break;

                    case R.id.learnMoreBarBtn:
                        Intent intent4 = new Intent(UartActivity.this    , LearnAboutCOActivity.class);
                        intent4.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent4);
                        UartActivity.this.overridePendingTransition(0,0);
                        break;
                }



                return false;
            }
        });


        if (!isTaskRoot()   //used to resume, rather than restart, when clicking app icon for galaxy 8
                && getIntent().hasCategory(Intent.CATEGORY_LAUNCHER)
                && getIntent().getAction() != null
                && getIntent().getAction().equals(Intent.ACTION_MAIN)) {

            finish();
            return;
        }
        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@



        //ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);


        mBleManager = BleManager.getInstance(this);
        restoreRetainedDataFragment();

        // Get default theme colors
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = getTheme();
        theme.resolveAttribute(R.attr.colorPrimaryDark, typedValue, true);
        mTxColor = typedValue.data;
        theme.resolveAttribute(R.attr.colorControlActivated, typedValue, true);
        mRxColor = typedValue.data;

        // UI
        mBufferListView = (ListView) findViewById(R.id.bufferListView);
        mBufferListAdapter = new TimestampListAdapter(this, R.layout.layout_uart_datachunkitem);
        mBufferListView.setAdapter(mBufferListAdapter);
        mBufferListView.setDivider(null);

        mBufferTextView = (EditText) findViewById(R.id.bufferTextView);
        if (mBufferTextView != null) {
            mBufferTextView.setKeyListener(null);     // make it not editable
        }

        mSendEditText = (EditText) findViewById(R.id.sendEditText);
        mSendEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    onClickSend(null);
                    return true;
                }

                return false;
            }
        });
        mSendEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View view, boolean hasFocus) {
                if (!hasFocus) {
                    // Dismiss keyboard when sendEditText loses focus
                    dismissKeyboard(view);
                }
            }
        });

        mSentBytesTextView = (TextView) findViewById(R.id.sentBytesTextView);
        mReceivedBytesTextView = (TextView) findViewById(R.id.receivedBytesTextView);


        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


        myLogFile = new File(getExternalFilesDir(filepath), "SparrowLog.txt");
        myAlertFile = new File(getExternalFilesDir(filepath),"SparrowAlert.txt");
        myEventFile = new File (getExternalFilesDir(filepath), "SparrowEvents.txt");




        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }



        try {       //check if file is empty
            FileInputStream fis = new FileInputStream(myLogFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            strLine = br.readLine();
            if(strLine == null){        //if empty, create header
                try {
                    FileOutputStream fos = new FileOutputStream(myLogFile, true);


                    String data = "Time, CO ppm, O3 ppb, °C, %RH, AQI \n";
                    fos.write(data.getBytes());
                    //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
                    fos.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


        //createNotificationChannels();

        notificationManager = NotificationManagerCompat.from(this);




        startStopBtn = (Button) findViewById(R.id.startStopBtn);
        startStopBtn.setTextColor(Color.rgb(255, 0, 0));
        startStopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String status = startStopBtn.getText().toString();
                if (status.equals("Start")) {

                    uartSendData("s", false);
                    startStopBtn.setText("Stop");
                    startStopBtn.setTextColor(Color.rgb(255, 0, 0));

                    connectBtn.setEnabled(false);
                    logBtn.setEnabled(true);
                } else if (status.equals("Stop")) {
                    startStopBtn.setText("Start");
                    startStopBtn.setTextColor(Color.rgb(0, 205, 50));

                    connectBtn.setEnabled(true);
                    logBtn.setEnabled(false);
                }
            }
        });

        logListView = (ListView) findViewById(R.id.bufferListView);
        //logListView.setVisibility(View.INVISIBLE);
        logBtn = (Button) findViewById(R.id.logBtn);
        //logBtn.setEnabled(false);
        logBtn.setTextColor(Color.rgb(255, 0, 0));
        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String status = logBtn.getText().toString();
                if (status.equals("Start Log")) {
                    logBtn.setText("Stop Log");
                    logBtn.setTextColor(Color.rgb(255, 0, 0));
                    //logListView.setVisibility(view.VISIBLE);
                } else if (status.equals("Stop Log")) {
                    logBtn.setText("Start Log");
                    logBtn.setTextColor(Color.rgb(0, 205, 50));
                    //logListView.setVisibility(view.INVISIBLE);
                }
            }
        });

        graphIntent = new Intent(getApplicationContext(), GraphActivity.class);
        secondActivitybtn = (Button) findViewById(R.id.graphBtn);
        secondActivitybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //graphIntent = new Intent(getApplicationContext(), GraphActivity.class);
                startActivity(graphIntent);
            }
        });

        connectIntent = new Intent(getApplicationContext(), MainActivity.class);
        connectBtn = (Button) findViewById(R.id.connectBtn);
        connectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //connectIntent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                //startActivityIfNeeded(connectIntent,0);

                //startActivity(connectIntent);


                SharedPreferences sharedPref = getSharedPreferences("connect status",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("status", "false");
                editor.apply();

                UartActivity.super.onBackPressed();

            }
        });




        addressEditText = (EditText) findViewById(R.id.addressEditText);
        setAddressBtn = (Button) findViewById(R.id.setAddressBtn);
        setAddressBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String address = addressEditText.getText().toString();
                SharedPreferences sharedPref = getSharedPreferences("macAddress", Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = sharedPref.edit();


                if (address.equals("")) {
                    Toast.makeText(getApplicationContext(), "Address removed", Toast.LENGTH_LONG).show();
                    editor.putString("address", "");
                    editor.apply();
                } else if (address.length() != 17) {
                    Toast.makeText(getApplicationContext(), "Invalid address", Toast.LENGTH_LONG).show();
                } else {
                    editor.putString("address", address);
                    editor.apply();
                    Toast.makeText(getApplicationContext(), "Address set", Toast.LENGTH_LONG).show();
                }
                //setAddressBtn.setText(sharedPref.getString("address","nothing"));

            }
        });





        alertHistoryIntent = new Intent(getApplicationContext(),AlertHistoryActivity.class);

        alertHistoryBtn = (Button) findViewById(R.id.alertHistoryBtn);
        alertHistoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(alertHistoryIntent);
            }
        });




        COInfoBtn = findViewById(R.id.COInfoBtn);
        COInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Intent intent4 = new Intent(UartActivity.this    , LearnAboutCOActivity.class);
                intent4.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent4);
                UartActivity.this.overridePendingTransition(0,0);

            }
        });



        eventsImageBtn = (ImageButton) findViewById(R.id.eventsImageBtn);
        eventsImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(UartActivity.this);
                builder.setTitle("Enter an event");

                // Set up the input
                final EditText input = new EditText(UartActivity.this);
                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                //input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        eventsString = input.getText().toString();
                        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss ");
                        String time = s.format(new Date());
                        writeToEventsFile(time +"~ " + eventsString+"~ "+currentCOppm+"~ "+currentTemp+"~ "+currentRH+"\n");
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        myDataImageBtn = (ImageButton) findViewById(R.id.myDataImageBtn);
        myDataImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(graphIntent);
            }
        });

        alertHistoryImageBtn = (ImageButton) findViewById(R.id.alertHistoryImageBtn);
        alertHistoryImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(alertHistoryIntent);
            }
        });

        learnAboutCOImageBtn = (ImageButton) findViewById(R.id.learnAboutImageBtn);
        learnAboutCOImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent learnAboutIntent = new Intent(getApplicationContext(),LearnAboutCOActivity.class);
                startActivity(learnAboutIntent);
            }
        });


        final TextView latTextView = (TextView) findViewById(R.id.latTextView);
        final TextView longTextView = (TextView) findViewById(R.id.longTextView);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);       //Possible cause for crash when running on BLU phone
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                latitude = location.getLatitude();
                longitude = location.getLongitude();




                String lati = latitude+"";
                String longi = longitude+"";

                if (lati.length()>=9){
                    lati = lati.substring(0,8);
                }

                if (longi.length() >= 9){
                    longi = longi.substring(0, 8);
                }


                latTextView.setText("Lat: "+lati);
                longTextView.setText("Long: "+longi);

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);

            }
        };

        configure_location();





        /*if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates("gps", 5000, 0, locationListener);*/



        geocoder = new Geocoder(this, Locale.getDefault());







        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


        // Read shared preferences
        maxPacketsToPaintAsText = PreferencesFragment.getUartTextMaxPackets(this);
        //Log.d(TAG, "maxPacketsToPaintAsText: "+maxPacketsToPaintAsText);

        // Read local preferences
        SharedPreferences preferences = getSharedPreferences(kPreferences, MODE_PRIVATE);
        //mShowDataInHexFormat = !preferences.getBoolean(kPreferences_asciiMode, true);
        mShowDataInHexFormat = true;        //force hex mode
        //final boolean isTimestampDisplayMode = preferences.getBoolean(kPreferences_timestampDisplayMode, false);
        final boolean isTimestampDisplayMode = true;        //force timestamp mode
        setDisplayFormatToTimestamp(isTimestampDisplayMode);
        mIsEchoEnabled = preferences.getBoolean(kPreferences_echo, true);
        mIsEolEnabled = preferences.getBoolean(kPreferences_eol, true);
        mEolCharactersId = preferences.getInt(kPreferences_eolCharactersId, 0);
        invalidateOptionsMenu();        // udpate options menu with current values

        // Continue
        onServicesDiscovered();

        // Mqtt init
        mMqttManager = MqttManager.getInstance(this);
        if (MqttSettings.getInstance(this).isConnected()) {
            mMqttManager.connectFromSavedSettings(this);
        }





        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);




        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS){
                    int result = mTTS.setLanguage(Locale.US);

                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("TTS", "Language not supported");
                    }
                    else{
                        enableTTS = true;
                    }
                }
                else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });






        final TextView a1TextView = (TextView) findViewById(R.id.a1TextView);
        final TextView cxTextView = (TextView) findViewById(R.id.cxTextView);
        final TextView txTextView = (TextView) findViewById(R.id.txTextView);
        final TextView hxTextView = (TextView) findViewById(R.id.hxTextView);
        final TextView pxTextView = (TextView) findViewById(R.id.pxTextView);
        final TextView vbTextView = (TextView) findViewById(R.id.vbTextView);

        TWATextView = findViewById(R.id.TWATextView);

        final Drawable blueCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.bluecircle);
        //final Drawable greenCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.greencircle);
        //final Drawable greenCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.bluegradientcircle);
        final Drawable greenCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.greengradientcircle);
        final Drawable yellowCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.yellowcircle);
        final Drawable redCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.redcircle);
        final Drawable darkRedCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.darkredcircle);

        final Drawable biggreenCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.biggreencircle);
        //final Drawable biggreenCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.biggreengradientcircle);
        final Drawable bigyellowCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.bigyellowcircle);
        final Drawable bigredCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.bigredcircle);
        final Drawable bigdarkRedCircle = ContextCompat.getDrawable(getApplicationContext(),R.drawable.bigdarkredcircle);

        blueRectangle = ContextCompat.getDrawable(getApplicationContext(), R.drawable.bluerectangle);
        greenRectangle = ContextCompat.getDrawable(getApplicationContext(), R.drawable.greenrectangle);
        yellowRectangle = ContextCompat.getDrawable(getApplicationContext(), R.drawable.yellowrectangle);
        redRectangle = ContextCompat.getDrawable(getApplicationContext(), R.drawable.redrectangle);
        darkRedRectangle = ContextCompat.getDrawable(getApplicationContext(), R.drawable.darkredrectangle);


        final Drawable greenCircle2 = ContextCompat.getDrawable(getApplicationContext(),R.drawable.greengradientcircle);

        frameLayout1 = (FrameLayout) findViewById(R.id.frameLayout1);
        final TextView concentration1TextView = (TextView) findViewById(R.id.concentrationTextView1);
        units1TextView = (TextView) findViewById(R.id.unitsTextView1);
        final TextView safetyLevel1TextView = (TextView) findViewById(R.id.safetyLevelTextView1);

        frameLayout2 = (FrameLayout) findViewById(R.id.frameLayout2);
        final TextView concentration2TextView = (TextView) findViewById(R.id.concentrationTextView2);
        units2TextView = (TextView) findViewById(R.id.unitsTextView2);
        final TextView safetyLevel2TextView = (TextView) findViewById(R.id.safetyLevelTextView2);

        frameLayout3 = (FrameLayout) findViewById(R.id.frameLayout3);
        final TextView concentration3TextView = (TextView) findViewById(R.id.concentrationTextView3);
        units3TextView = (TextView) findViewById(R.id.unitsTextView3);
        final TextView safetyLevel3TextView = (TextView) findViewById(R.id.safetyLevelTextView3);

        frameLayout5 = (FrameLayout) findViewById(R.id.frameLayout5);
        final TextView concentration5TextView = (TextView) findViewById(R.id.concentrationTextView5);
        units3TextView = (TextView) findViewById(R.id.unitsTextView5);
        final TextView safetyLevel5TextView = (TextView) findViewById(R.id.safetyLevelTextView5);

        frameLayout6 = (FrameLayout) findViewById(R.id.frameLayout6);
        final TextView concentration6TextView = (TextView) findViewById(R.id.concentrationTextView6);
        units3TextView = (TextView) findViewById(R.id.unitsTextView6);
        final TextView safetyLevel6TextView = (TextView) findViewById(R.id.safetyLevelTextView6);

         units5TextView= findViewById(R.id.unitsTextView5);



        frameLayout4 = (FrameLayout) findViewById(R.id.frameLayout4); //rectangular framelayout


        final ImageView chargingImageView = findViewById(R.id.chargingImageView);


        //dropped
        final TextView temperatureTextView = (TextView) findViewById(R.id.temperatureTextView);
        final TextView humidityTextView = (TextView) findViewById(R.id.humidityTextView);
        final TextView batteryTextView = (TextView) findViewById(R.id.batteryTextView);



        messageTextView= (TextView) findViewById(R.id.messageTextView);

        loadSettings();


        currentTimeMillis = System.currentTimeMillis();
        timeOnLastReceive = System.currentTimeMillis(); //called at onCreate because recordFromSparrowLog sends an "l" to start reading sparrow log
        timeSinceLastText = 0;      //0 to allow for immediate sending initially
        timeSinceLastAlert = 0;         //0 to allow for immediate logging to alert file
        //record from sparrow log
        uartSendData("e", false);   //obtain sparrow IDs
        //need delay here in order to allow eprom data to transfer properly before requesting log include some form of thread or runnable
        final Handler handler2 = new Handler();
        handler2.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 0.5s = 500ms

                SharedPreferences sharedPrefLog = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Boolean logDownloadOption = sharedPrefLog.getBoolean("log download",false);

                if(logDownloadOption == true){
                    recordFromSparrowLog();
                }
                else if (logDownloadOption == false ){       //defaults to not download, mainly for first startup, should be always on afterwards
                    startSingleRead = true;
                    uartSendData("L",false);    //still need to wipe log data to maintain order
                }



            }
        }, 500);
        //recordFromSparrowLog(); //also initializes and corrects timeonDisconnect


        final Handler handler = new Handler();        //Alternate method so that walking out of range does not break the app, forcing a restart
        runnable = new Runnable() {
            @Override
            public void run() {

                callAPI();  //enables airnow api even if not connected to sparrow

                //displayAPIValue();  //displays aqi even if sparrow is not connected

                currentTimeMillis = System.currentTimeMillis();
                long timeSinceLastRecieve = currentTimeMillis - timeOnLastReceive;

                if (timeSinceLastRecieve >= 5000 && startSingleRead == false){      //more than 5 secs have passed since last recieve, sparrow has finished transfering log
                    uartSendData("l",false);        //stop displaying log, shouldnt need this line
                    uartSendData("L",false);        //finished trasnfering log file so safe to delete
                    uartSendData("l",false);        //stop displaying log, shouldnt need this line
                    startSingleRead = true;
                    Toast.makeText(UartActivity.this, "Sparrow log downloaded", Toast.LENGTH_SHORT).show();
                    //messageTextView.setText("Location or Airnow.gov is currently unavailable");
                }
                if (startSingleRead){
                    uartSendData("s",false);        //request data from Sparrow



                }


                counts++;

                int listCount = rxData.size();
                //String logStatus = logBtn.getText().toString();
                if(listCount>=6 && startStopBtn.getText().toString().equals("Stop")){
                    String a1Value = rxData.get(listCount-6).toString();
                    String cxValue = rxData.get(listCount-5).toString();
                    String txValue = rxData.get(listCount-4).toString();
                    String hxValue = rxData.get(listCount-3).toString();
                    String pxValue = rxData.get(listCount-2).toString();
                    String vbValue = rxData.get(listCount-1).toString();

                    String a1Final ="";
                    String cxFinal ="";
                    String txFinal ="";
                    String hxFinal = "";
                    String pxFinal = "";
                    String vbFinal = "";

                    double concentrationCO =0;
                    String[] a1Arrray = a1Value.split("=");
                    if(a1Arrray[0].equals("A1")){
                        concentrationCO = Double.parseDouble(a1Arrray[1].trim());
                        concentrationCO = concentrationCO/1000; //convert to ppm from ppb

                        //calculateTWA15minutes(concentrationCO);

                        a1Final = concentrationCO + " "+concentrationUnitCO;
                        a1TextView.setText(a1Final);


                        int concCOppm = (int) concentrationCO;

                        calculateTWA15minutes(concentrationCO);
                        calculateTWA8Hours(concentrationCO);
                        calculateTWA24Hours(concentrationCO);
                        showTWA();
                        TWAalert();

                        //currentCOppm = concCOppm+"";
                        currentCOppm = concentrationCO+"";

                        if (mainDisplaySetting.equals("CO") || mainDisplaySetting.equals("")) {
                            concentration1TextView.setText(concCOppm + "");

                            if (concCOppm > hazardousCO) {
                                //cxTextView.setBackgroundColor(Color.rgb(160,5,5));

                                frameLayout1.setBackground(bigdarkRedCircle);
                                safetyLevel1TextView.setText("VERY HIGH");
                                frameLayout4.setBackground(darkRedRectangle);
                                messageTextView.setText("Your personal pollution level is VERY HIGH. \nEVACUATE IMMEDIATELY!");
                                createAlert(concCOppm);
                                vibrateHazardous();
                                sendTextAlert();
                            } else if (concCOppm > unhealthyCO) {
                                //cxTextView.setBackgroundColor(Color.rgb(255,5,5));

                                frameLayout1.setBackground(bigredCircle);
                                safetyLevel1TextView.setText("HIGH");
                                frameLayout4.setBackground(redRectangle);
                                messageTextView.setText("Your personal pollution level is HIGH. \nLEAVE AREA ASAP");
                                createAlert(concCOppm);
                                vibrateUnhealthy();
                            } else if (concCOppm > moderateCO) {
                                //cxTextView.setBackgroundColor(Color.rgb(255,255,0));

                                frameLayout1.setBackground(bigyellowCircle);
                                safetyLevel1TextView.setText("MEDIUM");
                                frameLayout4.setBackground(yellowRectangle);
                                if (enableAlertsAlways){
                                    createAlert(concCOppm);
                                }
                                displayAPIValue();
                            } else {
                                //cxTextView.setBackgroundColor(Color.rgb(0,255,0));

                                frameLayout1.setBackground(biggreenCircle);
                                safetyLevel1TextView.setText("LOW");
                                frameLayout4.setBackground(greenRectangle);
                                if (enableAlertsAlways){
                                    createAlert(concCOppm);
                                }
                                displayAPIValue();
                            }
                        }
                        else if (mainDisplaySetting.equals("AQI")){

                            //concentration2TextView.setText(concCOppm + "");

                            if (concCOppm > hazardousCO) {
                                //cxTextView.setBackgroundColor(Color.rgb(160,5,5));

                                //frameLayout2.setBackground(darkRedCircle);
                                safetyLevel2TextView.setText("VERY HIGH");
                                //frameLayout4.setBackground(darkRedRectangle);
                            } else if (concCOppm > unhealthyCO) {
                                //cxTextView.setBackgroundColor(Color.rgb(255,5,5));

                                //frameLayout2.setBackground(redCircle);
                                safetyLevel2TextView.setText("HIGH");
                                //frameLayout4.setBackground(redRectangle);
                            } else if (concCOppm > moderateCO) {
                                //cxTextView.setBackgroundColor(Color.rgb(255,255,0));

                                //frameLayout2.setBackground(yellowCircle);
                                safetyLevel2TextView.setText("MEDIUM");
                                //frameLayout4.setBackground(yellowRectangle);
                            } else {
                                //cxTextView.setBackgroundColor(Color.rgb(0,255,0));

                                //frameLayout2.setBackground(greenCircle);
                                safetyLevel2TextView.setText("LOW");
                                //frameLayout4.setBackground(greenRectangle);
                            }
                        }

                    }

                    int concentrationO3 = 0;
                    String[] cxArray = cxValue.split("=");
                    if(cxArray[0].equals("Cx")) {
                        //concentration = Double.parseDouble(cxArray[1].trim());
                        concentrationO3 = Integer.parseInt(cxArray[1].trim());



                        //concentration = concentration/1000;
                        cxFinal = concentrationO3 + " "+concentrationUnitO3;
                        //concentration = Integer.parseInt(cxArray[1].trim());

                        if (concentrationO3 > hazardousO3){
                            //cxTextView.setBackgroundColor(Color.rgb(160,5,5));

                            frameLayout6.setBackground(darkRedCircle);
                            safetyLevel6TextView.setText("VERY HIGH");
                        }
                        else if (concentrationO3 > unhealthyO3){
                            //cxTextView.setBackgroundColor(Color.rgb(255,5,5));

                            frameLayout6.setBackground(redCircle);
                            safetyLevel6TextView.setText("HIGH");
                        }
                        else if (concentrationO3 > moderateO3){
                            //cxTextView.setBackgroundColor(Color.rgb(255,255,0));

                            frameLayout6.setBackground(yellowCircle);
                            safetyLevel6TextView.setText("MEDIUM");
                        }
                        else{
                            //cxTextView.setBackgroundColor(Color.rgb(0,255,0));

                            frameLayout6.setBackground(greenCircle);
                            safetyLevel6TextView.setText("LOW");
                        }

                        cxTextView.setText(cxFinal);

                        int concentrationInt = (int) concentrationO3;
                        concentration6TextView.setText(concentrationInt+"");

                    }

                    double temp = 0;    //temp value to be used in log, only C values
                    String[] txArray = txValue.split("=");
                    if(txArray[0].equals("Tx")){
                        temp = Double.parseDouble(txArray[1].trim());
                        temp = temp/100;
                        double tempF = getTemp(temp);   //converts to F values depending on setting, only used on main page



                        if (temperatureUnitSetting.equals("C") || temperatureUnitSetting.equals("")){
                            txFinal =  String.valueOf(temp)+ " °C";

                            if(txFinal.length()>=8){
                                txFinal = txFinal.substring(0,4)+" °C";
                            }
                        }
                        else if (temperatureUnitSetting.equals("F")){
                            String tempFString = tempF+"";
                            if(tempFString.length()>5 ){
                                txFinal =  String.valueOf(tempF).substring(0,5)+ " °F";
                            }
                            else{
                                txFinal =  String.valueOf(tempF) + " °F";
                            }

                            if(txFinal.length()>=8){
                                txFinal = txFinal.substring(0,4)+" °F";
                            }

                        }



                        txTextView.setText(txFinal);

                        temperatureTextView.setText(txFinal);
                        concentration5TextView.setText(txFinal);

                        currentTemp = temp+"";

                    }

                    double humidity = 0;
                    String[] hxArrray = hxValue.split("=");
                    if(hxArrray[0].equals("Hx")){
                        humidity = Double.parseDouble(hxArrray[1].trim());
                        humidity = humidity/100;

                        if (humidity > 60) {

                            hxTextView.setBackgroundColor(Color.rgb(0,0,255));



                            /*if(latitude == 0.0 || longitude == 0.0){        //Only add to Alert file if gps is availible
                            }
                            else{

                                String location = getLocation(latitude, longitude);

                                SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
                                String format = s.format(new Date());
                                //format = format.substring(0,22);    //remove extra digits of milliseconds from tablet phones
                                if (location.equals("")){   //unable to retrieve address
                                    location = "?, ?, ?, ?";
                                }
                                writeToAlertFile(format.trim() + ", " + latitude + ", " + longitude + ", " + location + ", Humidity = " + humidity + " %" + "\n");

                            }*/


                        }
                        else if (humidity >50){
                            hxTextView.setBackgroundColor(Color.rgb(105,105,255));
                        }
                        else if (humidity > 30){
                            hxTextView.setBackgroundColor(Color.rgb(175,175,255));
                        }
                        else{
                            hxTextView.setBackgroundColor(Color.WHITE);
                        }

                        int humidityInt = (int) humidity;



                        hxFinal = humidity + " %";
                        if(hxFinal.length()>=6){
                            hxFinal = hxFinal.substring(0,4)+"%";
                        }
                        hxTextView.setText(hxFinal);

                        humidityTextView.setText(hxFinal);
                        concentration3TextView.setText(hxFinal);

                        currentRH = humidity+"";

                    }

                    double pressure = 0;
                    String[] pxArray = pxValue.split("=");
                    if(pxArray[0].equals("Px")) {
                        pressure = Double.parseDouble(pxArray[1].trim());
                        pressure = pressure/1000;
                        pxFinal = pressure + " kPa";
                        pxTextView.setText(pxFinal);

                    }

                    double volts = 0;
                    String[] vbArray = vbValue.split("=");
                    if(vbArray[0].equals("Vb")) {
                        volts = Double.parseDouble(vbArray[1].trim());
                        double batteryPercent = volts;
                        volts = volts/10;
                        //double batteryPercent = 100 - (4.1 - volts)*125;

                        int batteryPercentInt = (int) batteryPercent;
                        //batteryProgressBar.setProgress(batteryPercentInt);

                        String batteryPercentS = String.valueOf(batteryPercentInt);
                        //String batteryPercentF = batteryPercentS.substring(0,3);
                        vbFinal = volts + " V,  " + batteryPercentS + " %";
                        vbTextView.setText(vbFinal);

                        batteryTextView.setText(batteryPercentInt+" %");
                        concentration2TextView.setText(batteryPercentInt+" %");
                        chargingImageView.setVisibility(View.INVISIBLE);

                        if (batteryPercentInt == 255){  //if charging, returns 255
                            concentration2TextView.setText("");
                            chargingImageView.setVisibility(View.VISIBLE);
                        }


                    }

                    int aqi = 0;
                    aqi = getAQI(concentrationCO, concentrationO3);







                    if (mainDisplaySetting.equals("CO") || mainDisplaySetting.equals("")) {
                        if (aqi > hazardousAQI) {
                            //cxTextView.setBackgroundColor(Color.rgb(160,5,5));

                            //frameLayout2.setBackground(darkRedCircle);
                            safetyLevel2TextView.setText("VERY HIGH");
                            //createAlert(aqi);
                        } else if (aqi > unhealthyAQI) {
                            //cxTextView.setBackgroundColor(Color.rgb(255,5,5));

                            //frameLayout2.setBackground(redCircle);
                            safetyLevel2TextView.setText("HIGH");
                            //createAlert(aqi);
                        } else if (aqi > moderateAQI) {
                            //cxTextView.setBackgroundColor(Color.rgb(255,255,0));

                            //frameLayout2.setBackground(yellowCircle);
                            safetyLevel2TextView.setText("MEDIUM");

                        } else {
                            //cxTextView.setBackgroundColor(Color.rgb(0,255,0));

                            //frameLayout2.setBackground(greenCircle);
                            safetyLevel2TextView.setText("LOW");
                        }
                        //concentration2TextView.setText(aqi + "");
                    }
                    else if (mainDisplaySetting.equals("AQI")){
                        if (aqi > hazardousAQI) {
                            //cxTextView.setBackgroundColor(Color.rgb(160,5,5));

                            frameLayout1.setBackground(bigdarkRedCircle);
                            safetyLevel1TextView.setText("VERY HIGH");
                            frameLayout4.setBackground(darkRedRectangle);
                            messageTextView.setText("Your personal pollution level is VERY HIGH. \nEVACUATE IMMEDIATELY!");
                            vibrateHazardous();
                            createAlert(aqi);
                        } else if (aqi > unhealthyAQI) {
                            //cxTextView.setBackgroundColor(Color.rgb(255,5,5));

                            frameLayout1.setBackground(bigredCircle);
                            safetyLevel1TextView.setText("HIGH");
                            frameLayout4.setBackground(redRectangle);
                            messageTextView.setText("Your personal pollution level is HIGH. \nLEAVE AREA ASAP.");
                            vibrateUnhealthy();
                            createAlert(aqi);
                        } else if (aqi > moderateAQI) {
                            //cxTextView.setBackgroundColor(Color.rgb(255,255,0));

                            frameLayout1.setBackground(bigyellowCircle);
                            safetyLevel1TextView.setText("MEDIUM");
                            frameLayout4.setBackground(yellowRectangle);
                            if (enableAlertsAlways){
                                createAlert(aqi);
                            }
                            displayAPIValue();

                        } else {
                            //cxTextView.setBackgroundColor(Color.rgb(0,255,0));

                            //frameLayout1.setBackground(biggreenCircle);
                            frameLayout1.setBackground(biggreenCircle);
                            safetyLevel1TextView.setText("LOW");
                            frameLayout4.setBackground(greenRectangle);
                            if (enableAlertsAlways){
                                createAlert(aqi);
                            }
                            displayAPIValue();
                        }
                        concentration1TextView.setText(aqi + "");
                    }



                    Intent intent = new Intent(UartActivity.this, UartActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    PendingIntent pendingIntent = PendingIntent.getActivity(UartActivity.this, 0, intent, 0);

                    Notification notification1 =  new NotificationCompat.Builder(UartActivity.this, CHANNEL_2_ID)
                            .setSmallIcon(R.drawable.sparrow_status_bar)
                            .setContentTitle("SPARROW is connected")
                            .setContentText("Current CO concentration is "+ currentCOppm +" ppm CO")
                            .setPriority(NotificationCompat.PRIORITY_LOW)
                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                            .setContentIntent(pendingIntent)
                            .setTimeoutAfter(2000)      //needs to cancel itself but has to be greater than loop rate
                            .build();
                    notificationManager.notify(1,notification1);



                    loadLogSettings();




                        //logfile(a1Final+" "+cxFinal+" "+txFinal+" "+hxFinal+" "+pxFinal+" "+vbFinal+"\n");
                        //logListView.setVisibility(View.VISIBLE);

                        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss.SS ");
                        String format = s.format(new Date());


                        if (counts % logRate == 0) {
                            writeToLogFile(format.trim() + ", " + concentrationCO + ", " + concentrationO3 + ", " + temp + ", " + humidity + ", " + aqi + "\n");
                        }







                }

                SharedPreferences sharedPref = getSharedPreferences("connect status", Context.MODE_PRIVATE);

                String connectStatus = sharedPref.getString("status","");

                if (connectStatus.equals("true")){
                    connectBtn.setText("Connected");
                    connectBtn.setTextColor(Color.rgb(40,140,0));
                }
                else if (connectStatus.equals("false")){
                    connectBtn.setText("Not Connected");
                    connectBtn.setTextColor(Color.rgb(255,0,0));
                }
                else{
                    connectBtn.setText("Connect");
                }

                SharedPreferences sharedPrefCommands = getSharedPreferences("commands", 0);


                enableUSBCommand = sharedPrefCommands.getBoolean("enableUSB", false);
                if (enableUSBCommand){
                    uartSendData("U", false);
                    SharedPreferences.Editor commandsEditor = sharedPrefCommands.edit();
                    commandsEditor.putBoolean("enableUSB", false);
                    commandsEditor.apply();
                }


                zeroCommand = sharedPrefCommands.getBoolean("zero", false);
                    if (zeroCommand == true){
                        uartSendData("Z", false);
                        //uartSendData("s", false);
                        //uartSendData("s", false);
                        //frameLayout5.setBackground(yellowCircle);

                        SharedPreferences.Editor commandsEditor = sharedPrefCommands.edit();
                        commandsEditor.putBoolean("zero", false);
                        commandsEditor.apply();
                    }


                restoreDefaultsCommand = sharedPrefCommands.getBoolean("restoreDefault",false);
                if (restoreDefaultsCommand){
                    uartSendData("R", false);

                    SharedPreferences.Editor commandsEditor = sharedPrefCommands.edit();
                    commandsEditor.putBoolean("restoreDefault", false);
                    commandsEditor.apply();
                }





                //End of timed loop @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                handler.postDelayed(runnable,1000);
            }
        };
        runnable.run();



        /*t = new Thread(){     //thread version
            @Override
            public void run(){
                while(!isInterrupted()){
                    try{
                        Thread.sleep(1000);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {         //Run main timed loop here@@@@@@@@@@@@@@@@@@@@@@
                                if (startStopBtn.getText().toString().equals("Stop")){
                                    uartSendData("s",false);        //request data from Sparrow


                                }





                                counts++;
                                graphIntent.putExtra("counts", counts);
                                int listCount = rxData.size();
                                String logStatus = logBtn.getText().toString();
                                if(listCount>=6 && startStopBtn.getText().toString().equals("Stop")){
                                    String a1Value = rxData.get(listCount-6).toString();
                                    String cxValue = rxData.get(listCount-5).toString();
                                    String txValue = rxData.get(listCount-4).toString();
                                    String hxValue = rxData.get(listCount-3).toString();
                                    String pxValue = rxData.get(listCount-2).toString();
                                    String vbValue = rxData.get(listCount-1).toString();

                                    String a1Final ="";
                                    String cxFinal ="";
                                    String txFinal ="";
                                    String hxFinal = "";
                                    String pxFinal = "";
                                    String vbFinal = "";

                                    String[] a1Arrray = a1Value.split("=");
                                    if(a1Arrray[0].equals("A1")){
                                        a1Final = a1Arrray[1].trim() + " counts";
                                        a1TextView.setText(a1Final);
                                        a1Data.add(a1Final);
                                    }

                                    String[] cxArray = cxValue.split("=");
                                    if(cxArray[0].equals("Cx")) {
                                        cxFinal = cxArray[1].trim() + " ppb";
                                        int concentration = Integer.parseInt(cxArray[1].trim());

                                        if (concentration > 70000){
                                            cxTextView.setBackgroundColor(Color.rgb(160,5,5));
                                        }
                                        else if (concentration > 35000){
                                            cxTextView.setBackgroundColor(Color.rgb(255,5,5));
                                        }
                                        else if (concentration > 15000){
                                            cxTextView.setBackgroundColor(Color.rgb(255,255,0));
                                        }
                                        else{
                                            cxTextView.setBackgroundColor(Color.rgb(0,255,0));
                                        }

                                        cxTextView.setText(cxFinal);
                                        cxData.add(cxFinal);
                                    }

                                    String[] txArray = txValue.split("=");
                                    if(txArray[0].equals("Tx")){
                                        double temp = Double.parseDouble(txArray[1].trim());
                                        temp = temp/100;
                                        txFinal =  String.valueOf(temp)+ " °C";
                                        txTextView.setText(txFinal);
                                        txData.add(txFinal);
                                    }

                                    String[] hxArrray = hxValue.split("=");
                                    if(hxArrray[0].equals("Hx")){
                                        double humidity = Double.parseDouble(hxArrray[1].trim());
                                        humidity = humidity/100;

                                        if (humidity > 60) {

                                            hxTextView.setBackgroundColor(Color.rgb(0,0,255));

                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
                                            } else {
                                                //deprecated in API 26
                                                vibrator.vibrate(500);
                                            }

                                            if(latitude == 0.0 || longitude == 0.0){        //Add to Alert file if gps is availible
                                            }
                                            else{

                                                String location = getLocation(latitude,longitude);

                                                SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss.SS ");
                                                String format = s.format(new Date());

                                                writeToAlertFile(format+", "+ location+", humidity = "+humidity+" %" + "\n");
                                            }


                                        }
                                        else if (humidity >50){
                                            hxTextView.setBackgroundColor(Color.rgb(105,105,255));
                                        }
                                        else if (humidity > 30){
                                            hxTextView.setBackgroundColor(Color.rgb(175,175,255));
                                        }
                                        else{
                                            hxTextView.setBackgroundColor(Color.WHITE);
                                        }

                                        int humidityInt = (int) humidity;
                                        batteryProgressBar.setProgress(humidityInt);
                                        hxFinal = humidity + " %RH";
                                        hxTextView.setText(hxFinal);
                                        hxData.add(hxFinal);

                                    }

                                    String[] pxArray = pxValue.split("=");
                                    if(pxArray[0].equals("Px")) {
                                        double pressure = Double.parseDouble(pxArray[1].trim());
                                        pressure = pressure/1000;
                                        pxFinal = pressure + " kPa";
                                        pxTextView.setText(pxFinal);
                                        pxData.add(pxFinal);
                                    }

                                    String[] vbArray = vbValue.split("=");
                                    if(vbArray[0].equals("Vb")) {
                                        double volts = Double.parseDouble(vbArray[1].trim());
                                        volts = volts/10;
                                        double batteryPercent = 100 - (4.1 - volts)*125;
                                        int batteryPercentInt = (int) batteryPercent;
                                        //batteryProgressBar.setProgress(batteryPercentInt);

                                        String batteryPercentS = String.valueOf(batteryPercentInt);
                                        //String batteryPercentF = batteryPercentS.substring(0,3);
                                        vbFinal = volts + " V,  " + batteryPercentS + " %";
                                        vbTextView.setText(vbFinal);
                                        vbData.add(vbFinal);
                                    }

                                    //vbTextView.setText(hexToASCII(txFinal));

                                    graphIntent.putExtra("a1Data", a1Data);
                                    graphIntent.putExtra("cxData", cxData );
                                    graphIntent.putExtra("txData", txData);
                                    graphIntent.putExtra("hxData", hxData);
                                    graphIntent.putExtra("pxData", pxData);
                                    graphIntent.putExtra("vbData", vbData);





                                    if(logStatus.equals("Stop Log")){
                                        //logfile(a1Final+" "+cxFinal+" "+txFinal+" "+hxFinal+" "+pxFinal+" "+vbFinal+"\n");
                                        //logListView.setVisibility(View.VISIBLE);

                                        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss.SS ");
                                        String format = s.format(new Date());

                                        writeToLogFile(format+", "+a1Final+" "+cxFinal+" "+txFinal+" "+hxFinal+" "+pxFinal+" "+vbFinal+"\n");
                                    }





                                }

                                SharedPreferences sharedPref = getSharedPreferences("connect status", Context.MODE_PRIVATE);

                                String connectStatus = sharedPref.getString("status","");

                                if (connectStatus.equals("true")){
                                    connectBtn.setText("Connected");
                                    connectBtn.setTextColor(Color.rgb(0,255,0));
                                }
                                else if (connectStatus.equals("false")){
                                    connectBtn.setText("Not Connected");
                                    connectBtn.setTextColor(Color.rgb(255,0,0));
                                }
                                else{
                                    connectBtn.setText("Connect");
                                }

                            }           //End of timed loop@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                        });

                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }

            }
        };
        t.start();*/

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }

    @Override
    public void onResume() {
        super.onResume();

        UartActivity.this.overridePendingTransition(0,0);

        // Setup listeners
        mBleManager.setBleListener(this);

        mMqttManager.setListener(this);
        updateMqttStatus();

        // Start UI refresh
        //Log.d(TAG, "add ui timer");
        updateUI();

        isUITimerRunning = true;
        mUIRefreshTimerHandler.postDelayed(mUIRefreshTimerRunnable, 0);

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        loadSettings();



        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    }

    @Override
    public void onPause() {
        super.onPause();





        //Log.d(TAG, "remove ui timer");
        isUITimerRunning = false;
        mUIRefreshTimerHandler.removeCallbacksAndMessages(mUIRefreshTimerRunnable);

        // Save preferences
        SharedPreferences preferences = getSharedPreferences(kPreferences, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(kPreferences_echo, mIsEchoEnabled);
        editor.putBoolean(kPreferences_eol, mIsEolEnabled);
        editor.putInt(kPreferences_eolCharactersId, mEolCharactersId);
        editor.putBoolean(kPreferences_asciiMode, !mShowDataInHexFormat);
        editor.putBoolean(kPreferences_timestampDisplayMode, mIsTimestampDisplayMode);

        editor.apply();
    }


    @Override
    public void onDestroy() {       //only called when user device disconnects, not through force close of app
        // Disconnect mqtt
        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        if (mMqttManager != null) {
            mMqttManager.disconnect();
        }
        // Retain data
        saveRetainedDataFragment();

        if (mTTS != null){
            mTTS.stop();
            mTTS.shutdown();
        }

        if(disconnectVibrateSetting){
            vibrate1000();

            Intent intent = new Intent(UartActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(UartActivity.this, 0, intent, 0);

            Notification notification =  new NotificationCompat.Builder(this, CHANNEL_1_ID)
                    .setSmallIcon(R.drawable.sparrow_status_bar)
                    .setContentTitle("SPARROW is disconnected")
                    .setContentText("Click here to reconnect your SPARROW device")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setContentIntent(pendingIntent)        //may need to be removed
                    .build();
            notificationManager.notify(1,notification);

            super.onDestroy();
        }


        //Toast.makeText(this,"Sparrow Disconnected",Toast.LENGTH_LONG).show();



        //Used to restart app in 50 ms after disconnecting @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        if (autoReconnectSetting){
            Intent mStartActivity = getBaseContext().getPackageManager()
                    .getLaunchIntentForPackage( getBaseContext().getPackageName() );
            int mPendingIntentId = 123456;
            PendingIntent mPendingIntent = PendingIntent.getActivity(this, mPendingIntentId,    mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
            AlarmManager mgr = (AlarmManager)this.getSystemService(Context.ALARM_SERVICE);
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 50, mPendingIntent);
            System.exit(0);
        }





    }

    public void dismissKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void onClickSend(View view) {
        String data = mSendEditText.getText().toString();
        mSendEditText.setText("");       // Clear editText

        //secondActivityBtn.setText(mBufferListView.getItemAtPosition(mBufferListAdapter.getCount()-3)+"");
        //secondActivityBtn.setText(rxData.size()+"asd");
        uartSendData(data, false);

    }

    public void uartSendData(String data, boolean wasReceivedFromMqtt) {
        // MQTT publish to TX
        MqttSettings settings = MqttSettings.getInstance(UartActivity.this);
        if (!wasReceivedFromMqtt) {
            if (settings.isPublishEnabled()) {
                String topic = settings.getPublishTopic(MqttUartSettingsActivity.kPublishFeed_TX);
                final int qos = settings.getPublishQos(MqttUartSettingsActivity.kPublishFeed_TX);
                mMqttManager.publish(topic, data, qos);
            }
        }

        // Add eol
        if (mIsEolEnabled) {
            // Add newline character if checked
            data += getEolCharacters();//"\n";
        }

        // Send to uart
        if (!wasReceivedFromMqtt || settings.getSubscribeBehaviour() == MqttSettings.kSubscribeBehaviour_Transmit) {
            sendData(data);
            mSentBytes += data.length();
        }

        // Add to current buffer
        byte[] bytes = new byte[0];
        try {
            bytes = data.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        UartDataChunk dataChunk = new UartDataChunk(System.currentTimeMillis(), UartDataChunk.TRANSFERMODE_TX, bytes);
        //add if statemnt here to prevent adding null objects @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        if (dataChunk != null){
            mDataBuffer.add(dataChunk);
        }
        //mDataBuffer.add(dataChunk);

        final String formattedData = mShowDataInHexFormat ? BleUtils.bytesToHex2(bytes) : BleUtils.bytesToText(bytes, true);



        if (mIsTimestampDisplayMode) {
            final String currentDateTimeString = DateFormat.getTimeInstance().format(new Date(dataChunk.getTimestamp()));
            mBufferListAdapter.add(new TimestampData("[" + currentDateTimeString + "] TX: " + formattedData, mTxColor));
            mBufferListView.setSelection(mBufferListAdapter.getCount());
        }

        // Update UI
        updateUI();
    }

    private String getEolCharacters() {
        switch (mEolCharactersId) {
            case 1:
                return "\r";
            case 2:
                return "\n\r";
            case 3:
                return "\r\n";
            default:
                return "\n";
        }
    }

    private int getEolCharactersStringId() {
        switch (mEolCharactersId) {
            case 1:
                return R.string.uart_eolmode_r;
            case 2:
                return R.string.uart_eolmode_nr;
            case 3:
                return R.string.uart_eolmode_rn;
            default:
                return R.string.uart_eolmode_n;
        }
    }

    /*public void onClickCopy(View view) {
        String text = mBufferTextView.getText().toString(); // mShowDataInHexFormat ? mHexSpanBuffer.toString() : mAsciiSpanBuffer.toString();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText("UART", text);
            clipboard.setPrimaryClip(clip);
        }
    }*/

    public void onClickClear(View view) {
        mTextSpanBuffer.clear();
        mDataBufferLastSize = 0;
        mBufferListAdapter.clear();
        mBufferTextView.setText("");

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        rxData.clear();

        counts = 0;

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


        mDataBuffer.clear();
        mSentBytes = 0;
        mReceivedBytes = 0;
        updateUI();

    }

    public void onClickShare(View view) {
        String textToSend = mBufferTextView.getText().toString(); // (mShowDataInHexFormat ? mHexSpanBuffer : mAsciiSpanBuffer).toString();

        if (textToSend.length() > 0) {

            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, textToSend);
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.uart_share_subject));     // subject will be used if sent to an email app
            sendIntent.setType("text/*");       // Note: don't use text/plain because dropbox will not appear as destination
            // startActivity(sendIntent);
            startActivity(Intent.createChooser(sendIntent, getResources().getText(R.string.uart_sharechooser_title)));      // Always show the app-chooser
        } else {
            new AlertDialog.Builder(this)
                    .setMessage(getString(R.string.uart_share_empty))
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
        }
    }

    private void setDisplayFormatToTimestamp(boolean enabled) {
        mIsTimestampDisplayMode = enabled;
        mBufferTextView.setVisibility(enabled ? View.GONE : View.VISIBLE);
        mBufferListView.setVisibility(enabled ? View.VISIBLE : View.GONE);
    }

    // region Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {




        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_uart, menu);

        // Mqtt
        mMqttMenuItem = menu.findItem(R.id.action_mqttsettings);
        mMqttMenuItemAnimationHandler = new Handler();
        mMqttMenuItemAnimationRunnable.run();


        // DisplayMode
        /*MenuItem displayModeMenuItem = menu.findItem(R.id.action_displaymode);
        displayModeMenuItem.setTitle(String.format(getString(R.string.uart_action_displaymode_format), getString(mIsTimestampDisplayMode ? R.string.uart_displaymode_timestamp : R.string.uart_displaymode_text)));
        SubMenu displayModeSubMenu = displayModeMenuItem.getSubMenu();
        if (mIsTimestampDisplayMode) {
            MenuItem displayModeTimestampMenuItem = displayModeSubMenu.findItem(R.id.action_displaymode_timestamp);
            displayModeTimestampMenuItem.setChecked(true);
        } else {
            MenuItem displayModeTextMenuItem = displayModeSubMenu.findItem(R.id.action_displaymode_text);
            displayModeTextMenuItem.setChecked(true);
        }*/

        // DataMode
        /*MenuItem dataModeMenuItem = menu.findItem(R.id.action_datamode);
        dataModeMenuItem.setTitle(String.format(getString(R.string.uart_action_datamode_format), getString(mShowDataInHexFormat ? R.string.uart_format_hexadecimal : R.string.uart_format_ascii)));
        SubMenu dataModeSubMenu = dataModeMenuItem.getSubMenu();
        if (mShowDataInHexFormat) {
            MenuItem dataModeHexMenuItem = dataModeSubMenu.findItem(R.id.action_datamode_hex);
            dataModeHexMenuItem.setChecked(true);
        } else {
            MenuItem dataModeAsciiMenuItem = dataModeSubMenu.findItem(R.id.action_datamode_ascii);
            dataModeAsciiMenuItem.setChecked(true);
        }*/

        // Echo
        /*MenuItem echoMenuItem = menu.findItem(R.id.action_echo);
        echoMenuItem.setTitle(R.string.uart_action_echo);
        echoMenuItem.setChecked(mIsEchoEnabled);*/

        // Eol
        /*MenuItem eolMenuItem = menu.findItem(R.id.action_eol);
        eolMenuItem.setTitle(R.string.uart_action_eol);
        eolMenuItem.setChecked(mIsEolEnabled);*/

        // Eol Characters
        /*MenuItem eolModeMenuItem = menu.findItem(R.id.action_eolmode);
        eolModeMenuItem.setTitle(String.format(getString(R.string.uart_action_eolmode_format), getString(getEolCharactersStringId())));
        SubMenu eolModeSubMenu = eolModeMenuItem.getSubMenu();
        int selectedEolCharactersSubMenuId;
        switch (mEolCharactersId) {
            case 1:
                selectedEolCharactersSubMenuId = R.id.action_eolmode_r;
                break;
            case 2:
                selectedEolCharactersSubMenuId = R.id.action_eolmode_nr;
                break;
            case 3:
                selectedEolCharactersSubMenuId = R.id.action_eolmode_rn;
                break;
            default:
                selectedEolCharactersSubMenuId = R.id.action_eolmode_n;
                break;
        }*/
        /*MenuItem selectedEolCharacterMenuItem = eolModeSubMenu.findItem(selectedEolCharactersSubMenuId);
        selectedEolCharacterMenuItem.setChecked(true);*/

        return true;
    }

    private Runnable mMqttMenuItemAnimationRunnable = new Runnable() {
        @Override
        public void run() {
            updateMqttStatus();
            mMqttMenuItemAnimationHandler.postDelayed(mMqttMenuItemAnimationRunnable, 500);
        }
    };
    private int mMqttMenuItemAnimationFrame = 0;

    private void updateMqttStatus() {
        if (mMqttMenuItem == null)
            return;      // Hack: Sometimes this could have not been initialized so we don't update icons

        MqttManager mqttManager = MqttManager.getInstance(this);
        MqttManager.MqqtConnectionStatus status = mqttManager.getClientStatus();

        if (status == MqttManager.MqqtConnectionStatus.CONNECTING) {
            final int kConnectingAnimationDrawableIds[] = {R.drawable.mqtt_connecting1, R.drawable.mqtt_connecting2, R.drawable.mqtt_connecting3};
            mMqttMenuItem.setIcon(kConnectingAnimationDrawableIds[mMqttMenuItemAnimationFrame]);
            mMqttMenuItemAnimationFrame = (mMqttMenuItemAnimationFrame + 1) % kConnectingAnimationDrawableIds.length;
        } else if (status == MqttManager.MqqtConnectionStatus.CONNECTED) {
            mMqttMenuItem.setIcon(R.drawable.mqtt_connected);
            mMqttMenuItemAnimationHandler.removeCallbacks(mMqttMenuItemAnimationRunnable);
        } else {
            mMqttMenuItem.setIcon(R.drawable.mqtt_disconnected);
            mMqttMenuItemAnimationHandler.removeCallbacks(mMqttMenuItemAnimationRunnable);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        final int id = item.getItemId();

        switch (id) {
            case R.id.action_help:
                startHelp();
                return true;

            case R.id.action_connected_settings:
                startConnectedSettings();
                return true;

            case R.id.action_refreshcache:
                if (mBleManager != null) {
                    mBleManager.refreshDeviceCache();
                }
                break;

            case R.id.action_mqttsettings:
                Intent intent = new Intent(this, MqttUartSettingsActivity.class);
                startActivityForResult(intent, kActivityRequestCode_MqttSettingsActivity);
                break;

            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            case R.id.accountSettings:
                Intent accountSettingsIntent = new Intent(getApplicationContext(), AccountSettingsActivity.class);
                startActivity(accountSettingsIntent);
                break;

            case R.id.mySparrowSettings:
                Intent mySparrowSettingsIntent = new Intent(getApplicationContext(),MySparrowSettingsActivity.class);
                startActivity(mySparrowSettingsIntent);
                break;

            case R.id.preferencesSettings:
                //Intent preferencesIntent = new Intent(getApplicationContext(),PreferencesSettingsActivity.class);
                Intent preferencesIntent = new Intent(getApplicationContext(),SettingsActivity.class);
                startActivity(preferencesIntent);

                break;


            case R.id.connectDisconnectSetting:
                onBackPressed();

                break;

            case R.id.eventsBtn:
                AlertDialog.Builder builder = new AlertDialog.Builder(UartActivity.this);
                builder.setTitle("Enter an event");

                // Set up the input
                final EditText input = new EditText(UartActivity.this);
                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                //input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        eventsString = input.getText().toString();
                        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss ");
                        String time = s.format(new Date());
                        writeToEventsFile(time +"~ " + eventsString+" ~ "+currentCOppm+" ~ "+"0"+" ~ "+currentTemp+" ~ "+currentRH+"0"+" ~ "+"\n");
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();

                break;


            case R.id.skipLogDownload:
                AlertDialog.Builder builder2;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder2 = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder2 = new AlertDialog.Builder(this);
                }
                builder2.setTitle("Skip Log Download")
                        .setMessage("Stop sparrow app from downloading log and go straight to tracking. Unsaved data points from log will be lost forever. Are you sure you want to skip log download?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something
                                //uartSendData("l",false);
                                uartSendData("L",false);
                                uartSendData("l",false);
                                startSingleRead = true;
                                //Toast.makeText(getApplicationContext(), "Log download skipped", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                break;
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

            /*case R.id.action_displaymode_timestamp:
                setDisplayFormatToTimestamp(true);
                recreateDataView();
                invalidateOptionsMenu();
                return true;

            case R.id.action_displaymode_text:
                setDisplayFormatToTimestamp(false);
                recreateDataView();
                invalidateOptionsMenu();
                return true;

            case R.id.action_datamode_hex:
                mShowDataInHexFormat = true;
                recreateDataView();
                invalidateOptionsMenu();
                return true;

            case R.id.action_datamode_ascii:
                mShowDataInHexFormat = false;
                recreateDataView();
                invalidateOptionsMenu();
                return true;

            case R.id.action_echo:
                mIsEchoEnabled = !mIsEchoEnabled;
                invalidateOptionsMenu();
                return true;

            case R.id.action_eol:
                mIsEolEnabled = !mIsEolEnabled;
                invalidateOptionsMenu();
                return true;

            case R.id.action_eolmode_n:
                mEolCharactersId = 0;
                invalidateOptionsMenu();
                return true;

            case R.id.action_eolmode_r:
                mEolCharactersId = 1;
                invalidateOptionsMenu();
                return true;


            case R.id.action_eolmode_nr:
                mEolCharactersId = 2;
                invalidateOptionsMenu();
                return true;

            case R.id.action_eolmode_rn:
                mEolCharactersId = 3;
                invalidateOptionsMenu();
                return true;*/

        }

        return super.onOptionsItemSelected(item);
    }

    private void startConnectedSettings() {
        // Launch connected settings activity
        Intent intent = new Intent(this, ConnectedSettingsActivity.class);
        startActivityForResult(intent, kActivityRequestCode_ConnectedSettingsActivity);
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent intent) {
        if (requestCode == kActivityRequestCode_ConnectedSettingsActivity && resultCode == RESULT_OK) {
            finish();
        } else if (requestCode == kActivityRequestCode_MqttSettingsActivity && resultCode == RESULT_OK) {

        }
    }

    private void startHelp() {
        // Launch app help activity
        /*Intent intent = new Intent(this, CommonHelpActivity.class);
        intent.putExtra("title", getString(R.string.uart_help_title));
        intent.putExtra("help", "uart_help.html");
        startActivity(intent);*/
    }
    // endregion

    // region BleManagerListener
    /*
    @Override
    public void onConnected() {

    }

    @Override
    public void onConnecting() {

    }
*/
    @Override
    public void onDisconnected() {
        super.onDisconnected();
        Log.d(TAG, "Disconnected. Back to previous activity");
        finish();
    }

    @Override
    public void onServicesDiscovered() {
        super.onServicesDiscovered();
        enableRxNotifications();
    }

    @Override
    public synchronized void onDataAvailable(BluetoothGattCharacteristic characteristic) {
        super.onDataAvailable(characteristic);
        // UART RX
        if (characteristic.getService().getUuid().toString().equalsIgnoreCase(UUID_SERVICE)) {
            if (characteristic.getUuid().toString().equalsIgnoreCase(UUID_RX)) {
                final byte[] bytes = characteristic.getValue();
                mReceivedBytes += bytes.length;

                final UartDataChunk dataChunk = new UartDataChunk(System.currentTimeMillis(), UartDataChunk.TRANSFERMODE_RX, bytes);
                mDataBuffer.add(dataChunk);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mIsTimestampDisplayMode) {
                            final String currentDateTimeString = DateFormat.getTimeInstance().format(new Date(dataChunk.getTimestamp()));
                            final String formattedData = mShowDataInHexFormat ? BleUtils.bytesToHex2(bytes) : BleUtils.bytesToText(bytes, true);


                            rxCounts++;
                            if (rxCounts == 1){  //reading the 1st line after sending "e", HW and FW #
                                String HWFW = hexToDecimal3(formattedData);
                                String[] split = HWFW.split(" ");
                                hwVersion = split[0];
                                fwVersion = split[1];
                                if (hwVersion.equals("3")){         //new hardware version that contains 2 sensors
                                    frameLayout6.setVisibility(View.VISIBLE);


                                }

                            }

                            if (rxCounts == 2){
                                sensor1ID = hexToDecimal2(formattedData);
                            }
                            if (rxCounts == 3){
                                sensor2ID = hexToDecimal2(formattedData);
                            }
                            if (rxCounts == 4){
                                lines = hexToDecimal4(formattedData);
                                timeOnDisconnect = System.currentTimeMillis() - (lines*sparrowLogRate);
                            }
                            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ use if using Hex output from sparrow

                            if (rxCounts>4) {  //no longer reading from "e"
                                String dataString = hexToDecimal(formattedData);


                                String[] dataArray = dataString.split(" ");
                                if (dataArray.length == 6) {         //only add to rxdata if reading from single read "s"
                                    for (int i = 0; i < dataArray.length; i++) {
                                        rxData.add(dataArray[i]);
                                    }
                                }
                                else if(dataArray.length == 5){
                                    //reading from sparrow log
                                    //format and add directly to log file

                                    String measurementTime = getDate(timeOnDisconnect);
                                    String logFileFormat = measurementTime + ", " + dataArray[0] + ", " + dataArray[1] + ", " + dataArray[2] + ", " + dataArray[3] + ", " + dataArray[4] + "\n";
                                    writeToLogFile(logFileFormat);

                                    timeOnDisconnect = timeOnDisconnect + sparrowLogRate; //may need to add a few ms to sparrowLogRate due to delays due to sparrow hardware
                                }


                                timeOnLastReceive = System.currentTimeMillis();

                                SharedPreferences sharedPrefLastRecieve = getSharedPreferences("last receive", 0);
                                SharedPreferences.Editor editorLastRecieve = sharedPrefLastRecieve.edit();
                                editorLastRecieve.putLong("time on disconnect", timeOnLastReceive);
                                editorLastRecieve.apply();
                            }
                            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


                            //rxData.add(formattedData);       //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Use if using ascii output from sparrow




                            mBufferListAdapter.add(new TimestampData("[" + currentDateTimeString + "] RX: " + formattedData, mRxColor));    //REmoved

                            //mBufferListAdapter.add("[" + currentDateTimeString + "] RX: " + formattedData);
                            //mBufferListView.smoothScrollToPosition(mBufferListAdapter.getCount() - 1);
                            mBufferListView.setSelection(mBufferListAdapter.getCount());
                        }
                        updateUI();
                    }
                });

                // MQTT publish to RX
                MqttSettings settings = MqttSettings.getInstance(UartActivity.this);
                if (settings.isPublishEnabled()) {
                    String topic = settings.getPublishTopic(MqttUartSettingsActivity.kPublishFeed_RX);
                    final int qos = settings.getPublishQos(MqttUartSettingsActivity.kPublishFeed_RX);
                    final String text = BleUtils.bytesToText(bytes, false);
                    mMqttManager.publish(topic, text, qos);
                }
            }
        }
    }


/*
    @Override
    public void onDataAvailable(BluetoothGattDescriptor descriptor) {

    }

    @Override
    public void onReadRemoteRssi(int rssi) {

    }
    */
    // endregion

    private void addTextToSpanBuffer(SpannableStringBuilder spanBuffer, String text, int color) {

        if (kUseColorsForData) {
            final int from = spanBuffer.length();
            spanBuffer.append(text);
            spanBuffer.setSpan(new ForegroundColorSpan(color), from, from + text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        } else {
            spanBuffer.append(text);
        }
    }

    private void updateUI() {
        mSentBytesTextView.setText(String.format(getString(R.string.uart_sentbytes_format), mSentBytes));
        mReceivedBytesTextView.setText(String.format(getString(R.string.uart_receivedbytes_format), mReceivedBytes));
    }

    private int mDataBufferLastSize = 0;

    private void updateTextDataUI() {

        if (!mIsTimestampDisplayMode) {
            if (mDataBufferLastSize != mDataBuffer.size()) {

                final int bufferSize = mDataBuffer.size();
                if (bufferSize > maxPacketsToPaintAsText) {
                    mDataBufferLastSize = bufferSize - maxPacketsToPaintAsText;
                    mTextSpanBuffer.clear();
                    addTextToSpanBuffer(mTextSpanBuffer, getString(R.string.uart_text_dataomitted) + "\n", kInfoColor);
                }

                // Log.d(TAG, "update packets: "+(bufferSize-mDataBufferLastSize));
                for (int i = mDataBufferLastSize; i < bufferSize; i++) {
                    final UartDataChunk dataChunk = mDataBuffer.get(i);
                    final boolean isRX = dataChunk.getMode() == UartDataChunk.TRANSFERMODE_RX;
                    final byte[] bytes = dataChunk.getData();
                    final String formattedData = mShowDataInHexFormat ? BleUtils.bytesToHex2(bytes) : BleUtils.bytesToText(bytes, true);
                    addTextToSpanBuffer(mTextSpanBuffer, formattedData, isRX ? mRxColor : mTxColor);
                }

                mDataBufferLastSize = mDataBuffer.size();
                mBufferTextView.setText(mTextSpanBuffer);
                //mBufferTextView.setSelection(0, mTextSpanBuffer.length());        // to automatically scroll to the end
            }
        }
    }

    private void recreateDataView() {

        if (mIsTimestampDisplayMode) {
            mBufferListAdapter.clear();

            final int bufferSize = mDataBuffer.size();
            for (int i = 0; i < bufferSize; i++) {

                final UartDataChunk dataChunk = mDataBuffer.get(i);
                final boolean isRX = dataChunk.getMode() == UartDataChunk.TRANSFERMODE_RX;
                final byte[] bytes = dataChunk.getData();
                final String formattedData = mShowDataInHexFormat ? BleUtils.bytesToHex2(bytes) : BleUtils.bytesToText(bytes, true);

                //rxData.add(formattedData); //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                final String currentDateTimeString = DateFormat.getTimeInstance().format(new Date(dataChunk.getTimestamp()));
                mBufferListAdapter.add(new TimestampData("[" + currentDateTimeString + "] " + (isRX ? "RX" : "TX") + ": " + formattedData, isRX ? mRxColor : mTxColor));
//                mBufferListAdapter.add("[" + currentDateTimeString + "] " + (isRX ? "RX" : "TX") + ": " + formattedData);
            }
            mBufferListView.setSelection(mBufferListAdapter.getCount());
        } else {
            mDataBufferLastSize = 0;
            mTextSpanBuffer.clear();
            mBufferTextView.setText("");
        }
    }


    // region DataFragment
    public static class DataFragment extends Fragment {
        private boolean mShowDataInHexFormat;
        private SpannableStringBuilder mTextSpanBuffer;
        private ArrayList<UartDataChunk> mDataBuffer;
        private int mSentBytes;
        private int mReceivedBytes;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setRetainInstance(true);
        }
    }

    private void restoreRetainedDataFragment() {
        // find the retained fragment
        FragmentManager fm = getFragmentManager();
        mRetainedDataFragment = (DataFragment) fm.findFragmentByTag(TAG);

        if (mRetainedDataFragment == null) {
            // Create
            mRetainedDataFragment = new DataFragment();
            fm.beginTransaction().add(mRetainedDataFragment, TAG).commit();

            mDataBuffer = new ArrayList<>();
            mTextSpanBuffer = new SpannableStringBuilder();
        } else {
            // Restore status
            mShowDataInHexFormat = mRetainedDataFragment.mShowDataInHexFormat;
            mTextSpanBuffer = mRetainedDataFragment.mTextSpanBuffer;
            mDataBuffer = mRetainedDataFragment.mDataBuffer;
            mSentBytes = mRetainedDataFragment.mSentBytes;
            mReceivedBytes = mRetainedDataFragment.mReceivedBytes;
        }
    }

    private void saveRetainedDataFragment() {
        mRetainedDataFragment.mShowDataInHexFormat = mShowDataInHexFormat;
        mRetainedDataFragment.mTextSpanBuffer = mTextSpanBuffer;
        mRetainedDataFragment.mDataBuffer = mDataBuffer;
        mRetainedDataFragment.mSentBytes = mSentBytes;
        mRetainedDataFragment.mReceivedBytes = mReceivedBytes;
    }
    // endregion


    // region MqttManagerListener

    @Override
    public void onMqttConnected() {
        updateMqttStatus();
    }

    @Override
    public void onMqttDisconnected() {
        updateMqttStatus();
    }

    @Override
    public void onMqttMessageArrived(String topic, MqttMessage mqttMessage) {
        final String message = new String(mqttMessage.getPayload());

        //Log.d(TAG, "Mqtt messageArrived from topic: " +topic+ " message: "+message);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                uartSendData(message, true);       // Don't republish to mqtt something received from mqtt
            }
        });

    }

    // endregion


    // region TimestampAdapter
    private class TimestampData {
        String text;
        int textColor;

        TimestampData(String text, int textColor) {
            this.text = text;
            this.textColor = textColor;
        }
    }

    private class TimestampListAdapter extends ArrayAdapter<TimestampData> {

        TimestampListAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.layout_uart_datachunkitem, parent, false);
            }

            TimestampData data = getItem(position);
            if (data != null) {
                TextView textView = (TextView) convertView;
                textView.setText(data.text);
                textView.setTextColor(data.textColor);
            }

            return convertView;
        }
    }







    public void logfile(String input)       //works on BLU phone
    {
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd");
//        Date now = new Date();
//        String fileName = "App1_" + formatter.format(now) + ".txt";//like 2016_01_12.txt

        String fileName = "Sparrow_Log.txt";//like 2016_01_12.txt

        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss.SS ");
        String format = s.format(new Date());

        try
        {
            File root = new File(Environment.getExternalStorageDirectory()+File.separator+"Documents", "KWJ");
            //File root = new File(Environment.getExternalStorageDirectory(), "Notes");
            if (!root.exists())
            {
                root.mkdirs();
            }
            File gpxfile = new File(root, fileName);

            FileWriter writer = new FileWriter(gpxfile,true);
//            writer.append(input + ", ");
            writer.append(format + input);
            writer.flush();
            writer.close();
            Toast.makeText(this, "Data written to Sparrow_Log.txt", Toast.LENGTH_SHORT).show();
        }
        catch(IOException e)
        {
            e.printStackTrace();

        }
    }

    public void writeToLogFile(String data)        //works on BLU and galaxy s8
    {
        try {
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }



    public void writeToAlertFile(String data)        //works on BLU and galaxy s8
    {
        try {
            FileOutputStream fos = new FileOutputStream(myAlertFile, true);
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowAlert.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void writeToAlertFileThread(final String data){
        Thread t = new Thread(){
            @Override
            public void run() {
                writeToAlertFile(data);
            }
        };
        t.start();
    }

    public void writeToEventsFile(String data)        //works on BLU and galaxy s8
    {
        try {
            FileOutputStream fos = new FileOutputStream(myEventFile, true);
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public String getLocation(double latitude, double longitude)
    {
        String address = "";
        if (latitude != 0.0 && longitude != 0.0) {
            try {
                addresses = geocoder.getFromLocation(latitude, longitude, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }

            if(addresses != null){
                address = addresses.get(0).getAddressLine(0);
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL
            }


        }
        return  address;
    }

    public int hexToDecimal4 (String hex){   //for number of lines in device log
        String[] hexArray = hex.split(" "); //split based on spaces
        String linesInHexString = hexArray[0]+hexArray[1];
        int linesInHexInt = Integer.parseInt(linesInHexString,16);


        return linesInHexInt;
    }

    public String hexToDecimal3 (String hex){   //for hardware and firmware version number
        String[] hexArray = hex.split(" "); //split based on spaces
        String HWInHex = hexArray[0];
        String FWInHex = hexArray[1];
        long HWInhexLong = Long.parseLong(HWInHex,16);
        long FWInhexLong = Long.parseLong(FWInHex,16);


        String outputString = HWInhexLong + " " + FWInhexLong;
        return outputString;
    }

    public String hexToDecimal2 (String hex){   //for sensitivity factor of sensors
        String[] hexArray = hex.split(" "); //split based on spaces
        String sfInHex = hexArray[4]+hexArray[5]+hexArray[6]+hexArray[7];
        long sfInhexLong = Long.parseLong(sfInHex,16);

        if(sfInhexLong > 2000000000){
            long max = 4294967296L;    //4294967296L
            long negative = (max - sfInhexLong)*(-1);
            sfInhexLong = negative;
        }

        String outputString = sfInhexLong+"";
        return outputString;
    }

    public String hexToDecimal (String hex){        //accepts raw hex output from sparrow sperated by spaces

        String[] hexArray = hex.split(" "); //split based on spaces
        String outputString = "";

        if (hexArray.length == 16){    //reading from single output "s"
            String a1String = hexArray[0]+hexArray[1]+hexArray[2]+hexArray[3];
            String cxString = hexArray[4]+hexArray[5]+hexArray[6]+hexArray[7];
            String txString = hexArray[8]+hexArray[9];
            String hxString = hexArray[10]+hexArray[11];
            String pxString = hexArray[12]+hexArray[13]+hexArray[14];
            String vbString = hexArray[15];

            long a1Number = Long.parseLong(a1String, 16);
            if (a1Number > 2000000000){ //if reading a negative number
                a1Number = 0;
            }
            long cxNumber = Long.parseLong(cxString, 16);
            if (cxNumber > 2000000000){ //if reading a negative number
                cxNumber = 0;
            }
            int txNumber = Integer.parseInt(txString, 16);

            if (txNumber > 32767){
                int max = 65535;
                int negative = (max - txNumber)*(-1);
                txNumber = negative;
            }

            int hxNumber = Integer.parseInt(hxString, 16);
            int pxNumber = Integer.parseInt(pxString, 16);
            int vbNumber = Integer.parseInt(vbString, 16);


            outputString = "A1="+a1Number+" Cx="+cxNumber+" Tx="+txNumber+" Hx="+hxNumber+" Px="+pxNumber+" Vb="+vbNumber;


        }
        else if (hexArray.length == 12){   //reading from log file output "l"
            String ppbCO = hexArray[0]+hexArray[1]+hexArray[2]+hexArray[3];
            String ppbO3 = hexArray[4]+hexArray[5]+hexArray[6]+hexArray[7];
            String txString = hexArray[8]+hexArray[9];
            String hxString = hexArray[10]+hexArray[11];

            long ppbCONumber = Long.parseLong(ppbCO, 16);
            if (ppbCONumber > 2000000000){
                ppbCONumber = 0;
            }
            long ppbO3Number = Long.parseLong(ppbO3, 16);
            if (ppbO3Number > 2000000000){
                ppbO3Number = 0;
            }

            int txNumber = Integer.parseInt(txString, 16);

            if (txNumber > 32767){
                int max = 65535;
                int negative = (max - txNumber)*(-1);
                txNumber = negative;
            }

            int hxNumber = Integer.parseInt(hxString, 16);

            double txNumberDouble = (double) txNumber;
            txNumberDouble = txNumberDouble/100;

            double hxNumberDouble = (double) hxNumber;
            hxNumberDouble = hxNumberDouble/100;

            double ppmCO = ppbCONumber/1000.0;
            int AQI = getAQI(ppmCO,(int) ppbO3Number);

            outputString = ppmCO+" "+ppbO3Number+" "+txNumberDouble+" "+hxNumberDouble+" " + AQI;   //formatted for log text file
        }

        return outputString;

    }

    /*public String hexToDecimal (String hex) {
        String[] hexArray = hex.split(" "); //split based on spaces
        String outputString = "";

        if (hexArray.length == 16){    //reading from single output "s"
            String a1String = hexArray[0]+hexArray[1]+hexArray[2]+hexArray[3];
            String cxString = hexArray[4]+hexArray[5]+hexArray[6]+hexArray[7];
            String txString = hexArray[8]+hexArray[9];
            String hxString = hexArray[10]+hexArray[11];
            String pxString = hexArray[12]+hexArray[13]+hexArray[14];
            String vbString = hexArray[15];

            long coNumber = Long.parseLong(a1String, 16);
            if (coNumber > 2000000000){ //if reading a negative number
                coNumber = 0;
            }
            long o3Number = Long.parseLong(cxString, 16);
            if (o3Number > 2000000000){ //if reading a negative number
                o3Number = 0;
            }
            int txNumber = Integer.parseInt(txString, 16);
            int hxNumber = Integer.parseInt(hxString, 16);
            int pxNumber = Integer.parseInt(pxString, 16);
            int vbNumber = Integer.parseInt(vbString, 16);


            outputString = "CO="+coNumber+" O3="+o3Number+" Tx="+txNumber+" Hx="+hxNumber+" Px="+pxNumber+" Vb="+vbNumber;


        }
        return outputString;
    }*/


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 10:
                configure_location();
                break;
            default:
                break;
        }
    }
    void configure_location(){
        // first check for permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.INTERNET}
                        ,10);
            }
            return;
        }
        // this code won't execute IF permissions are not allowed, because in the line above there is return statement.

        locationManager.requestLocationUpdates("gps", 5000, 0, locationListener);


    }

    public int getAQI (double ppmCO, int ppbO3){
        int aqi = 0;
        double aqiCO = 0;
        double aqiO3 = 0;
        if (ppmCO >= 0 && ppmCO < 4.4){
            aqiCO =  ((((50 - 0)/(4.4 - 0)) * (ppmCO - 0)) + 0);
        }
        else if (ppmCO >= 4.4 && ppmCO < 9.4){
            aqiCO =  ((((100 - 50)/(9.4 - 4.4)) * (ppmCO - 4.4)) + 50);
        }
        else if (ppmCO >= 9.4 && ppmCO < 12.4){
            aqiCO =  ((((150 - 100)/(12.4 - 9.4)) * (ppmCO - 9.4)) + 100);
        }
        else if (ppmCO >= 12.4 && ppmCO <15.4){
            aqiCO =  ((((200 - 150)/(15.4 - 12.4)) * (ppmCO - 12.4)) + 150);
        }
        else if (ppmCO >= 15.4 && ppmCO < 30.4){
            aqiCO =  ((((300 - 200)/(30.4 - 15.4)) * (ppmCO - 15.4)) + 200);
        }
        else if (ppmCO >= 30.4 && ppmCO < 40.4){
            aqiCO =  ((((400 - 300)/(40.4 - 30.4)) * (ppmCO - 30.4)) + 300);
        }
        else if (ppmCO >= 40.4 && ppmCO < 50.4){
            aqiCO =  ((((500 - 400)/(50.4 - 40.4)) * (ppmCO - 40.4)) + 400);
        }
        else if (ppmCO >= 50.4){
            aqiCO = 500;
        }



        double ppbO3Double = (double) ppbO3;
        if (ppbO3 >= 0 && ppbO3 < 60){
            aqiO3 =  ((0.833 * (ppbO3Double - 0)) + 0);
        }
        else if (ppbO3 >= 60 && ppbO3 < 125){
            aqiO3 =  ((0.77 * (ppbO3Double - 60)) + 50);
        }
        else if (ppbO3 >= 125 && ppbO3 < 164){
            aqiO3 =  ((1.28 * (ppbO3Double - 125)) + 100);
        }
        else if (ppbO3 >= 164 && ppbO3 < 204){
            aqiO3 =  ((1.25 * (ppbO3Double - 164)) + 150);
        }
        else if (ppbO3 >= 204 && ppbO3 < 404){
            aqiO3 =  ((0.5 * (ppbO3Double - 204)) + 200);
        }
        else if (ppbO3 >= 404 && ppbO3 < 504){
            aqiO3 =  ((( ppbO3Double - 404)) + 300);
        }
        else if (ppbO3 >= 504 && ppbO3 < 604){
            aqiO3 =  (((ppbO3Double - 504)) + 400);
        }
        else if (ppbO3 >= 604){
            aqiO3 = 500;
        }

        if (aqiCO > aqiO3){
            aqi = (int) aqiCO;
        }
        else if (aqiCO< aqiO3){
            aqi = (int) aqiO3;
        }
        else {
            aqi = (int) aqiCO;
        }


        return aqi;
    }



    public void callAPI (){
        if (latitude == 0.0 || longitude == 0.0) {

        }
        else{   //only called if location is known
            SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:hh:mm:ss");    //can only be called once per hour or per app restart
            String today = s.format(new Date());
            Date todayDate;
            long todayMillis = 0;
            try {
                todayDate = s.parse(today);
                todayMillis = todayDate.getTime();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long currentDateLong = Long.parseLong(currentDate);

            if (todayMillis-currentDateLong >= 18000000) {  //5 hours or more has past
                fetchData process = new fetchData();
                process.execute();
                SimpleDateFormat s2 = new SimpleDateFormat("hh:mm aa");
                apiCallTime = s2.format(new Date());
                currentDate = todayMillis+"";
            }

        }

    }

    public void displayAPIValue (){



        int apiValue = 1;
        if (!apiCallValue.equals("")){
            apiValue = Integer.parseInt(apiCallValue);
        }



        if (apiValue > 300){
            frameLayout4.setBackground(darkRedRectangle);
        }
        else if (apiValue > 100){
            frameLayout4.setBackground(redRectangle);
        }
        else if (apiValue > 50){
            frameLayout4.setBackground(yellowRectangle);
        }
        else if (apiValue >= 0){
            frameLayout4.setBackground(greenRectangle);
        }


        if(apiCallValue.equals("") || apiCallLocation.equals("")){
            messageTextView.setText("Location or Airnow.gov is currently unavailable");   //moved to startSingleRead
            frameLayout4.setBackground(blueRectangle);

        }
        else{

            messageTextView.setText("Air quality index for "+apiCallLocation+" is "+apiCallValue+" ("+apiLevel+")\nPrimary pollutant is "+apiMajorPollutant+"\nLast update: "+apiCallTime+" (from airnow.gov)");
        }

    }

    public void loadSensitivitySettings(){
        SharedPreferences sharedPrefDefault = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        sensitivityModeSetting = sharedPrefDefault.getString("sensitivity mode","");
        if (sensitivityModeSetting.equals("very sensitive")){   //removed from settings, no longer selectable
            moderateCO = 5;
            unhealthyCO = 9;
            hazardousCO = 15;

            moderateO3 = 25;
            unhealthyO3 = 50;
            hazardousO3 = 100;

            moderateAQI = 20;
            unhealthyAQI = 50;
            hazardousAQI = 100;
        }
        else if (sensitivityModeSetting.equals("sensitive")){
            moderateCO = 9;
            unhealthyCO = 15;
            hazardousCO = 25;

            moderateO3 = 50;
            unhealthyO3 = 75;
            hazardousO3 = 200;

            moderateAQI = 30;
            unhealthyAQI = 80;
            hazardousAQI = 150;
        }
        else if (sensitivityModeSetting.equals("normal") || sensitivityModeSetting.equals("")){
            moderateCO = 15;
            unhealthyCO = 35;
            hazardousCO = 70;

            moderateO3 = 75;
            unhealthyO3 = 96;
            hazardousO3 = 400;

            moderateAQI = 50;
            unhealthyAQI = 150;
            hazardousAQI = 250;
        }
        else if (sensitivityModeSetting.equals("home alert")){
            moderateCO = 30;
            unhealthyCO = 70;
            hazardousCO = 150;

            moderateO3 = 150;
            unhealthyO3 = 200;
            hazardousO3 = 800;

            moderateAQI = 100;
            unhealthyAQI = 300;
            hazardousAQI = 500;
        }
        else if (sensitivityModeSetting.equals("custom")){

            String yellowEditText = sharedPrefDefault.getString("customCOYellow","15");
            String redEditText = sharedPrefDefault.getString("customCORed","35");
            String maroonEditText = sharedPrefDefault.getString("customCOMaroon","70");


            try {
                moderateCO = Integer.parseInt(yellowEditText);
                unhealthyCO = Integer.parseInt(redEditText);
                hazardousCO = Integer.parseInt(maroonEditText);
            }catch (NumberFormatException e){
                moderateCO = 15;
                unhealthyCO = 35;
                hazardousCO = 70;
            }

            if (moderateCO > 50){
                moderateCO = 50;
            }
            if(unhealthyCO > 200){
                unhealthyCO = 200;
            }
            if(hazardousCO > 400){
                hazardousCO = 400;
            }

            /*String[] yellowEditTextArray = yellowEditText.split(",");
            String[] redEditTextArray = redEditText.split(",");
            String[] maroonEditTextArray = maroonEditText.split(",");

            if(yellowEditTextArray.length != 3 || redEditTextArray.length != 3 || maroonEditTextArray.length != 3){ //if number of params do not match, then set to default

                yellowEditTextArray = new String[3];
                redEditTextArray = new String[3];
                maroonEditTextArray = new String[3];

                yellowEditTextArray[0] = "15";
                yellowEditTextArray[1] = "75";
                yellowEditTextArray[2] = "50";
                redEditTextArray[0] = "35";
                redEditTextArray[1] = "96";
                redEditTextArray[2] = "150";
                maroonEditTextArray[0] = "70";
                maroonEditTextArray[1] = "400";
                maroonEditTextArray[2] = "250";
            }

            try {
                int yellow0 = Integer.parseInt(yellowEditTextArray[0].trim());
                int yellow1 = Integer.parseInt(yellowEditTextArray[1].trim());
                int yellow2 = Integer.parseInt(yellowEditTextArray[2].trim());
                int red0 = Integer.parseInt(redEditTextArray[0].trim());
                int red1 = Integer.parseInt(redEditTextArray[1].trim());
                int red2 = Integer.parseInt(redEditTextArray[2].trim());
                int maroon0 = Integer.parseInt(maroonEditTextArray[0].trim());
                int maroon1 = Integer.parseInt(maroonEditTextArray[1].trim());
                int maroon2 = Integer.parseInt(maroonEditTextArray[2].trim());
            }
            catch(NumberFormatException e){
                yellowEditTextArray[0] = "15";
                yellowEditTextArray[1] = "75";
                yellowEditTextArray[2] = "50";
                redEditTextArray[0] = "35";
                redEditTextArray[1] = "96";
                redEditTextArray[2] = "150";
                maroonEditTextArray[0] = "70";
                maroonEditTextArray[1] = "400";
                maroonEditTextArray[2] = "250";
            }


            moderateCO = Integer.parseInt(yellowEditTextArray[0].trim());
            unhealthyCO = Integer.parseInt(redEditTextArray[0].trim());
            hazardousCO = Integer.parseInt(maroonEditTextArray[0].trim());

            moderateO3 = Integer.parseInt(yellowEditTextArray[1].trim());
            unhealthyO3 = Integer.parseInt(redEditTextArray[1].trim());
            hazardousO3 = Integer.parseInt(maroonEditTextArray[1].trim());

            moderateAQI = Integer.parseInt(yellowEditTextArray[2].trim());
            unhealthyAQI = Integer.parseInt(redEditTextArray[2].trim());
            hazardousAQI = Integer.parseInt(maroonEditTextArray[2].trim());*/
        }
    }

    public void loadLogSettings(){
        SharedPreferences sharedPrefDefault = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String lograte = sharedPrefDefault.getString("log rate","");

        if(lograte.equals("1 sec")){
            logRate = 1;
        }
        else if(lograte.equals("10 sec")|| lograte.equals("")){     //default

            logRate = 10;
        }
        else if (lograte.equals("1 min")){
            logRate = 60;
        }
        else if (lograte.equals("10 min")){
            logRate = 600;
        }
        else if (lograte.equals("1 hour")){
            logRate = 3600;
        }
        else if (lograte.equals("1 day")){
            logRate = 86400;
        }
    }

    public void loadSettings (){




        SharedPreferences sharedPrefDefault = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        temperatureUnitSetting = sharedPrefDefault.getString("temperature unit", "C"); //used in getTemp

        loadLogSettings();

        loadSensitivitySettings();

        autoReconnectSetting = sharedPrefDefault.getBoolean("auto reconnect",true);

        mainDisplaySetting = sharedPrefDefault.getString("main display", "CO");

        concentrationUnitCO = sharedPrefDefault.getString("CO concentration unit","ppm CO");
        if (!concentrationUnitCO.equals("ppm CO")){
            SpannableStringBuilder cs = new SpannableStringBuilder("\nmg/m3 CO");
            cs.setSpan(new SuperscriptSpan(),5, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            cs.setSpan(new RelativeSizeSpan(0.75f), 5, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            if(mainDisplaySetting.equals("CO")){
                units1TextView.setText(cs);
                //units2TextView.setText("\nAQI");
            }
            else if (mainDisplaySetting.equals("AQI")){
                units1TextView.setText("\nAQI");
                //units2TextView.setText(cs);
            }

        }
        else if (concentrationUnitCO.equals("ppm CO")){
            if(mainDisplaySetting.equals("CO")){
                units1TextView.setText("\n"+concentrationUnitCO);
                //units2TextView.setText("\nAQI");
            }
            else if (mainDisplaySetting.equals("AQI")){
                units1TextView.setText("\nAQI");
                //units2TextView.setText("\n"+concentrationUnitCO);
            }
        }

        concentrationUnitO3 = sharedPrefDefault.getString("O3 concentration unit", "ppb O3");
        if (!concentrationUnitO3.equals("ppb O3")){
            SpannableStringBuilder cs = new SpannableStringBuilder("\nμg/m3 O3");
            cs.setSpan(new SuperscriptSpan(),5, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            cs.setSpan(new RelativeSizeSpan(0.75f), 5, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            units3TextView.setText(cs);
        }
        else if (concentrationUnitO3.equals("ppb O3")){
            units3TextView.setText("\n"+concentrationUnitO3);
        }

        enableEmergencyContact1 = sharedPrefDefault.getBoolean("enable emergency contact 1", false);
        enableEmergencyContact2 = sharedPrefDefault.getBoolean("enable emergency contact 2", false);
        emergencyContactNumber1 = sharedPrefDefault.getString("emergency contact cell number 1", "");
        emergencyContactNumber2 = sharedPrefDefault.getString("emergency contact cell number 2", "");


        userName = sharedPrefDefault.getString("my name", "");
        userGender = sharedPrefDefault.getString("gender", "");

        enableAlertsAlways = sharedPrefDefault.getBoolean("alwaysTrackAlert",false);


        showTWA = sharedPrefDefault.getBoolean("time weighted average", false);

        TWAalert = sharedPrefDefault.getBoolean("enable TWA alerts", false);

        TWAVoiceAlert = sharedPrefDefault.getBoolean("enable TWA voice alerts", false);

        disconnectVibrateSetting = sharedPrefDefault.getBoolean("vibrate disconnect", true);   //check onDestroy() method

        alertSpeakSettings = sharedPrefDefault.getBoolean("voice alerts", true);    //used in vibrateUnhealthy and vibrateHazardous

        alertVibrateSetting = sharedPrefDefault.getBoolean("vibrate alerts",true); //used in vibrateUnhealthy and vibrateHazardous


        if (sensitivityModeSetting.equals("very sensitive")){
            uartSendData("15000", false);
            //might need deley here
            uartSendData("29000", false);
            //might need delay here
            uartSendData("315000", false);
            //
            //uartSendData("e", false);
        }
        if (sensitivityModeSetting.equals("sensitive")){
            uartSendData("19000", false);
            uartSendData("215000", false);
            uartSendData("325000", false);
            //uartSendData("e", false);
        }
        if (sensitivityModeSetting.equals("normal")||sensitivityModeSetting.equals("")){
            uartSendData("115000", false);
            uartSendData("235000", false);
            uartSendData("370000", false);
            //uartSendData("e", false);
        }
        if (sensitivityModeSetting.equals("home alert")){
            uartSendData("130000", false);
            uartSendData("270000", false);
            uartSendData("3150000", false);
            //uartSendData("e", false);
        }
        if (sensitivityModeSetting.equals("custom")){
            uartSendData("1"+moderateCO+"000", false);
            uartSendData("2"+unhealthyCO+"000", false);
            uartSendData("3"+hazardousCO+"000", false);
            //uartSendData("e", false);
        }
    }

    public double getTemp (double tempC){
        double tempReturn =0.0;
        if(temperatureUnitSetting.equals("C") || temperatureUnitSetting.equals("")){
            tempReturn = tempC;
        }
        else if (temperatureUnitSetting.equals("F")){
            tempReturn = (tempC * 1.8) + 32;
        }
        return tempReturn;
    }

    public void speak (String word){
        mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null);

        //mTTS.stop();
        //mTTS.shutdown();
    }

    public void vibrate1000 (){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            vibrator.vibrate(1000);
        }


    }

    public void vibrateUnhealthy (){
        if (alertVibrateSetting){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                //deprecated in API 26
                vibrator.vibrate(500);
            }
        }

        if (alertSpeakSettings){
            speak("warning");
        }


    }

    public void vibrateHazardous (){
        if (alertVibrateSetting){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                //deprecated in API 26
                vibrator.vibrate(1000);
            }
        }

        if(alertSpeakSettings){
            speak("danger");
        }



    }

    public static String getDate(long milliSeconds)
    {
        // Create a DateFormatter object for displaying date in specified format.

        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss.SS");

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return s.format(calendar.getTime());
    }

    public static String getHour(long milliSeconds)
    {
        // Create a DateFormatter object for displaying date in specified format.

        SimpleDateFormat s = new SimpleDateFormat("hh:mm:ss");

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return s.format(calendar.getTime());
    }

    private void recordFromSparrowLog (){
        uartSendData("l",false);


        //long maxSparrowLogTime = 604800000; //for 1 week
        //long maxSparrowLogTime = (long) maxNumberOfLines*sparrowLogRate; //for 12 hours


        SharedPreferences sharedPrefLastRecieve = getSharedPreferences("last receive",0);
        //timeOnDisconnect = sharedPrefLastRecieve.getLong("time on disconnect",currentTimeMillis - maxSparrowRecordingTime) + 60000;   //default value is 1 week ago, add 1 minute due to 1 min delay from starting log





        //int sparrowLogRate = 16000;
        //int sparrowLogRate = 1000;      //milliseconds inbetween sparrow log

        long totalTransferTime = 2000000;     // total transfer time for a full log in milliseconds, found experimentally, based on deley between lines, currently 50 ms
        double numberOfLines = lines;
        double percentOfTotalTime = numberOfLines/maxNumberOfLines;
        double timeNeeded = percentOfTotalTime*totalTransferTime;
        long timeAtCompletion = System.currentTimeMillis() + (long)timeNeeded;  //issue when on new firmware
        messageTextView.setText("APP IS DOWNLOADING SPARROW LOG.\n DO NOT DISCONNECT.\n Finished at around "+getHour(timeAtCompletion));

        Intent intent = new Intent(UartActivity.this, UartActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(UartActivity.this, 0, intent, 0);

        Notification notification1 =  new NotificationCompat.Builder(UartActivity.this, CHANNEL_2_ID)
                .setSmallIcon(R.drawable.sparrow_status_bar)
                .setContentTitle("Download in progress")
                .setContentText("Log is downloading from device, eta: "+getHour(timeAtCompletion))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(pendingIntent)
                .setTimeoutAfter((long) timeNeeded)   //delete notifcation after the max possible download time, in case of force close during this time
                .build();
        notificationManager.notify(1,notification1);

    }

    public void createAlert (int value){

        int alertLogRate = 10000;
        if (enableAlertsAlways){
            alertLogRate = 60000;
        }


        if(latitude == 0.0 || longitude == 0.0){        //Only add to Alert file if gps is availible
        }
        else{

            //only create once every 10 seconds

            if (currentTimeMillis - timeSinceLastAlert >= alertLogRate){
                String location = getLocation(latitude, longitude);

                SimpleDateFormat s = new SimpleDateFormat("MMM dd, hh:mm:ss aa");
                String format = s.format(new Date());
                //format = format.substring(0,22);    //remove extra digits of milliseconds from tablet phones
                if (location.equals("")){   //unable to retrieve address
                    location = "?, ?, ?, ?";
                }
                String latString = latitude+"";
                String longString = longitude+"";
                if(latString.length()>9){
                    latString = latString.substring(0,9);
                }

                if(longString.length()>8){
                    longString = longString.substring(0,9);
                }

                writeToAlertFile(format.trim() + ", " + latString + ", " + longString + ", " + location + ", CO = " + value + " ppm\n");
                //writeToAlertFileThread(format.trim() + ", " + latitude + ", " + longitude + ", " + location + ", AQI = " + AQI + "\n");

                timeSinceLastAlert = System.currentTimeMillis();
            }


        }
    }

    private void createNotificationChannels(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel1 = new NotificationChannel(CHANNEL_1_ID, "Disconnect Notification", NotificationManager.IMPORTANCE_HIGH);
            channel1.setDescription("Notification and vibration will occur when SPARROW disconnects from the App.");

            NotificationChannel channel2 = new NotificationChannel(CHANNEL_2_ID, "Connection status", NotificationManager.IMPORTANCE_LOW);
            channel2.setDescription("Notification to track current AQI.");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel2);
            manager.createNotificationChannel(channel1);
        }

    }

    private void calculateTWA15minutes (double COppm){
        COppmTWA15MinutesCounter++;
        if (COppmTWA15MinutesCounter <= 900){
            COppmTWA15MinutesList.add(COppm);
            COppmTWA15MinutesAmount = COppmTWA15MinutesAmount + COppm;
        }

        if(COppmTWA15MinutesCounter > 900){

            COppmTWA15MinutesList.add(COppm);

            COppmTWA15MinutesAmount = COppmTWA15MinutesAmount + (double)COppm - (double)COppmTWA15MinutesList.get(0);

            COppmTWA15MinutesList.remove(0);

            COppmTWA15Minutes = COppmTWA15MinutesAmount/900.0;


        }

        if (COppmTWA15Minutes > 50){
            speak("warning");
            messageTextView.setText("You have been exposed to over 50 ppm of CO for over 15 minutes. Please seek fresh air");
        }

    }

    private void calculateTWA8Hours (double COppm){
        COppmTWA8HoursCounter++;
        if (COppmTWA8HoursCounter <= 28800){
            COppmTWA8HoursList.add(COppm);
            COppmTWA8HoursAmount = COppmTWA8HoursAmount + COppm;
        }

        if(COppmTWA8HoursCounter > 28800){

            COppmTWA8HoursList.add(COppm);

            COppmTWA8HoursAmount = COppmTWA8HoursAmount + (double)COppm - (double)COppmTWA8HoursList.get(0);

            COppmTWA8HoursList.remove(0);

            COppmTWA8Hours = COppmTWA8HoursAmount/28800.0;

        }

    }

    private void calculateTWA24Hours (double COppm){
        COppmTWA24HoursCounter++;
        if (COppmTWA24HoursCounter <= 86400){
            COppmTWA24HoursList.add(COppm);
            COppmTWA24HoursAmount = COppmTWA24HoursAmount + COppm;
        }

        if(COppmTWA24HoursCounter > 86400){

            COppmTWA24HoursList.add(COppm);

            COppmTWA24HoursAmount = COppmTWA24HoursAmount + (double)COppm - (double)COppmTWA24HoursList.get(0);

            COppmTWA24HoursList.remove(0);

            COppmTWA24Hours = COppmTWA24HoursAmount/86400.0;

        }

    }

    private void TWAalert (){
        //need to add alert, either vibration, sound or both when certain thresholds have been met
        //also need sound alerts
        if(TWAalert) {  //preference checked
            if (COppmTWA15Minutes > 50) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    //deprecated in API 26
                    vibrator.vibrate(1000);
                }

            }

            if (COppmTWA8Hours > 30) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    //deprecated in API 26
                    vibrator.vibrate(1000);
                }
            }

            if (COppmTWA24Hours > 20) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    //deprecated in API 26
                    vibrator.vibrate(1000);
                }
            }
        }

        if (TWAVoiceAlert){
            if (COppmTWA15Minutes > 50) {
                speak("danger");
            }

            if (COppmTWA8Hours > 30) {
                speak("danger");
            }

            if (COppmTWA24Hours > 20) {
                speak("danger");
            }

        }
    }

    private void showTWA(){

        //String TWA15Minutes = COppmTWA15Minutes+"";
        //String TWA8Hours = COppmTWA8Hours+"";
        //String TWA24Hours = COppmTWA24Hours+"";

        TWA15Minutes = String.format("%.3f", COppmTWA15Minutes);
        TWA8Hours = String.format("%.3f", COppmTWA8Hours);
        TWA24Hours = String.format("%.3f", COppmTWA24Hours);

        if (COppmTWA15MinutesCounter<900){
            TWA15Minutes = "not yet available ("+(900 - COppmTWA15MinutesCounter)+")";
        }
        else{
            TWA15Minutes = TWA15Minutes+" ppm CO";
        }

        if (COppmTWA8HoursCounter<28800){
            TWA8Hours = "not yet available ("+(28800 - COppmTWA8HoursCounter)+")";
        }
        else{
            TWA8Hours = TWA8Hours + " ppm CO";
        }

        if (COppmTWA24HoursCounter<86400){
            TWA24Hours = "not yet available ("+(86400 - COppmTWA24HoursCounter)+")";
        }
        else{
            TWA24Hours = TWA24Hours + " ppm CO";
        }



        if (showTWA){

            TWATextView.setText("15 minute TWA= "+TWA15Minutes+"\n8 hour TWA= "+ TWA8Hours+"\n24 hour TWA= "+TWA24Hours);
            //Toast.makeText(this,"15 minute TWA= "+TWA15Minutes+"\n8 hour TWA= "+ TWA8Hours+"\n24 hour TWA= "+TWA24Hours,Toast.LENGTH_SHORT).show();
        }
        else{
            TWATextView.setText("");
        }
    }

    public void sendTextAlert(){

        //need method to prevent spamming of messages

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this,"SMS is not enabled",Toast.LENGTH_SHORT).show();
        }
        else{

            if (currentTimeMillis-timeSinceLastText >= 300000){ //over 5 minutes have past since last text, ok to send again
                SmsManager smsManager = SmsManager.getDefault();

                String message = "SPARROW App Alert: "+userName+" was just exposed to very high levels of CO ("+currentCOppm+" ppm). Last known location: "+ getLocation(latitude, longitude) ;

                if (enableEmergencyContact1 && emergencyContactNumber1.length() == 10){
                    smsManager.sendTextMessage(emergencyContactNumber1, null, message, null, null);
                    timeSinceLastText = System.currentTimeMillis();
                }

                if (enableEmergencyContact2 && emergencyContactNumber2.length() == 10){
                    smsManager.sendTextMessage(emergencyContactNumber2, null, message, null, null);
                    timeSinceLastText = System.currentTimeMillis();
                }




            }




            //smsManager.sendTextMessage("4157346486", null, message, null, null);


        }






        /*SmsManager smsManager = SmsManager.getDefault();
        String pronoun = "";

        if (userGender.equals("Male")){
            pronoun = "His";
        }
        else if (userGender.equals("Female")){
            pronoun = "Her";
        }

        String message = "This is an automated message. "+userName+" has set you as their emergency contact. "+userName+" has just been exposed to dangerous levels of Carbon Monoxide. "+pronoun+" last known location is "+ getLocation(latitude, longitude) ;
        smsManager.sendTextMessage("+14157346486", null, message, null, null);*/
    }

    @Override
    public void onBackPressed(){
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle("Close home page")
                .setMessage("Are you sure you want to close the home page and return to the connect screen?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do something
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();

        //super.onBackPressed();
    }

    // endregion
}