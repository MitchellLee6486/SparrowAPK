package com.adafruit.bluefruit.le.sparrow.app;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class fetchData extends AsyncTask<Void,Void,Void>{

    String data = "";

    String AQI = "";
    String location = "";
    String level = "";
    String majorPollutant = "";

    @Override
    protected Void doInBackground(Void... voids) {
        String urlString = "http://www.airnowapi.org/aq/forecast/latLong/?format=application/json&latitude="+UartActivity.latitude+"&longitude="+UartActivity.longitude+"&date=&distance=25&API_KEY=6321086E-4F05-434E-983B-E2195DE9C86E";



        try {
            URL url = new URL(urlString);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while(line !=  null){
                line = bufferedReader.readLine();
                data = data+line;
            }

            try {
                JSONArray jsonArray = new JSONArray(data);

                    JSONObject jsonObject = (JSONObject) jsonArray.get(0);      //only need data for current day
                    AQI = jsonObject.get("AQI")+"";
                    location = jsonObject.get("ReportingArea")+"";
                    majorPollutant = jsonObject.get("ParameterName")+"";
                    JSONObject jsonCategory = (JSONObject) jsonObject.get("Category");
                    level = jsonCategory.get("Name")+"";
                    //dataParsed = dataParsed + singleParsed;

            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        if (AQI.equals("") || AQI.equals("-1")) {

        }
        else{
            UartActivity.apiCallValue = this.AQI;  //updates value in uartactivty
            UartActivity.apiCallLocation = this.location;
            UartActivity.apiMajorPollutant = this.majorPollutant;
            UartActivity.apiLevel = this.level;
        }
    }
}
