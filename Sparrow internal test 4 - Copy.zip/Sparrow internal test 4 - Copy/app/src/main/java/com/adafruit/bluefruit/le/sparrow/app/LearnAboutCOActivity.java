package com.adafruit.bluefruit.le.sparrow.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LearnAboutCOActivity extends AppCompatActivity {


    private Button showFAQBtn, faq1Btn, faq2Btn, faq3Btn, faq4Btn, faq5Btn, faq6Btn, faq7Btn, faq8Btn, faq9Btn, faq10Btn;
    private Button showHowToUseBtn, how1Btn, how2Btn, how3Btn, how4Btn, how5Btn, how6Btn, how7Btn, how8Btn, how9Btn, how10Btn, how11Btn, how12Btn, how13Btn, how14Btn;
    private Button showTableBtn;
    private ImageView table1ImageView, table2ImageView, table3ImageView;
    private TextView table1TextView, table2TextView, table3TextView;
    private Button funURLBtn, epaURLBtn, nioshURLBtn, oshaURLBtn, sparrowURLBtn, specURLBtn, kwjURLBtn, detectCOURLBtn;
    private TextView faq1TextView, faq2TextView, faq3TextView, faq4TextView, faq5TextView, faq6TextView, faq7TextView, faq8TextView, faq9TextView, faq10TextView;
    private TextView how1TextView, how2TextView, how3TextView, how4TextView, how5TextView, how6TextView, how7TextView, how8TextView, how9TextView, how10TextView, how11TextView, how12TextView, how13TextView, how14TextView;
    private TextView currentCOTextView, currentRHTextView, currentTempTextView, TWA15minuteTextView, TWA8hourTextView, TWA24hourTextView;
    private TextView coDescriptiontextview, rhDescriptiontextView, tempDescriptiontextView;
    private Runnable runnable;

    private int count = 0;

    public static String currentCOppm, currentRH, currentTemp, COppmTWA15Minutes, COppmTWA8Hours, COppmTWA24Hours;


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_other, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        final int id = item.getItemId();

        switch (id) {

            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            case R.id.accountSettings:
                Intent accountSettingsIntent = new Intent(getApplicationContext(), AccountSettingsActivity.class);
                startActivity(accountSettingsIntent);
                break;

            case R.id.mySparrowSettings:
                Intent mySparrowSettingsIntent = new Intent(getApplicationContext(),MySparrowSettingsActivity.class);
                startActivity(mySparrowSettingsIntent);
                break;

            case R.id.preferencesSettings:
                //Intent preferencesIntent = new Intent(getApplicationContext(),PreferencesSettingsActivity.class);
                Intent preferencesIntent = new Intent(getApplicationContext(),SettingsActivity.class);
                startActivity(preferencesIntent);

                break;


            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@



        }

        return super.onOptionsItemSelected(item);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn_about_co);

        getSupportActionBar().setSubtitle(" Learn More");
        getSupportActionBar().setTitle(" SPARROW");
        getSupportActionBar().setLogo(R.mipmap.sparrow_icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(3);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavViewBar);

        Menu bottomMenu = bottomNavigationView.getMenu();
        MenuItem bottomMenuItem = bottomMenu.getItem(3);
        bottomMenuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.homeBarBtn:
                        Intent intent1 = new Intent(LearnAboutCOActivity.this, UartActivity.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent1);
                        LearnAboutCOActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.myDataBarBtn:
                        Intent intent2 = new Intent(LearnAboutCOActivity.this    , GraphActivity.class);
                        intent2.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent2);
                        LearnAboutCOActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.myAlertBarBtn:
                        Intent intent3 = new Intent(LearnAboutCOActivity.this    , AlertHistoryActivity.class);
                        intent3.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent3);
                        LearnAboutCOActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.learnMoreBarBtn:

                        break;
                }



                return false;
            }
        });


        currentCOTextView = findViewById(R.id.currentCOTextView);
        currentRHTextView = findViewById(R.id.currentRHTextView);
        currentTempTextView = findViewById(R.id.currentTempTextView);
        TWA15minuteTextView = findViewById(R.id.TWA15minTextView);
        TWA8hourTextView = findViewById(R.id.TWA8hourTextView);
        TWA24hourTextView = findViewById(R.id.TWA24hourTextView);

        coDescriptiontextview = findViewById(R.id.coDescriptionTextView);
        rhDescriptiontextView = findViewById(R.id.rhDescriptionTextView);
        tempDescriptiontextView = findViewById(R.id.tempDescriptionTextView);

        table1ImageView = findViewById(R.id.table1ImageView);
        table1ImageView.setVisibility(View.GONE);
        table1TextView = findViewById(R.id.table1TextView);
        table1TextView.setVisibility(View.GONE);

        table2ImageView = findViewById(R.id.table2ImageView);
        table2ImageView.setVisibility(View.GONE);
        table2TextView = findViewById(R.id.table2TextView);
        table2TextView.setVisibility(View.GONE);

        table3ImageView = findViewById(R.id.table3ImageView);
        table3ImageView.setVisibility(View.GONE);
        table3TextView = findViewById(R.id.table3TextView);
        table3TextView.setVisibility(View.GONE);

        setTextViewHTML(table1TextView, "Read more on CO exposure guidelines from " +
                "<a href=\"http://www.inchem.org/documents/ehc/ehc/ehc213.htm\">WHO</a> "+
                ", "+"<a href=\"https://www.epa.gov/co-pollution/table-historical-carbon-monoxide-co-national-ambient-air-quality-standards-naaqs\">EPA</a> "
                +", "+ "<a href=\"https://www.ncbi.nlm.nih.gov/books/NBK220012/\">AEGL</a> "+"(Acute Exposure Guideline Levels)");

        setTextViewHTML(table2TextView, "Read more on CO occupational exposure guidelines for " +
                "<a href=\"https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=CELEX:32017L0164\">EU Commission</a> "+
                "\n\rRead more on CO occupational exposure guidelines for ACGIH, NIOSH, & OSHA at the "
                +"<a href=\"https://www.epa.gov/indoor-air-quality-iaq/carbon-monoxides-impact-indoor-air-quality\">EPA Website on Indoor Air Quality</a> "
                +"\n\rLink to "+ "<a href=\"https://www.ncbi.nlm.nih.gov/books/NBK220012/\">AEGL</a> "+"(Acute Exposure Guideline Levels)");

        setTextViewHTML(table3TextView, "Read more on " + "<a href=\"https://www.ncbi.nlm.nih.gov/books/NBK220012/\">AEGL</a> "
                +": Acute Exposure Guideline Levels for Selected Airborne Chemicals");



        showTableBtn = findViewById(R.id.showTableBtn);
        showTableBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (showTableBtn.getText().equals("Show")){
                    showTableBtn.setText("Hide");
                    table1ImageView.setVisibility(View.VISIBLE);
                    table1TextView.setVisibility(View.VISIBLE);
                    table2ImageView.setVisibility(View.VISIBLE);
                    table2TextView.setVisibility(View.VISIBLE);
                    table3ImageView.setVisibility(View.VISIBLE);
                    table3TextView.setVisibility(View.VISIBLE);
                }
                else if (showTableBtn.getText().equals("Hide")){
                    showTableBtn.setText("Show");
                    table1ImageView.setVisibility(View.GONE);
                    table1TextView.setVisibility(View.GONE);
                    table2ImageView.setVisibility(View.GONE);
                    table2TextView.setVisibility(View.GONE);
                    table3ImageView.setVisibility(View.GONE);
                    table3TextView.setVisibility(View.GONE);
                }

            }
        });


        showFAQBtn = findViewById(R.id.showFAQBtn);
        showFAQBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (showFAQBtn.getText().equals("Show")){
                    showFAQBtn.setText("Hide");
                    faq1Btn.setVisibility(View.VISIBLE);
                    faq2Btn.setVisibility(View.VISIBLE);
                    faq3Btn.setVisibility(View.VISIBLE);
                    faq4Btn.setVisibility(View.VISIBLE);
                    faq5Btn.setVisibility(View.VISIBLE);
                    faq6Btn.setVisibility(View.VISIBLE);
                    faq7Btn.setVisibility(View.VISIBLE);
                    faq8Btn.setVisibility(View.VISIBLE);
                    faq9Btn.setVisibility(View.VISIBLE);
                    faq10Btn.setVisibility(View.VISIBLE);

                }
                else if (showFAQBtn.getText().equals("Hide")){
                    showFAQBtn.setText("Show");
                    faq1Btn.setVisibility(View.GONE);
                    faq2Btn.setVisibility(View.GONE);
                    faq3Btn.setVisibility(View.GONE);
                    faq4Btn.setVisibility(View.GONE);
                    faq5Btn.setVisibility(View.GONE);
                    faq6Btn.setVisibility(View.GONE);
                    faq7Btn.setVisibility(View.GONE);
                    faq8Btn.setVisibility(View.GONE);
                    faq9Btn.setVisibility(View.GONE);
                    faq10Btn.setVisibility(View.GONE);
                    faq1TextView.setVisibility(View.GONE);
                    faq2TextView.setVisibility(View.GONE);
                    faq3TextView.setVisibility(View.GONE);
                    faq4TextView.setVisibility(View.GONE);
                    faq5TextView.setVisibility(View.GONE);
                    faq6TextView.setVisibility(View.GONE);
                    faq7TextView.setVisibility(View.GONE);
                    faq8TextView.setVisibility(View.GONE);
                    faq9TextView.setVisibility(View.GONE);
                    faq10TextView.setVisibility(View.GONE);
                }
            }
        });



        faq1Btn = findViewById(R.id.faq1Btn);
        faq1TextView = findViewById(R.id.faq1TextView);
        faq1Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq1TextView.getVisibility() == View.GONE){
                    faq1TextView.setVisibility(View.VISIBLE);
                }
                else if (faq1TextView.getVisibility() == View.VISIBLE){
                    faq1TextView.setVisibility(View.GONE);
                }

            }
        });

        faq2Btn = findViewById(R.id.faq2Btn);
        faq2TextView = findViewById(R.id.faq2TextView);
        faq2Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq2TextView.getVisibility() == View.GONE){
                    faq2TextView.setVisibility(View.VISIBLE);
                }
                else if (faq2TextView.getVisibility() == View.VISIBLE){
                    faq2TextView.setVisibility(View.GONE);
                }

            }
        });

        faq3Btn = findViewById(R.id.faq3Btn);
        faq3TextView = findViewById(R.id.faq3TextView);
        faq3Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq3TextView.getVisibility() == View.GONE){
                    faq3TextView.setVisibility(View.VISIBLE);
                }
                else if (faq3TextView.getVisibility() == View.VISIBLE){
                    faq3TextView.setVisibility(View.GONE);
                }

            }
        });

        faq4Btn = findViewById(R.id.faq4Btn);
        faq4TextView = findViewById(R.id.faq4TextView);
        faq4Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq4TextView.getVisibility() == View.GONE){
                    faq4TextView.setVisibility(View.VISIBLE);
                }
                else if (faq4TextView.getVisibility() == View.VISIBLE){
                    faq4TextView.setVisibility(View.GONE);
                }

            }
        });

        faq5Btn = findViewById(R.id.faq5Btn);
        faq5TextView = findViewById(R.id.faq5TextView);
        faq5Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq5TextView.getVisibility() == View.GONE){
                    faq5TextView.setVisibility(View.VISIBLE);
                }
                else if (faq5TextView.getVisibility() == View.VISIBLE){
                    faq5TextView.setVisibility(View.GONE);
                }

            }
        });

        faq6Btn = findViewById(R.id.faq6Btn);
        faq6TextView = findViewById(R.id.faq6TextView);
        faq6Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq6TextView.getVisibility() == View.GONE){
                    faq6TextView.setVisibility(View.VISIBLE);
                }
                else if (faq6TextView.getVisibility() == View.VISIBLE){
                    faq6TextView.setVisibility(View.GONE);
                }

            }
        });

        faq7Btn = findViewById(R.id.faq7Btn);
        faq7TextView = findViewById(R.id.faq7TextView);
        faq7Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq7TextView.getVisibility() == View.GONE){
                    faq7TextView.setVisibility(View.VISIBLE);
                }
                else if (faq7TextView.getVisibility() == View.VISIBLE){
                    faq7TextView.setVisibility(View.GONE);
                }

            }
        });

        faq8Btn = findViewById(R.id.faq8Btn);
        faq8TextView = findViewById(R.id.faq8TextView);
        faq8Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq8TextView.getVisibility() == View.GONE){
                    faq8TextView.setVisibility(View.VISIBLE);
                }
                else if (faq8TextView.getVisibility() == View.VISIBLE){
                    faq8TextView.setVisibility(View.GONE);
                }

            }
        });

        faq9Btn = findViewById(R.id.faq9Btn);
        faq9TextView = findViewById(R.id.faq9TextView);
        faq9Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq9TextView.getVisibility() == View.GONE){
                    faq9TextView.setVisibility(View.VISIBLE);
                }
                else if (faq9TextView.getVisibility() == View.VISIBLE){
                    faq9TextView.setVisibility(View.GONE);
                }

            }
        });

        faq10Btn = findViewById(R.id.faq10Btn);
        faq10TextView = findViewById(R.id.faq10TextView);
        faq10Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (faq10TextView.getVisibility() == View.GONE){
                    faq10TextView.setVisibility(View.VISIBLE);
                }
                else if (faq10TextView.getVisibility() == View.VISIBLE){
                    faq10TextView.setVisibility(View.GONE);
                }

            }
        });


        faq1Btn.setVisibility(View.GONE);
        faq2Btn.setVisibility(View.GONE);
        faq3Btn.setVisibility(View.GONE);
        faq4Btn.setVisibility(View.GONE);
        faq5Btn.setVisibility(View.GONE);
        faq6Btn.setVisibility(View.GONE);
        faq7Btn.setVisibility(View.GONE);
        faq8Btn.setVisibility(View.GONE);
        faq9Btn.setVisibility(View.GONE);
        faq10Btn.setVisibility(View.GONE);


        showHowToUseBtn = findViewById(R.id.showHowToUseBtn);
        showHowToUseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (showHowToUseBtn.getText().equals("Show")){
                    showHowToUseBtn.setText("Hide");
                    how1Btn.setVisibility(View.VISIBLE);
                    how2Btn.setVisibility(View.VISIBLE);
                    how3Btn.setVisibility(View.VISIBLE);
                    how4Btn.setVisibility(View.VISIBLE);
                    how5Btn.setVisibility(View.VISIBLE);
                    how6Btn.setVisibility(View.VISIBLE);
                    how7Btn.setVisibility(View.VISIBLE);
                    how8Btn.setVisibility(View.VISIBLE);
                    how9Btn.setVisibility(View.VISIBLE);
                    how10Btn.setVisibility(View.VISIBLE);
                    how11Btn.setVisibility(View.VISIBLE);
                    how12Btn.setVisibility(View.VISIBLE);
                    how13Btn.setVisibility(View.VISIBLE);
                    how14Btn.setVisibility(View.VISIBLE);

                }
                else if (showHowToUseBtn.getText().equals("Hide")){
                    showHowToUseBtn.setText("Show");
                    how1Btn.setVisibility(View.GONE);
                    how2Btn.setVisibility(View.GONE);
                    how3Btn.setVisibility(View.GONE);
                    how4Btn.setVisibility(View.GONE);
                    how5Btn.setVisibility(View.GONE);
                    how6Btn.setVisibility(View.GONE);
                    how7Btn.setVisibility(View.GONE);
                    how8Btn.setVisibility(View.GONE);
                    how9Btn.setVisibility(View.GONE);
                    how10Btn.setVisibility(View.GONE);
                    how11Btn.setVisibility(View.GONE);
                    how12Btn.setVisibility(View.GONE);
                    how13Btn.setVisibility(View.GONE);
                    how14Btn.setVisibility(View.GONE);

                    how1TextView.setVisibility(View.GONE);
                    how2TextView.setVisibility(View.GONE);
                    how3TextView.setVisibility(View.GONE);
                    how4TextView.setVisibility(View.GONE);
                    how5TextView.setVisibility(View.GONE);
                    how6TextView.setVisibility(View.GONE);
                    how7TextView.setVisibility(View.GONE);
                    how8TextView.setVisibility(View.GONE);
                    how9TextView.setVisibility(View.GONE);
                    how10TextView.setVisibility(View.GONE);
                    how11TextView.setVisibility(View.GONE);
                    how12TextView.setVisibility(View.GONE);
                    how13TextView.setVisibility(View.GONE);
                    how14TextView.setVisibility(View.GONE);
                }
            }
        });

        how1Btn = findViewById(R.id.how1Btn);
        how1TextView = findViewById(R.id.how1TextView);
        how1Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how1TextView.getVisibility() == View.GONE){
                    how1TextView.setVisibility(View.VISIBLE);
                }
                else if (how1TextView.getVisibility() == View.VISIBLE){
                    how1TextView.setVisibility(View.GONE);
                }

            }
        });

        how2Btn = findViewById(R.id.how2Btn);
        how2TextView = findViewById(R.id.how2TextView);
        how2Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how2TextView.getVisibility() == View.GONE){
                    how2TextView.setVisibility(View.VISIBLE);
                }
                else if (how2TextView.getVisibility() == View.VISIBLE){
                    how2TextView.setVisibility(View.GONE);
                }

            }
        });

        how3Btn = findViewById(R.id.how3Btn);
        how3TextView = findViewById(R.id.how3TextView);
        how3Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how3TextView.getVisibility() == View.GONE){
                    how3TextView.setVisibility(View.VISIBLE);
                }
                else if (how3TextView.getVisibility() == View.VISIBLE){
                    how3TextView.setVisibility(View.GONE);
                }

            }
        });

        how4Btn = findViewById(R.id.how4Btn);
        how4TextView = findViewById(R.id.how4TextView);
        how4Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how4TextView.getVisibility() == View.GONE){
                    how4TextView.setVisibility(View.VISIBLE);
                }
                else if (how4TextView.getVisibility() == View.VISIBLE){
                    how4TextView.setVisibility(View.GONE);
                }

            }
        });

        how5Btn = findViewById(R.id.how5Btn);
        how5TextView = findViewById(R.id.how5TextView);
        how5Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how5TextView.getVisibility() == View.GONE){
                    how5TextView.setVisibility(View.VISIBLE);
                }
                else if (how5TextView.getVisibility() == View.VISIBLE){
                    how5TextView.setVisibility(View.GONE);
                }

            }
        });

        how6Btn = findViewById(R.id.how6Btn);
        how6TextView = findViewById(R.id.how6TextView);
        how6Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how6TextView.getVisibility() == View.GONE){
                    how6TextView.setVisibility(View.VISIBLE);
                }
                else if (how6TextView.getVisibility() == View.VISIBLE){
                    how6TextView.setVisibility(View.GONE);
                }

            }
        });

        how7Btn = findViewById(R.id.how7Btn);
        how7TextView = findViewById(R.id.how7TextView);
        how7Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how7TextView.getVisibility() == View.GONE){
                    how7TextView.setVisibility(View.VISIBLE);
                }
                else if (how7TextView.getVisibility() == View.VISIBLE){
                    how7TextView.setVisibility(View.GONE);
                }

            }
        });

        how8Btn = findViewById(R.id.how8Btn);
        how8TextView = findViewById(R.id.how8TextView);
        how8Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how8TextView.getVisibility() == View.GONE){
                    how8TextView.setVisibility(View.VISIBLE);
                }
                else if (how8TextView.getVisibility() == View.VISIBLE){
                    how8TextView.setVisibility(View.GONE);
                }

            }
        });

        how9Btn = findViewById(R.id.how9Btn);
        how9TextView = findViewById(R.id.how9TextView);
        how9Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how9TextView.getVisibility() == View.GONE){
                    how9TextView.setVisibility(View.VISIBLE);
                }
                else if (how9TextView.getVisibility() == View.VISIBLE){
                    how9TextView.setVisibility(View.GONE);
                }

            }
        });

        how10Btn = findViewById(R.id.how10Btn);
        how10TextView = findViewById(R.id.how10TextView);
        how10Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how10TextView.getVisibility() == View.GONE){
                    how10TextView.setVisibility(View.VISIBLE);
                }
                else if (how10TextView.getVisibility() == View.VISIBLE){
                    how10TextView.setVisibility(View.GONE);
                }

            }
        });

        how11Btn = findViewById(R.id.how11Btn);
        how11TextView = findViewById(R.id.how11TextView);
        how11Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how11TextView.getVisibility() == View.GONE){
                    how11TextView.setVisibility(View.VISIBLE);
                }
                else if (how11TextView.getVisibility() == View.VISIBLE){
                    how11TextView.setVisibility(View.GONE);
                }

            }
        });

        how12Btn = findViewById(R.id.how12Btn);
        how12TextView = findViewById(R.id.how12TextView);
        how12Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how12TextView.getVisibility() == View.GONE){
                    how12TextView.setVisibility(View.VISIBLE);
                }
                else if (how12TextView.getVisibility() == View.VISIBLE){
                    how12TextView.setVisibility(View.GONE);
                }

            }
        });

        how13Btn = findViewById(R.id.how13Btn);
        how13TextView = findViewById(R.id.how13TextView);
        how13Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how13TextView.getVisibility() == View.GONE){
                    how13TextView.setVisibility(View.VISIBLE);
                }
                else if (how13TextView.getVisibility() == View.VISIBLE){
                    how13TextView.setVisibility(View.GONE);
                }

            }
        });

        how14Btn = findViewById(R.id.how14Btn);
        how14TextView = findViewById(R.id.how14TextView);
        how14Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (how14TextView.getVisibility() == View.GONE){
                    how14TextView.setVisibility(View.VISIBLE);
                }
                else if (how14TextView.getVisibility() == View.VISIBLE){
                    how14TextView.setVisibility(View.GONE);
                }

            }
        });

        how1Btn.setVisibility(View.GONE);
        how2Btn.setVisibility(View.GONE);
        how3Btn.setVisibility(View.GONE);
        how4Btn.setVisibility(View.GONE);
        how5Btn.setVisibility(View.GONE);
        how6Btn.setVisibility(View.GONE);
        how7Btn.setVisibility(View.GONE);
        how8Btn.setVisibility(View.GONE);
        how9Btn.setVisibility(View.GONE);
        how10Btn.setVisibility(View.GONE);
        how11Btn.setVisibility(View.GONE);
        how12Btn.setVisibility(View.GONE);
        how13Btn.setVisibility(View.GONE);
        how14Btn.setVisibility(View.GONE);


        funURLBtn = findViewById(R.id.funURLBtn);
        funURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.sparrowsense.com/sparrow-in-action/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        epaURLBtn = findViewById(R.id.epaURLBtn);
        epaURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.epa.gov/outdoor-air-quality-data");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        nioshURLBtn = findViewById(R.id.nioshURLBtn);
        nioshURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.cdc.gov/niosh/index.htm");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        oshaURLBtn = findViewById(R.id.oshaURLBtn);
        oshaURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.osha.gov/SLTC/indoorairquality/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        sparrowURLBtn = findViewById(R.id.sparrowURLBtn);
        sparrowURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.sparrowsense.com/the-sparrow-app/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        specURLBtn = findViewById(R.id.specURLBtn);
        specURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.spec-sensors.com/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        kwjURLBtn = findViewById(R.id.kwjURLBtn);
        kwjURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.kwjengineering.com/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        detectCOURLBtn = findViewById(R.id.detectCOURLBtn);
        detectCOURLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("https://www.detectcarbonmonoxide.com/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });


        final Handler handler = new Handler();        //Alternate method so that walking out of range does not break the app, forcing a restart
        runnable = new Runnable() {
            @Override
            public void run() {

                count++;

                getData();
                currentCOTextView.setText("Carbon Monoxide: "+currentCOppm+" ppm");
                currentRHTextView.setText("Relative Humidity: "+currentRH+" %");
                currentTempTextView.setText("Temperature: "+currentTemp+" °C");


                    TWA15minuteTextView.setText("15 Minute TWA: "+ COppmTWA15Minutes);



                    TWA8hourTextView.setText("8 Hour TWA: "+ COppmTWA8Hours);



                    TWA24hourTextView.setText("24 Hour TWA: "+ COppmTWA24Hours);





                if (currentCOppm != null && currentRH != null && currentTemp != null){
                    double co = Double.parseDouble(currentCOppm);
                    double rh = Double.parseDouble(currentRH);
                    double temp = Double.parseDouble(currentTemp);
                    updateDescription(co, rh, temp);
                }

                //End of timed loop @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                handler.postDelayed(runnable,1000);
            }
        };
        runnable.run();


    }
    private void getData (){
        getCurrentValues process = new getCurrentValues();
        process.execute();
    }

    private void updateDescription (double COppm, double rh, double temp){

        if (COppm > 70){
            //coDescriptiontextview.setText("Your CO exposure right now is considered hazardous for a normal person. Please evacuate the area as soon as possible.");
            setTextViewHTML(coDescriptiontextview, "Your CO exposure is considered very high! CO exposure at this level is especially harmful. You have a very significant source of CO in your environment. " +
                    "Evacuate the area and seek fresh air. Contact emergency authorities if this level of CO persists. You may experience flu-like symptoms including headaches, drowsiness, nausea. " +
                    "<a href=\"https://www.osha.gov/dts/sltc/methods/inorganic/id209/id209.html\">OSHA standards</a> " +" allow exposure to 200 ppm of CO for only 5 minutes!");
        }
        else if (COppm >34){
            //coDescriptiontextview.setText("Your CO exposure right now is considered unhealthy for a normal person. It is highly recommended to leave the area.");
            setTextViewHTML(coDescriptiontextview, "Your CO exposure is considered high! Prolonged exposure above 35 ppm can lead to negative health effects. There is a significant source " +
                    "of CO in your environment, seek fresh air or contact emergency authorities if your CO source is unkown. You may experience flu-like symptoms including headache, drowsiness, and nausea. " +
                    "Home CO alarms may begin to alarm at 30 ppm, and the "+"<a href=\"https://www.epa.gov/indoor-air-quality-iaq/carbon-monoxides-impact-indoor-air-quality\">NIOSH standard</a> " +
                    "suggests 35 ppm as the acceptable limit for only 8 hours ("+"<a href=\"http://www.euro.who.int/__data/assets/pdf_file/0009/128169/e94535.pdf\">WHO standard</a> "+"suggests 30 " +
                    "ppm for 8 hours).");

        }
        else if (COppm > 14){
            //coDescriptiontextview.setText("Your CO exposure right now is considered moderate for a normal person. It may not be immediatley dangerous but may lead to health issues over time.");
            setTextViewHTML(coDescriptiontextview,"Your CO exposure is considered moderate for a healthy individual. Prolonged exposure to low levels of CO can lead to negative health effects. " +
                    "There is a source of CO in your environment and you may want to seek fresh air. The "+"<a href=\"http://www.euro.who.int/__data/assets/pdf_file/0020/123059/AQG2ndEd_5_5carbonmonoxide.PDF\">WHO standard</a> " +
                    "suggests physical impairment may begin when an individual is exposed to 15-20 ppm of CO for 8 hours.");
        }
        else{
            //coDescriptiontextview.setText("Your CO exposure right now is considered safe for a normal person. You should not need to relocate unless you are extra sensitive towards CO.");
            //coDescriptiontextview.setText(Html.fromHtml("<a href=\"http://www.google.com\">google</a> "));
            //coDescriptiontextview.setMovementMethod(LinkMovementMethod.getInstance());
            //setTextViewHTML(coDescriptiontextview,"<a href=\"http://www.google.com\">click here to go to google</a> ");
            //setTextViewHTML(coDescriptiontextview,"testing "+"<a href=\"https://www.epa.gov/co-pollution/basic-information-about-carbon-monoxide-co-outdoor-air-pollution\">EPA standard</a> ");
            setTextViewHTML(coDescriptiontextview,"Your CO exposure is generally considered safe for a healthy individual. 0 – 3 ppm of CO is a " +
                    "typical reading for your SPARROW. Be alert to rising CO levels and sources of carbon monoxide. Low " +
                    "levels of CO can be especially harmful to sensitive individuals. The "+ "<a href=\"https://www.epa.gov/co-pollution/basic-information-about-carbon-monoxide-co-outdoor-air-pollution\">EPA standard</a> " +" for outdoor air quality " +
                    "suggests 9 ppm as the acceptable limit over an 8-hour time period.");

        }


        if (rh > 75){
            rhDescriptiontextView.setText("Your air is very humid");
        }
        else if (rh >50){
            rhDescriptiontextView.setText("Your air is humid");
        }
        else if (rh > 25){
            rhDescriptiontextView.setText("Your air is normal");
        }
        else{
            rhDescriptiontextView.setText("Your air is dry");
        }


        if (temp > 30){
            tempDescriptiontextView.setText("Your air temperature is very hot");
        }
        else if (temp >25){
            tempDescriptiontextView.setText("Your air temperature is hot");
        }
        else if (temp > 20){
            tempDescriptiontextView.setText("Your air temperature is normal");
        }
        else{
            tempDescriptiontextView.setText("Your air temperature is low");
        }

    }

    protected void makeLinkClickable(SpannableStringBuilder strBuilder, final URLSpan span)     //support for setTextViewHTML()
    {
        int start = strBuilder.getSpanStart(span);
        int end = strBuilder.getSpanEnd(span);
        int flags = strBuilder.getSpanFlags(span);
        ClickableSpan clickable = new ClickableSpan() {
            public void onClick(View view) {
                // Do something with span.getURL() to handle the link click...
                Uri webaddress = Uri.parse(span.getURL());

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        };
        strBuilder.setSpan(clickable, start, end, flags);
        strBuilder.removeSpan(span);
    }

    protected void setTextViewHTML(TextView text, String html)      //used to set a textview where some words are hyperlinks
    {
        CharSequence sequence = Html.fromHtml(html);
        SpannableStringBuilder strBuilder = new SpannableStringBuilder(sequence);
        URLSpan[] urls = strBuilder.getSpans(0, sequence.length(), URLSpan.class);
        for(URLSpan span : urls) {
            makeLinkClickable(strBuilder, span);
        }
        text.setText(strBuilder);
        text.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
