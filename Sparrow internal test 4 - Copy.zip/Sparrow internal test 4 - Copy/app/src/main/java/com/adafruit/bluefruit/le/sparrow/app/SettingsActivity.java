package com.adafruit.bluefruit.le.sparrow.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.R;
import com.adafruit.bluefruit.le.sparrow.app.settings.PreferencesFragment;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class SettingsActivity extends PreferenceActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //load settings fragment
        getFragmentManager().beginTransaction().replace(android.R.id.content, new SettingsPreferencesFragment()).commit();

    }

    public static class SettingsPreferencesFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.settings_activity_preferences);

            bindSummaryValue(findPreference("sensitivity mode"));
            bindSummaryValue(findPreference("customCOYellow"));
            bindSummaryValue(findPreference("customCORed"));
            bindSummaryValue(findPreference("customCOMaroon"));
            //bindSummaryValue(findPreference("log download"));
            bindSummaryValue(findPreference("CO concentration unit"));
            //bindSummaryValue(findPreference("O3 concentration unit"));
            bindSummaryValue(findPreference("temperature unit"));
            bindSummaryValue(findPreference("log rate"));
            bindSummaryValue(findPreference("plot type"));
        }
    }

    private static void bindSummaryValue(Preference preference){
        preference.setOnPreferenceChangeListener(listener);
        listener.onPreferenceChange(preference, PreferenceManager.getDefaultSharedPreferences(preference.getContext()).getString(preference.getKey(),""));

    }



    private static Preference.OnPreferenceChangeListener listener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object newValue) {





            String stringValue = newValue.toString();
            if (preference instanceof ListPreference){
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);
                //Set the summary to reflect the new value
                preference.setSummary(index >= 0 ? listPreference.getEntries()[index] : null);

            }
            else if (preference instanceof EditTextPreference){
                preference.setSummary(stringValue);
            }

            return true;
        }
    };




}
