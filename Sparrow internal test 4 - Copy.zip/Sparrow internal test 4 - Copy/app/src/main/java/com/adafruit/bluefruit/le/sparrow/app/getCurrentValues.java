package com.adafruit.bluefruit.le.sparrow.app;

import android.os.AsyncTask;

public class getCurrentValues extends AsyncTask<Void,Void,Void> {
    String currentCOppm, currentRH, currentTemp, COppmTWA15Minutes, COppmTWA8Hours, COppmTWA24Hours;

    @Override
    protected Void doInBackground(Void... voids) {

        currentCOppm = UartActivity.currentCOppm;
       currentRH = UartActivity.currentRH;
       currentTemp = UartActivity.currentTemp;
        COppmTWA15Minutes = UartActivity.TWA15Minutes+"";
        COppmTWA8Hours = UartActivity.TWA8Hours+"";
        COppmTWA24Hours = UartActivity.TWA24Hours+"";


        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);


        //UartActivity.apiCallValue = this.AQI;  //updates value in uartactivty
        LearnAboutCOActivity.currentCOppm = this.currentCOppm;
        LearnAboutCOActivity.currentRH = this.currentRH;
        LearnAboutCOActivity.currentTemp = this.currentTemp;
        LearnAboutCOActivity.COppmTWA15Minutes = this.COppmTWA15Minutes;
        LearnAboutCOActivity.COppmTWA8Hours = this.COppmTWA8Hours;
        LearnAboutCOActivity.COppmTWA24Hours = this.COppmTWA24Hours;


    }
}
