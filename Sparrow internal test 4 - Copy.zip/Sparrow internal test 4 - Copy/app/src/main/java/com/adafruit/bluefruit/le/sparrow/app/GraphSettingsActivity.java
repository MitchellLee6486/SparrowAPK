package com.adafruit.bluefruit.le.sparrow.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.R;

public class GraphSettingsActivity extends AppCompatActivity {

    private String resolution;
    private Button per1SecBtn, per10SecBtn, per1MinBtn, per10MinBtn, per1HourBtn, per1DayBtn, linePlotBtn, pointsPlotBtn;
    private int logRate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_settings);





        SharedPreferences sharedPrefLog = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String lograte = sharedPrefLog.getString("log rate","");

        if(lograte.equals("1 sec")){
            logRate = 1;
        }
        else if(lograte.equals("10 sec") || lograte.equals("")){

            logRate = 10;
        }
        else if (lograte.equals("1 min")){
            logRate = 60;
        }
        else if (lograte.equals("10 min")){
            logRate = 600;
        }
        else if (lograte.equals("1 hour")){
            logRate = 3600;
        }
        else if (lograte.equals("1 day")){
            logRate = 86400;
        }




        per1SecBtn = (Button) findViewById(R.id.per1SecBtn);
        per1SecBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(1 < logRate){
                    Toast.makeText(GraphSettingsActivity.this,"Resolution must be equal or greater than log rate",Toast.LENGTH_SHORT).show();
                }
                else {
                    SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("resolution", "1 sec");
                    editor.apply();
                    Toast.makeText(GraphSettingsActivity.this, "Resolution set", Toast.LENGTH_SHORT).show();

                    highlightButton("1 sec");
                }
            }
        });



        per10SecBtn = (Button) findViewById(R.id.per10SecBtn);
        per10SecBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(10 < logRate){
                    Toast.makeText(GraphSettingsActivity.this,"Resolution must be equal or greater than log rate",Toast.LENGTH_SHORT).show();
                }
                else {
                    SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("resolution", "10 sec");
                    editor.apply();
                    Toast.makeText(GraphSettingsActivity.this, "Resolution set", Toast.LENGTH_SHORT).show();

                    highlightButton("10 sec");
                }
            }
        });


        per1MinBtn = (Button) findViewById(R.id.per1MinBtn);
        per1MinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(60 < logRate){
                    Toast.makeText(GraphSettingsActivity.this,"Resolution must be equal or greater than log rate",Toast.LENGTH_SHORT).show();
                }
                else {
                    SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("resolution", "1 min");
                    editor.apply();
                    Toast.makeText(GraphSettingsActivity.this, "Resolution set", Toast.LENGTH_SHORT).show();

                    highlightButton("1 min");
                }
            }
        });

        per10MinBtn = (Button) findViewById(R.id.per10MinBtn);
        per10MinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(600 < logRate){
                    Toast.makeText(GraphSettingsActivity.this,"Resolution must be equal or greater than log rate",Toast.LENGTH_SHORT).show();
                }
                else {
                    SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("resolution", "10 min");
                    editor.apply();
                    Toast.makeText(GraphSettingsActivity.this, "Resolution set", Toast.LENGTH_SHORT).show();

                    highlightButton("10 min");
                }
            }
        });

        per1HourBtn = (Button) findViewById(R.id.per1HourBtn);
        per1HourBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(3600 < logRate){
                    Toast.makeText(GraphSettingsActivity.this,"Resolution must be equal or greater than log rate",Toast.LENGTH_SHORT).show();
                }
                else {
                    SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("resolution", "1 hour");
                    editor.apply();
                    Toast.makeText(GraphSettingsActivity.this, "Resolution set", Toast.LENGTH_SHORT).show();

                    highlightButton("1 hour");
                }
            }
        });

        per1DayBtn = (Button) findViewById(R.id.per1DayBtn);
        per1DayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(86400 < logRate){
                    Toast.makeText(GraphSettingsActivity.this,"Resolution must be equal or greater than log rate",Toast.LENGTH_SHORT).show();
                }
                else {
                    SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("resolution", "1 day");
                    editor.apply();
                    Toast.makeText(GraphSettingsActivity.this, "Resolution set", Toast.LENGTH_SHORT).show();

                    highlightButton("1 day");
                }
            }
        });

        linePlotBtn = (Button) findViewById(R.id.linePlotBtn);
        linePlotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("plot type", "line");
                editor.apply();
                Toast.makeText(GraphSettingsActivity.this, "Plot type set", Toast.LENGTH_SHORT).show();
            }
        });

        pointsPlotBtn = (Button) findViewById(R.id.pointsPlotBtn);
        pointsPlotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPref = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("plot type", "points");
                editor.apply();
                Toast.makeText(GraphSettingsActivity.this, "Plot type set", Toast.LENGTH_SHORT).show();
            }
        });


        SharedPreferences sharedPrefRes = getSharedPreferences("graph settings", Context.MODE_PRIVATE);
        resolution = sharedPrefRes.getString("resolution","");

        if (resolution.equals("")){

        }
        else if (resolution.equals("1 sec")){
            per1SecBtn.setTextColor(Color.rgb(0,255,0));
        }
        else if (resolution.equals("10 sec")){
            per10SecBtn.setTextColor(Color.rgb(0,255,0));
        }
        else if (resolution.equals("1 min")){
            per1MinBtn.setTextColor(Color.rgb(0,255,0));
        }
        else if (resolution.equals("10 min")){
            per10MinBtn.setTextColor(Color.rgb(0,255,0));
        }
        else if (resolution.equals("1 hour")){
            per1HourBtn.setTextColor(Color.rgb(0,255,0));
        }
        else if (resolution.equals("1 day")){
            per1DayBtn.setTextColor(Color.rgb(0,255,0));
        }



    }
    public void highlightButton (String res){
        if (res.equals("1 sec")){
            per1SecBtn.setTextColor(Color.rgb(0,255,0));
            per10SecBtn.setTextColor(Color.rgb(0,0,0));
            per1MinBtn.setTextColor(Color.rgb(0,0,0));
            per10MinBtn.setTextColor(Color.rgb(0,0,0));
            per1HourBtn.setTextColor(Color.rgb(0,0,0));
            per1DayBtn.setTextColor(Color.rgb(0,0,0));
        }
        else if (res.equals("10 sec")){
            per1SecBtn.setTextColor(Color.rgb(0,0,0));
            per10SecBtn.setTextColor(Color.rgb(0,255,0));
            per1MinBtn.setTextColor(Color.rgb(0,0,0));
            per10MinBtn.setTextColor(Color.rgb(0,0,0));
            per1HourBtn.setTextColor(Color.rgb(0,0,0));
            per1DayBtn.setTextColor(Color.rgb(0,0,0));
        }
        else if (res.equals("1 min")){
            per1SecBtn.setTextColor(Color.rgb(0,0,0));
            per10SecBtn.setTextColor(Color.rgb(0,0,0));
            per1MinBtn.setTextColor(Color.rgb(0,255,0));
            per10MinBtn.setTextColor(Color.rgb(0,0,0));
            per1HourBtn.setTextColor(Color.rgb(0,0,0));
            per1DayBtn.setTextColor(Color.rgb(0,0,0));
        }
        else if (res.equals("10 min")){
            per1SecBtn.setTextColor(Color.rgb(0,0,0));
            per10SecBtn.setTextColor(Color.rgb(0,0,0));
            per1MinBtn.setTextColor(Color.rgb(0,0,0));
            per10MinBtn.setTextColor(Color.rgb(0,255,0));
            per1HourBtn.setTextColor(Color.rgb(0,0,0));
            per1DayBtn.setTextColor(Color.rgb(0,0,0));
        }
        else if (res.equals("1 hour")){
            per1SecBtn.setTextColor(Color.rgb(0,0,0));
            per10SecBtn.setTextColor(Color.rgb(0,0,0));
            per1MinBtn.setTextColor(Color.rgb(0,0,0));
            per10MinBtn.setTextColor(Color.rgb(0,0,0));
            per1HourBtn.setTextColor(Color.rgb(0,255,0));
            per1DayBtn.setTextColor(Color.rgb(0,0,0));
        }
        else if (res.equals("1 day")){
            per1SecBtn.setTextColor(Color.rgb(0,0,0));
            per10SecBtn.setTextColor(Color.rgb(0,0,0));
            per1MinBtn.setTextColor(Color.rgb(0,0,0));
            per10MinBtn.setTextColor(Color.rgb(0,0,0));
            per1HourBtn.setTextColor(Color.rgb(0,0,0));
            per1DayBtn.setTextColor(Color.rgb(0,255,0));
        }
    }
}
