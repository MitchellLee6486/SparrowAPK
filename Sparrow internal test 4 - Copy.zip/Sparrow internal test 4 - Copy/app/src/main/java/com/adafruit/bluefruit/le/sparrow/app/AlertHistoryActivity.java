package com.adafruit.bluefruit.le.sparrow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class AlertHistoryActivity extends AppCompatActivity {

    private ListView alertList;
    private Button alertMapBtn;
    private ArrayList<String> alertArrayList;
    File myExternalFile;


    private static final String TAG = "AlertHistoryActivity";
    private static final int ERROR_DIALOG_REQUEST = 9001;



    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_alerts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        final int id = item.getItemId();

        switch (id) {

            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            case R.id.accountSettings:
                Intent accountSettingsIntent = new Intent(getApplicationContext(), AccountSettingsActivity.class);
                startActivity(accountSettingsIntent);
                break;

            case R.id.mySparrowSettings:
                Intent mySparrowSettingsIntent = new Intent(getApplicationContext(),MySparrowSettingsActivity.class);
                startActivity(mySparrowSettingsIntent);
                break;

            case R.id.preferencesSettings:
                //Intent preferencesIntent = new Intent(getApplicationContext(),PreferencesSettingsActivity.class);
                Intent preferencesIntent = new Intent(getApplicationContext(),SettingsActivity.class);
                startActivity(preferencesIntent);

                break;



            case R.id.clearAlertLog:
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(this);
                }
                builder.setTitle("Restart Sparrow Alerts?")
                        .setMessage("Restart alerts file to improve response time. All data points will be lost. We recommend sending yourself a copy of the log first through the share alert log feature. Are you sure you want to restart your Sparrow Alerts? ")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something
                                alertList.setAdapter(null);
                                restartAlertFile();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

                break;
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@



        }

        return super.onOptionsItemSelected(item);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_history);

        getSupportActionBar().setSubtitle(" Alerts");
        getSupportActionBar().setTitle(" SPARROW");
        getSupportActionBar().setLogo(R.mipmap.sparrow_icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(3);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavViewBar);

        Menu bottomMenu = bottomNavigationView.getMenu();
        MenuItem bottomMenuItem = bottomMenu.getItem(2);
        bottomMenuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.homeBarBtn:
                        Intent intent1 = new Intent(AlertHistoryActivity.this, UartActivity.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent1);
                        AlertHistoryActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.myDataBarBtn:
                        Intent intent2 = new Intent(AlertHistoryActivity.this    , GraphActivity.class);
                        intent2.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent2);
                        AlertHistoryActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.myAlertBarBtn:

                        break;

                    case R.id.learnMoreBarBtn:
                        Intent intent4 = new Intent(AlertHistoryActivity.this    , LearnAboutCOActivity.class);
                        intent4.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent4);
                        AlertHistoryActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;
                }



                return false;
            }
        });




        if (!isTaskRoot()   //used to resume, rather than restart, when clicking appp icon for galaxy 8, add to every activity except launcher
                && getIntent().hasCategory(Intent.CATEGORY_LAUNCHER)
                && getIntent().getAction() != null
                && getIntent().getAction().equals(Intent.ACTION_MAIN)) {

            finish();
            return;
        }


        if (isServicesOK()){
            init();
        }





        alertList = (ListView) findViewById(R.id.alertListView);



        alertArrayList = new ArrayList<String>();

        myExternalFile = new File(getExternalFilesDir("SparrowFolder"),"SparrowAlert.txt");


        long fileSize = myExternalFile.length();
        long fileSizemb = (fileSize/1024000);

        if(fileSizemb >= 25){
            Toast.makeText(AlertHistoryActivity.this,"Current alert file is "+fileSizemb+" mb. Can no longer send through email. Recommended to clear alert file.",Toast.LENGTH_LONG).show();

        }
        else if (fileSizemb >= 10){
            Toast.makeText(AlertHistoryActivity.this,"Current alert file is "+fileSizemb+" mb. Consider saving the log through email and clearing the alert file.",Toast.LENGTH_LONG).show();
        }
        else if (fileSizemb >= 5 ){     //include a warning indicating that larger data size will slow down in google map
            Toast.makeText(AlertHistoryActivity.this,"Current alert file is "+fileSizemb+" mb.",Toast.LENGTH_LONG).show();
        }


        try {
            FileInputStream fis = new FileInputStream(myExternalFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            while((strLine = br.readLine())!= null){
                alertArrayList.add(formatAlertString(strLine));
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        alertList.setAdapter(new ArrayAdapter<String>(this, R.layout.my_listview_detail, alertArrayList));

        alertList.setSelection(alertList.getAdapter().getCount()-1);

        alertList.setOnItemClickListener(new AdapterView.OnItemClickListener() { //click on a alert to open that specific alert in google map
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String item = adapterView.getItemAtPosition(i).toString();


                Intent intent = new Intent(AlertHistoryActivity.this, MapActivity.class);
                intent.putExtra("display", "single");
                intent.putExtra("alertData", item);
                startActivity(intent);
            }
        });

    }
    public String formatAlertString(String string){
        String formatted = "";
        String[] splitString = string.split(",");
        if (splitString.length == 8){
            String time = splitString[0].trim()+", "+splitString[1].trim();
            String coordinates = splitString[2].trim()+", "+splitString[3].trim();
            String address = splitString[4].trim()+", "+splitString[5].trim();
            String concentration = splitString[7].trim();
            formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;
        }
        else if (splitString.length == 9){
            String time = splitString[0].trim()+", "+splitString[1].trim();
            String coordinates = splitString[2].trim()+", "+splitString[3].trim();
            String address = splitString[4].trim()+", "+splitString[5].trim()+", "+splitString[6].trim();
            String concentration = splitString[8].trim();
            formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;
        }
        else if (splitString.length == 10){
            String time = splitString[0].trim()+", "+splitString[1].trim();
            String coordinates = splitString[2].trim()+", "+splitString[3].trim();
            String address = splitString[4].trim()+", "+splitString[5].trim()+", "+splitString[6].trim()+", "+splitString[7].trim();
            String concentration = splitString[9].trim();
            formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;
        }



        return formatted;
    }

    public boolean isServicesOK(){
        Log.d(TAG, "isServicesOK: checking google services version");

        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(AlertHistoryActivity.this);

        if(available == ConnectionResult.SUCCESS){
            Log.d(TAG, "isServicesOK: Google Play services is working");
            return true;
        }
        else if (GoogleApiAvailability.getInstance().isUserResolvableError(available)){
            Log.d(TAG, "isServicesOK: an error occured but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(AlertHistoryActivity.this, available, ERROR_DIALOG_REQUEST);
            dialog.show();
        }
        else{
            Toast.makeText(this, "You can't make map requests",Toast.LENGTH_SHORT).show();
        }
        return false;
    }
    private void init(){
        alertMapBtn = (Button) findViewById(R.id.alertMapBtn);
        alertMapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AlertHistoryActivity.this, MapActivity.class);
                intent.putExtra("display", "all");
                startActivity(intent);
            }
        });
    }

    public void restartAlertFile() {
        try {

            String filepath = "SparrowFolder";
            File file = new File(getExternalFilesDir(filepath), "SparrowAlert.txt");

            if (file.exists()) {

                if (file.delete()) {

                } else {

                }

            } else {

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        File myLogFile = new File(getExternalFilesDir("SparrowFolder"), "SparrowAlert.txt");
        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }



        /*try {       //check if file is empty
            FileInputStream fis = new FileInputStream(myLogFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            strLine = br.readLine();
            if(strLine == null){        //if empty, create header
                try {
                    FileOutputStream fos = new FileOutputStream(myLogFile, true);
                    String data = "Time, CO ppm, O3 ppb, °C, %RH, AQI \n";
                    fos.write(data.getBytes());
                    //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
                    fos.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}
