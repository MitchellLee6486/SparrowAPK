package com.adafruit.bluefruit.le.sparrow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.adafruit.bluefruit.le.sparrow.R;



public class MySparrowSettingsActivity extends AppCompatActivity {


    private String emailBody;
    private String filepath = "SparrowFolder";

    private Button shareLogBtn, shareAlertLogBtn, enableUSBBtn, restoreDefaultsBtn, zeroBtn, submitFeedbackBtn;
    private Button findAnswerBtn, buySparrowBtn, showAdvancedBtn;
    private TextView sparrowIDTextView, sensor1IDTextView, sensor2IDTextView, hwVersionTextView, fwVersionTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sparrow_settings);

        getSupportActionBar().setSubtitle(" My SPARROW");
        getSupportActionBar().setTitle(" SPARROW");
        getSupportActionBar().setLogo(R.mipmap.sparrow_icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(3);


        shareLogBtn = (Button) findViewById(R.id.shareLogBtn);
        shareLogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                File myLogFile = new File(getExternalFilesDir(filepath), "SparrowLog.txt");

                emailBody = "This is an email from the Sparrow App. Contains the text file that holds the sparrow log.";
                sendIntentToGmailApp(myLogFile);
            }
        });

        shareAlertLogBtn = (Button) findViewById(R.id.shareAlertLogBtn);
        shareAlertLogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File myAlertLogFile = new File(getExternalFilesDir(filepath), "SparrowAlert.txt");

                emailBody = "This is an email from the Sparrow App. Contains the text file that holds the sparrow alerts log.";
                sendIntentToGmailApp(myAlertLogFile);
            }
        });

        showAdvancedBtn = findViewById(R.id.showAdvancedBtn);
        showAdvancedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (showAdvancedBtn.getText().equals("Show Advanced Features")){
                    showAdvancedBtn.setText("Hide Advanced Features");
                    enableUSBBtn.setVisibility(View.VISIBLE);
                    restoreDefaultsBtn.setVisibility(View.VISIBLE);
                    zeroBtn.setVisibility(View.VISIBLE);
                }
                else if (showAdvancedBtn.getText().equals("Hide Advanced Features")){
                    showAdvancedBtn.setText("Show Advanced Features");
                    enableUSBBtn.setVisibility(View.GONE);
                    restoreDefaultsBtn.setVisibility(View.GONE);
                    zeroBtn.setVisibility(View.GONE);
                }
            }
        });

        enableUSBBtn = findViewById(R.id.enableUSBBtn);
        enableUSBBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(MySparrowSettingsActivity.this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(MySparrowSettingsActivity.this);
                }

                builder.setTitle("Enable USB on SPARROW Device")
                        .setMessage("Are you sure you want to enable USB communication on your SPARROW device?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something


                                SharedPreferences sharedPrefCommands = getSharedPreferences("commands", 0);
                                SharedPreferences.Editor editorCommands = sharedPrefCommands.edit();
                                editorCommands.putBoolean("enableUSB",true);
                                editorCommands.apply();

                                Intent intent1 = new Intent(MySparrowSettingsActivity.this, UartActivity.class);
                                intent1.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                startActivity(intent1);
                                MySparrowSettingsActivity.this.overridePendingTransition(0,0);
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });

        restoreDefaultsBtn = findViewById(R.id.restoreFactorydefaultsBtn);
        restoreDefaultsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(MySparrowSettingsActivity.this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(MySparrowSettingsActivity.this);
                }

                builder.setTitle("Restore SPARROW Device to Factory Settings")
                        .setMessage("Are you sure you want to restore your SPARROW device to its orignal factory settings? This will also delete all current log and event files. Some features require an app restart to take place.")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something


                                SharedPreferences sharedPrefCommands = getSharedPreferences("commands", 0);
                                SharedPreferences.Editor editorCommands = sharedPrefCommands.edit();
                                editorCommands.putBoolean("restoreDefault",true);
                                editorCommands.apply();

                                restartLogFile();
                                restartEventsFile();
                                restartAlertFile();

                                Intent intent1 = new Intent(MySparrowSettingsActivity.this, UartActivity.class);
                                intent1.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                startActivity(intent1);
                                MySparrowSettingsActivity.this.overridePendingTransition(0,0);
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });

        zeroBtn = findViewById(R.id.zeroCommandBtn);
        zeroBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(MySparrowSettingsActivity.this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(MySparrowSettingsActivity.this);
                }


                SharedPreferences sharedPrefZero = getSharedPreferences("dates", 0);
                String lastZero = sharedPrefZero.getString("time of last zero", "-");


                builder.setTitle("Zero Sparrow Sensors")
                        .setMessage("You should only zero your device when you start to see significant ppm readings even though you know you are in a clean air environment. Are you sure you want to zero your Sparrow's sensors? Only zero in the included refresh bag. Your last zero occured at "+lastZero)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something

                                SharedPreferences sharedPrefCommands = getSharedPreferences("commands", 0);
                                SharedPreferences.Editor editorCommands = sharedPrefCommands.edit();
                                editorCommands.putBoolean("zero",true);
                                editorCommands.apply();


                                Toast.makeText(getApplicationContext(), "Sensors zeroed", Toast.LENGTH_SHORT).show();

                                SharedPreferences sharedPrefZero = getSharedPreferences("dates",0);
                                SharedPreferences.Editor editorLastRecieve = sharedPrefZero.edit();
                                SimpleDateFormat s = new SimpleDateFormat("MMM dd, yyyy.");
                                String zeroDate = s.format(new Date());
                                editorLastRecieve.putString("time of last zero", zeroDate);
                                editorLastRecieve.apply();

                                Intent intent1 = new Intent(MySparrowSettingsActivity.this, UartActivity.class);
                                intent1.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                //intent1.putExtra("zeroCommand", true);
                                startActivity(intent1);
                                MySparrowSettingsActivity.this.overridePendingTransition(0,0);
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();


            }
        });

        enableUSBBtn.setVisibility(View.GONE);
        restoreDefaultsBtn.setVisibility(View.GONE);
        zeroBtn.setVisibility(View.GONE);


        sparrowIDTextView = findViewById(R.id.sparrowIDTextView);
        sparrowIDTextView.setText("SPARROW ID: "+MainActivity.sparrowID);

        sensor1IDTextView = findViewById(R.id.sensor1IDTextView);
        sensor1IDTextView.setText("CO Sensitivty Factor: "+UartActivity.sensor1ID+" pA per ppm");

        sensor2IDTextView = findViewById(R.id.sensor2IDTextView);
        sensor2IDTextView.setText("O3 Sensitivty Factor: "+UartActivity.sensor2ID+" pA per ppm");

        hwVersionTextView = findViewById(R.id.hwVersionTextView);
        hwVersionTextView.setText("Hardware Version: " + UartActivity.hwVersion);

        fwVersionTextView = findViewById(R.id.fwVersionTextView);
        fwVersionTextView.setText("Firmware Version: " + UartActivity.fwVersion);


        if(Build.VERSION.SDK_INT>=24){      //"hack method" to go around api 24+ requirements, may need to change, used for opening gmail
            try{
                Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                m.invoke(null);
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        buySparrowBtn = (Button) findViewById(R.id.buySparrowBtn);
        buySparrowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("http://sparrowsense.com/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        findAnswerBtn = (Button) findViewById(R.id.findAnswerBtn);
        findAnswerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webaddress = Uri.parse("http://sparrowsense.com/the-sparrow-app/faq/");

                Intent goToURL = new Intent(Intent.ACTION_VIEW, webaddress);
                if (goToURL.resolveActivity(getPackageManager()) !=  null){
                    startActivity(goToURL);
                }
            }
        });

        submitFeedbackBtn = findViewById(R.id.submitFeedbackBtn);
        submitFeedbackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendSupportemail();
            }
        });

    }

    private void sendIntentToGmailApp(File fileToSend) {
        if(fileToSend != null){
            Intent email = new Intent(Intent.ACTION_SEND);
            email.putExtra(Intent.EXTRA_SUBJECT, "Sparrow Log Sent Through Sparrow App");
            email.putExtra(Intent.EXTRA_TEXT, emailBody);
            email.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + fileToSend.getAbsoluteFile()));   //only works with android sdkversion < 24
            //email.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            //email.putExtra(Intent.EXTRA_STREAM, Uri.parse("content://" + fileToSend.getAbsoluteFile()));
            email.setType("message/rfc822");
            startActivity(Intent.createChooser(email , "Send Log File"));
        }
    }

    private void sendSupportemail() {

            Intent email = new Intent(Intent.ACTION_SEND);
            //email.putExtra(Intent.EXTRA_SUBJECT, "SPARROW App Support and Feedback");
            email.putExtra(Intent.EXTRA_EMAIL,new String[]{"android.support@kwjengineering.com"});

            email.setType("message/rfc822");
            startActivity(Intent.createChooser(email , "Send Feedback"));

    }

    public void restartLogFile() {
        try {

            String filepath = "SparrowFolder";
            File file = new File(getExternalFilesDir(filepath), "SparrowLog.txt");

            if (file.exists()) {

                if (file.delete()) {

                } else {

                }

            } else {

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        File myLogFile = new File(getExternalFilesDir("SparrowFolder"), "SparrowLog.txt");
        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }



        try {       //check if file is empty
            FileInputStream fis = new FileInputStream(myLogFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            strLine = br.readLine();
            if(strLine == null){        //if empty, create header
                try {
                    FileOutputStream fos = new FileOutputStream(myLogFile, true);
                    String data = "Time, CO ppm, O3 ppb, °C, %RH, AQI \n";
                    fos.write(data.getBytes());
                    //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
                    fos.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void restartEventsFile (){
        try {

            String filepath = "SparrowFolder";
            File file = new File(getExternalFilesDir(filepath), "SparrowEvents.txt");

            if (file.exists()) {

                if (file.delete()) {

                } else {

                }

            } else {

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        File myLogFile = new File(getExternalFilesDir("SparrowFolder"), "SparrowEvents.txt");
        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }

    public void restartAlertFile() {
        try {

            String filepath = "SparrowFolder";
            File file = new File(getExternalFilesDir(filepath), "SparrowAlert.txt");

            if (file.exists()) {

                if (file.delete()) {

                } else {

                }

            } else {

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        File myLogFile = new File(getExternalFilesDir("SparrowFolder"), "SparrowAlert.txt");
        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }



}
