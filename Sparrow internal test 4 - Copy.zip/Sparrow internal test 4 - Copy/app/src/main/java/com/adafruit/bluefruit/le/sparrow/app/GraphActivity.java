package com.adafruit.bluefruit.le.sparrow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.R;
import com.adafruit.bluefruit.le.sparrow.app.settings.MqttUartSettingsActivity;
import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.PointsGraphSeries;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class GraphActivity extends AppCompatActivity {

    private Button clearBtn,a1Plotbtn, cxPlotBtn,txPlotBtn, hxPlotBtn, vbPlotBtn, sessionOrLogBtn, dosageBtn;
    private Spinner eventsSpinner;
    private EditText startDate, endDate;
    private String startdateString, endDateString, startAxis, endAxis, fileName;
    private String resolutionText = "";
    private int COplotBtnCounts = 0, HXplotBtnCounts = 0, TXplotBtnCounts = 0;
    private ArrayList<String> logArray, logTimeFrameArray, eventsArray, eventsTimeArray, eventsDataArray;
    private long startDateValue, endDateValue;
    private int logRate, mod;
    private String lastPlottedItem = "";

    private String plotTypeSetting;

    File myExternalFile;

    GraphView graph;
    boolean isBound = false;
    double y,x;



    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_graph, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        final int id = item.getItemId();

        switch (id) {

            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            case R.id.accountSettings:
                Intent accountSettingsIntent = new Intent(getApplicationContext(), AccountSettingsActivity.class);
                startActivity(accountSettingsIntent);
                break;

            case R.id.mySparrowSettings:
                Intent mySparrowSettingsIntent = new Intent(getApplicationContext(),MySparrowSettingsActivity.class);
                startActivity(mySparrowSettingsIntent);
                break;

            case R.id.preferencesSettings:
                //Intent preferencesIntent = new Intent(getApplicationContext(),PreferencesSettingsActivity.class);
                Intent preferencesIntent = new Intent(getApplicationContext(),SettingsActivity.class);
                startActivity(preferencesIntent);

                break;


            case R.id.clearEvents:
                AlertDialog.Builder builder1;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder1 = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder1 = new AlertDialog.Builder(this);
                }
                builder1.setTitle("Clear Events?")
                        .setMessage("Clear events list?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something
                                eventsSpinner.setAdapter(null);
                                eventsArray.clear();
                                eventsArray.add("Events");
                                eventsTimeArray.clear();
                                eventsTimeArray.add("-");
                                eventsDataArray.clear();
                                ArrayAdapter<String> adaptor = new ArrayAdapter<String>(GraphActivity.this, R.layout.support_simple_spinner_dropdown_item, eventsArray);
                                adaptor.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                                eventsSpinner.setAdapter(adaptor);


                                graph.removeAllSeries();

                                graph.getViewport().setXAxisBoundsManual(true);
                                //graph.getViewport().setMinX(0.0);
                                //graph.getViewport().setMaxX(0.8);
                                graph.getGridLabelRenderer().setVerticalAxisTitle("Value");
                                startAxis = "-";
                                endAxis = "-";
                                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis+" to "+endAxis+resolutionText);
                                restartEventsFile();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

                break;

            case R.id.clearLogFile:
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(this);
                }
                builder.setTitle("Restart Sparrow Log?")
                        .setMessage("Restart log file to improve response time of plot. All data points will be lost. We recommend sending yourself a copy of the log first through the share log feature. Are you sure you want to restart your Sparrow Log? ")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something
                                logArray.clear();   //clear so that user cant plot the data that was deleted

                                graph.removeAllSeries();


                                graph.getViewport().setXAxisBoundsManual(true);
                                graph.getViewport().setMinX(0.0);
                                graph.getViewport().setMaxX(0.8);
                                graph.getGridLabelRenderer().setVerticalAxisTitle("Value");
                                startAxis = "-";
                                endAxis = "-";
                                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis+" to "+endAxis+resolutionText);
                                restartLogFile();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

                break;
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@



        }

        return super.onOptionsItemSelected(item);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);



        getSupportActionBar().setSubtitle(" My Data");
        getSupportActionBar().setTitle(" SPARROW");
        getSupportActionBar().setLogo(R.mipmap.sparrow_icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(3);


        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavViewBar);

        Menu bottomMenu = bottomNavigationView.getMenu();
        MenuItem bottomMenuItem = bottomMenu.getItem(1);
        bottomMenuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.homeBarBtn:

                        saveDates();

                        Intent intent1 = new Intent(GraphActivity.this, UartActivity.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent1);
                        GraphActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.myDataBarBtn:

                        break;

                    case R.id.myAlertBarBtn:

                        saveDates();

                        Intent intent3 = new Intent(GraphActivity.this    , AlertHistoryActivity.class);
                        intent3.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent3);
                        GraphActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;

                    case R.id.learnMoreBarBtn:

                        saveDates();

                        Intent intent4 = new Intent(GraphActivity.this    , LearnAboutCOActivity.class);
                        intent4.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent4);
                        GraphActivity.this.overridePendingTransition(0,0);
                        finish();
                        break;
                }



                return false;
            }
        });



        if (!isTaskRoot()   //used to resume, rather than restart, when clicking appp icon for galaxy 8, add to every activity except launcher
                && getIntent().hasCategory(Intent.CATEGORY_LAUNCHER)
                && getIntent().getAction() != null
                && getIntent().getAction().equals(Intent.ACTION_MAIN)) {

            finish();
            return;
        }


        fileName = "SparrowLog.txt";
        myExternalFile = new File(getExternalFilesDir("SparrowFolder"),fileName);
        long fileSize = myExternalFile.length();
        long fileSizemb = (fileSize/1024000);

        if(fileSizemb >= 25){
            Toast.makeText(GraphActivity.this,"Current log file is "+fileSizemb+" mb. Can no longer send through email. Recommended to clear log file.",Toast.LENGTH_LONG).show();

        }
        else if (fileSizemb >= 15){
            Toast.makeText(GraphActivity.this,"Current log file is "+fileSizemb+" mb. Consider saving the log through email and clearing the log file.",Toast.LENGTH_LONG).show();
        }
        else if (fileSizemb >= 5 ){
            Toast.makeText(GraphActivity.this,"Current log file is "+fileSizemb+" mb.",Toast.LENGTH_LONG).show();
        }


        loadLogFileThread();


        clearBtn = (Button) findViewById(R.id.startStopBtn);
        a1Plotbtn = (Button) findViewById(R.id.a1PlotBtn);
        cxPlotBtn = (Button) findViewById(R.id.cxPlotBtn);
        txPlotBtn = (Button) findViewById(R.id.txPlotBtn);
        hxPlotBtn = (Button) findViewById(R.id.hxPlotBtn);
        vbPlotBtn = (Button) findViewById(R.id.vbPlotBtn);
        sessionOrLogBtn = (Button) findViewById(R.id.sessionOrLogBtn);
        dosageBtn = (Button) findViewById(R.id.dosageBtn);
        eventsSpinner = (Spinner) findViewById(R.id.eventsSpinner);

        loadEvents();


        startDate = (EditText) findViewById(R.id.startDateEditText);
        endDate = (EditText) findViewById(R.id.endDateEditText);
        startDate.setVisibility(View.INVISIBLE);
        endDate.setVisibility(View.INVISIBLE);

        if (UartActivity.hwVersion.equals("3")){
            cxPlotBtn.setVisibility(View.VISIBLE);
        }

        SharedPreferences sharedPref = getSharedPreferences("Dates", Context.MODE_PRIVATE);

        String startDate1 = sharedPref.getString("startDate","");
        String endDate1 = sharedPref.getString("endDate","");

        startDate.setText(startDate1);
        endDate.setText(endDate1);


        loadLogSettings();

        loadResolutionSettings();


        graph = (GraphView) findViewById(R.id.graph);
        graph.setTitle("");
        startAxis = "-";
        endAxis = "-";
        graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis+" to "+endAxis+resolutionText);
        graph.getGridLabelRenderer().setVerticalAxisTitle("Value");

        //graph.getGridLabelRenderer().setLabelHorizontalHeight(60);
        //graph.getGridLabelRenderer().setTextSize(30);


        final SimpleDateFormat s2 = new SimpleDateFormat( "MMM dd\nhh:mm:ss");
        graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
            @Override
            public String formatLabel(double value, boolean isValueX){
                if(isValueX){
                    return s2.format(new Date((long)value));
                }else{
                    return super.formatLabel(value, isValueX);
                }
            }
        });



        graph.getGridLabelRenderer().setNumHorizontalLabels(3);
        //graph.getViewport().setScalable(true);
        //graph.getGridLabelRenderer().setLabelHorizontalHeight(40);
        //graph.getGridLabelRenderer().setHorizontalAxisTitleTextSize(48);


        a1Plotbtn.setTextColor(Color.rgb(255,0,0));
        a1Plotbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*x = 0.0;
                LineGraphSeries<DataPoint> series;
                series = new LineGraphSeries<DataPoint>();
                series.setColor(Color.rgb(255,0,0));*/


                startdateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();

            COplotBtnCounts++;
            if (COplotBtnCounts % 2 ==0){   //even number
                //remove data from plot

            }
            else{   //odd number
                //plot the data
            }


                if (sessionOrLogBtn.getText().toString().equals("Past Hour")) {
                    graphPreviousHourThread(1);
                    /*if (getIntent().hasExtra("a1Data")) {

                        ArrayList txList = getIntent().getExtras().getStringArrayList("a1Data");
                        int size = txList.size();
                        for (int i = 0; i < size; i++) {
                            x = x + 1;
                            String[] txArray = txList.get(i).toString().split(" ");
                            double tx = Double.parseDouble(txArray[0]);
                            y = tx;
                            series.appendData(new DataPoint(x, y), true, size);
                        }

                        graph.getViewport().setXAxisBoundsManual(true);
                        graph.getViewport().setMinX(0.0);
                        graph.getViewport().setMaxX(x);
                        graph.getGridLabelRenderer().setVerticalAxisTitle("ADC Counts");

                        graph.getViewport().setScalable(true);

                        //graph.removeAllSeries();
                        graph.addSeries(series);
                    }*/
                }

                if (sessionOrLogBtn.getText().toString().equals("Past Day")){
                    graphPreviousDayThread(1);
                }

                if (sessionOrLogBtn.getText().toString().equals("Specific Time")){


                    long testStartValue = getDateValue(startdateString);    //works
                    //int startindex = getStartIndex(testStartValue);

                    long testEndValue = getDateValue(endDateString);    //works
                    //int endindex = getEndIndex(testEndValue, startindex);

                    //graphFromLogDatesVersion(startindex, endindex,1);
                    graphFromLogDatesVersionThread(testStartValue,testEndValue,1);

                    /*for (int i = startindex; i<endindex;i++){
                        logTimeFrameArray.add(logArray.get(i));
                    }

                    for (int i =0; i<logTimeFrameArray.size();i++){
                        String logTimeFrameString = logTimeFrameArray.get(i);
                        String[] logTimeFrameStringArray = logTimeFrameString.split(",");
                        String adcCounts = logTimeFrameStringArray[1].trim();


                        double counts = Double.parseDouble(adcCounts);
                        x = x +1;
                        y = counts;
                        series.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());

                    }
                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(0.0);
                    double maxX = (double)endindex - (double)startindex;
                    graph.getViewport().setMaxX(maxX);
                    graph.getGridLabelRenderer().setVerticalAxisTitle("ADC Counts");    //change for adc

                    graph.getViewport().setScalable(true);

                    graph.addSeries(series);
                    logTimeFrameArray.clear();*/
                }
            }
        });


        cxPlotBtn.setTextColor(Color.rgb(128,128,0));
        cxPlotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startdateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();

                if (sessionOrLogBtn.getText().toString().equals("Past Hour")) {
                    graphPreviousHourThread(2);
                }

                if (sessionOrLogBtn.getText().toString().equals("Past Day")){
                    graphPreviousDayThread(2);
                }

                if (sessionOrLogBtn.getText().toString().equals("Specific Time")){

                    long testStartValue = getDateValue(startdateString);    //works
                    //int startindex = getStartIndex(testStartValue);

                    long testEndValue = getDateValue(endDateString);    //works
                    //int endindex = getEndIndex(testEndValue,startindex);

                    //graphFromLogDatesVersion(startindex,endindex,2);
                    graphFromLogDatesVersionThread(testStartValue,testEndValue,2);
                }
            }
        });


        txPlotBtn.setTextColor(Color.rgb(0,255,0));
        txPlotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startdateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();

                if (sessionOrLogBtn.getText().toString().equals("Past Hour")) {
                    graphPreviousHourThread(3);
                }

                if (sessionOrLogBtn.getText().toString().equals("Past Day")){
                    graphPreviousDayThread(3);
                }

                if (sessionOrLogBtn.getText().toString().equals("Specific Time")){

                    long testStartValue = getDateValue(startdateString);    //works
                    //int startindex = getStartIndex(testStartValue);

                    long testEndValue = getDateValue(endDateString);    //works
                    //int endindex = getEndIndex(testEndValue,startindex);

                    //graphFromLogDatesVersion(startindex, endindex, 3);
                    graphFromLogDatesVersionThread(testStartValue,testEndValue,3);

                }
            }
        });


        hxPlotBtn.setTextColor(Color.rgb(0,128,128));
        hxPlotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startdateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();

                if (sessionOrLogBtn.getText().toString().equals("Past Hour")) {
                    graphPreviousHourThread(4);
                }

                if (sessionOrLogBtn.getText().toString().equals("Past Day")){
                    graphPreviousDayThread(4);
                }

                if (sessionOrLogBtn.getText().toString().equals("Specific Time")){

                    long testStartValue = getDateValue(startdateString);    //works
                    //int startindex = getStartIndex(testStartValue);

                    long testEndValue = getDateValue(endDateString);    //works
                    //int endindex = getEndIndex(testEndValue,startindex);

                    //graphFromLogDatesVersion(startindex, endindex,4);
                    graphFromLogDatesVersionThread(testStartValue,testEndValue,4);
                }
            }
        });





        vbPlotBtn.setTextColor(Color.rgb(128,0,128));       //changed from battery voltage to AQI
        vbPlotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startdateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();

                if (sessionOrLogBtn.getText().toString().equals("Past Hour")) {

                    graphPreviousHourThread(5);       //dataToGraph changed from 6 to 5 because removed kpa values
                }

                if (sessionOrLogBtn.getText().toString().equals("Past Day")){
                    graphPreviousDayThread(5);        //dataToGraph changed from 6 to 5 because removed kpa values
                }

                if (sessionOrLogBtn.getText().toString().equals("Specific Time")){

                    long testStartValue = getDateValue(startdateString);    //works
                    //int startindex = getStartIndex(testStartValue);

                    long testEndValue = getDateValue(endDateString);    //works
                    //int endindex = getEndIndex(testEndValue,startindex);

                    //graphFromLogDatesVersion(startindex,endindex,5);        //dataToGraph changed from 6 to 5 because removed kpa values
                    graphFromLogDatesVersionThread(testStartValue,testEndValue,5);

                }

            }
        });


        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                graph.removeAllSeries();
                lastPlottedItem = "";


                /*graph.getViewport().setXAxisBoundsManual(true);
                graph.getViewport().setMinX(0.0);
                graph.getViewport().setMaxX(0.8);
                graph.getGridLabelRenderer().setVerticalAxisTitle("Value");
                startAxis = "-";
                endAxis = "-";
                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis+" to "+endAxis+resolutionText);*/

            }
        });

        sessionOrLogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                startdateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();

                if (sessionOrLogBtn.getText().toString().equals("Past Hour") ){    //only changes if dates are provided
                    sessionOrLogBtn.setText("Past Day");


                    /*long testStartValue = getDateValue(startdateString);    //works
                    int startindex = getStartIndex(testStartValue);
                    hxPlotBtn.setText(startindex+"");

                    long testEndValue = getDateValue(endDateString);    //works
                    int endindex = getEndIndex(testEndValue);
                    vbPlotBtn.setText(endindex+"");

                    for (int i = startindex; i<endindex;i++){
                        logTimeFrameArray.add(logArray.get(i));
                    }*/


                }
                else if (sessionOrLogBtn.getText().toString().equals("Past Day")){
                    sessionOrLogBtn.setText("Specific Time");

                    startDate.setVisibility(View.VISIBLE);
                    endDate.setVisibility(View.VISIBLE);
                }
                else if (sessionOrLogBtn.getText().toString().equals("Specific Time")){
                    sessionOrLogBtn.setText("Past Hour");

                    startDate.setVisibility(View.INVISIBLE);
                    endDate.setVisibility(View.INVISIBLE);

                    logTimeFrameArray.clear();
                }



            }
        });



        dosageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {




                int startIndex = 0;
                int endIndex = 1;

                long currentTimeValue = 0;
                long previousHourValue = 1;

                if (sessionOrLogBtn.getText().equals("Past Hour")){
                    SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
                    String currentTime = s.format(new Date());
                    try {
                        Date date = s.parse(currentTime);

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        calendar.add(Calendar.HOUR, -1);
                        String previousHourAsString = s.format(calendar.getTime());
                        currentTimeValue = getDateValue(currentTime);
                        previousHourValue = getDateValue(previousHourAsString);

                        //startIndex = getStartIndex(previousHourValue);
                        //endIndex = getEndIndex(currentTimeValue,startIndex);




                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                }
                else if (sessionOrLogBtn.getText().equals("Past Day")){
                    SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
                    String currentTime = s.format(new Date());
                    try {
                        Date date = s.parse(currentTime);

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        calendar.add(Calendar.DATE, -1);
                        String previousDateAsString = s.format(calendar.getTime());
                        currentTimeValue = getDateValue(currentTime);
                        previousHourValue = getDateValue(previousDateAsString);
                        //startIndex = getStartIndex(previousHourValue);
                        //endIndex = getEndIndex(currentTimeValue,startIndex);

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
                else if (sessionOrLogBtn.getText().equals("Specific Time")){
                    startdateString = startDate.getText().toString();
                    endDateString = endDate.getText().toString();

                    currentTimeValue = getDateValue(endDateString);    //works
                    //startIndex = getStartIndex(currentTimeValue);

                    previousHourValue = getDateValue(startdateString);    //works
                    //endIndex = getEndIndex(previousHourValue,startIndex);
                }

                calculateDosageThread(previousHourValue,currentTimeValue);


                /*String[] Dosage = calculateDosage(startIndex, endIndex);
                String startTime = Dosage[0].substring(0,19);
                String startTimeUSA = convertToUSATimeFormat(startTime);
                String endTime = Dosage[1].substring(0, 19);
                String endTimeUSA = convertToUSATimeFormat(endTime);
                String COppmHours = Dosage[2];
                String O3ppbHours = Dosage[3];



                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(GraphActivity.this, android.R.style.Theme_Material_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(GraphActivity.this);
                }
                builder.setTitle("Your Dosage")
                        .setMessage("Your dosage from "+startTimeUSA+ " to "+endTimeUSA+ " is "+COppmHours+" and "+O3ppbHours)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do something


                            }
                        })

                        //.setIcon(android.R.drawable.ic_dialog_alert)
                        .show();*/


            }
        });


    }


    public void loadLogFile (){
        fileName = "SparrowLog.txt";


        myExternalFile = new File(getExternalFilesDir("SparrowFolder"),fileName);
        logArray = new ArrayList<String>();
        logTimeFrameArray = new ArrayList<String>();

        try {



            FileInputStream fis = new FileInputStream(myExternalFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            while((strLine = br.readLine())!= null){
                logArray.add(strLine);
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadLogFileThread(){

        final ProgressDialog nDialog;
        nDialog = new ProgressDialog(GraphActivity.this);
        nDialog.setMessage("Loading..");
        nDialog.setTitle("Reading Log File");
        nDialog.setIndeterminate(false);
        nDialog.setCancelable(true);
        nDialog.show();

        Thread t = new Thread(){     //thread version
            @Override
            public void run(){


                fileName = "SparrowLog.txt";
                myExternalFile = new File(getExternalFilesDir("SparrowFolder"),fileName);


                logArray = new ArrayList<String>();
                logTimeFrameArray = new ArrayList<String>();

                try {



                    FileInputStream fis = new FileInputStream(myExternalFile);
                    DataInputStream in = new DataInputStream(fis);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));

                    String strLine;
                    while((strLine = br.readLine())!= null){
                        logArray.add(strLine);
                    }
                    in.close();

                    nDialog.dismiss();


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        };
        t.start();

    }


    public void graphPreviousHour (int dataToGraph){

        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        String currentTime = s.format(new Date());
        try {
            Date date = s.parse(currentTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.HOUR, -1);
            String previousHourAsString = s.format(calendar.getTime());
            long currentTimeValue = getDateValue(currentTime);
            long previousHourValue = getDateValue(previousHourAsString);
            int startIndex = getStartIndex(previousHourValue);
            int endIndex = getEndIndex(currentTimeValue,startIndex);

            graphFromLogDatesVersion(startIndex+1, endIndex, dataToGraph);      //@@@@@@@@@@@@@@@@@@@@@@@@@

        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    public void graphPreviousHourThread (final int dataToGraph){
        final ProgressDialog nDialog;
        nDialog = new ProgressDialog(GraphActivity.this);
        nDialog.setMessage("Loading..");
        nDialog.setTitle("Adding Data Points");
        nDialog.setIndeterminate(false);
        nDialog.setCancelable(true);
        nDialog.show();

        Thread t = new Thread(){
            @Override
            public void run(){
                graphPreviousHour(dataToGraph);

                nDialog.dismiss();
            }
        };
        t.start();
    }

    public void graphPreviousDay (int dataToGraph){

        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        String currentTime = s.format(new Date());
        try {
            Date date = s.parse(currentTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DATE, -1);
            String previousDateAsString = s.format(calendar.getTime());
            long currentTimeValue = getDateValue(currentTime);
            long previousHourValue = getDateValue(previousDateAsString);
            int startIndex = getStartIndex(previousHourValue);
            int endIndex = getEndIndex(currentTimeValue,startIndex);
            graphFromLogDatesVersion(startIndex+1,endIndex,dataToGraph);        //@@@@@@@@@@@@@@@@@@@@change back to regular if needed
        } catch (ParseException e) {
            e.printStackTrace();
        }


        /*SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        String currentTime = s.format(new Date());
        long currentTimeValue = getDateValue(currentTime);
        long previousHourValue = currentTimeValue - 1000000;
        int startIndex = getStartIndex(previousHourValue);
        int endIndex = getEndIndex(currentTimeValue);
        graphFromLog(startIndex,endIndex,dataToGraph);*/
    }

    public void graphPreviousDayThread (final int dataToGraph){
        final ProgressDialog nDialog;
        nDialog = new ProgressDialog(GraphActivity.this);
        nDialog.setMessage("Loading..");
        nDialog.setTitle("Adding Data Points");
        nDialog.setIndeterminate(false);
        //nDialog.setCancelable(true);
        nDialog.setCancelable(false);
        nDialog.show();

        Thread t = new Thread() {
            @Override
            public void run() {
                graphPreviousDay(dataToGraph);

                nDialog.dismiss();
            }
        };
        t.start();
    }

    public void graphFromLog (int startIndex, int endIndex, int dataToGraph){

        if(plotTypeSetting.equals("line")){
            x = -1.0;
            LineGraphSeries<DataPoint> series;
            series = new LineGraphSeries<DataPoint>();
            if (dataToGraph == 1){
                series.setColor(Color.rgb(255,0,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("CO ppm");    //change for adc

            }
            else if (dataToGraph == 2){
                series.setColor(Color.rgb(128,128,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("O3 ppb");        //set for ppm
            }
            else if (dataToGraph == 3){
                series.setColor(Color.rgb(0,255,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("Temperature C");        //set for temperature
            }
            else if (dataToGraph == 4){
                series.setColor(Color.rgb(0,128,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("%RH");        //set for %RH
            }
            else if (dataToGraph == 5){
                series.setColor(Color.rgb(128,0,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("AQI");        //set for AQI
            /*series.setColor(Color.rgb(0,0,255));
            graph.getGridLabelRenderer().setVerticalAxisTitle("Kpa");        //set for kPa*/
            }
       /* else if (dataToGraph == 6){
            series.setColor(Color.rgb(128,0,128));
            graph.getGridLabelRenderer().setVerticalAxisTitle("AQI");        //set for AQI
        }*/


            for (int i = startIndex; i<endIndex;i++){
                if (i % mod == 0) { //only records per resultion set
                    logTimeFrameArray.add(logArray.get(i));
                }
            }
            if(logTimeFrameArray.size() >= 1) {
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                String logTimeFrameString2 = logTimeFrameArray.get(0);
                String[] logTimeFrameStringArray2 = logTimeFrameString2.split(",");
                String startTime = logTimeFrameStringArray2[0].trim();
                startAxis = startTime.substring(5, 19);

                String logTimeFrameString3 = logTimeFrameArray.get(logTimeFrameArray.size() - 1);
                String[] logTimeFrameStringArray3 = logTimeFrameString3.split(",");
                String endTime = logTimeFrameStringArray3[0].trim();
                endAxis = endTime.substring(5, 19);

                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis + " to " + endAxis + resolutionText);
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                for (int i = 0; i < logTimeFrameArray.size(); i++) {

                    String logTimeFrameString = logTimeFrameArray.get(i);
                    String[] logTimeFrameStringArray = logTimeFrameString.split(",");


                    String data = logTimeFrameStringArray[dataToGraph].trim();   //obtain the specified data to graph
                    double dataValue = Double.parseDouble(data);
                    x = x + 1;
                    y = dataValue;
                    series.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());

                }

                graph.getViewport().setXAxisBoundsManual(true);
                graph.getViewport().setMinX(0.0);
                //double maxX = (double)endindex - (double)startindex;
                graph.getViewport().setMaxX(x);

                graph.getGridLabelRenderer().setNumHorizontalLabels(3);


                //graph.getGridLabelRenderer().setLabelHorizontalHeight(40);
                //graph.getGridLabelRenderer().setHorizontalAxisTitleTextSize(48);

                graph.getViewport().setScalable(true);

                graph.addSeries(series);
                logTimeFrameArray.clear();
            }
        }
        else if (plotTypeSetting.equals("points")){
            x = -1.0;
            PointsGraphSeries<DataPoint> series;
            series = new PointsGraphSeries<DataPoint>();
            series.setSize(4);
            if (dataToGraph == 1){
                series.setColor(Color.rgb(255,0,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("CO ppm");    //change for adc

            }
            else if (dataToGraph == 2){
                series.setColor(Color.rgb(128,128,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("O3 ppb");        //set for ppm
            }
            else if (dataToGraph == 3){
                series.setColor(Color.rgb(0,255,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("Temperature C");        //set for temperature
            }
            else if (dataToGraph == 4){
                series.setColor(Color.rgb(0,128,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("%RH");        //set for %RH
            }
            else if (dataToGraph == 5){
                series.setColor(Color.rgb(128,0,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("AQI");        //set for AQI
            /*series.setColor(Color.rgb(0,0,255));
            graph.getGridLabelRenderer().setVerticalAxisTitle("Kpa");        //set for kPa*/
            }
       /* else if (dataToGraph == 6){
            series.setColor(Color.rgb(128,0,128));
            graph.getGridLabelRenderer().setVerticalAxisTitle("AQI");        //set for AQI
        }*/


            for (int i = startIndex; i<endIndex;i++){
                if (i % mod == 0) { //only records per resultion set
                    logTimeFrameArray.add(logArray.get(i));
                }
            }
            if(logTimeFrameArray.size() >= 1) {
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                String logTimeFrameString2 = logTimeFrameArray.get(0);
                String[] logTimeFrameStringArray2 = logTimeFrameString2.split(",");
                String startTime = logTimeFrameStringArray2[0].trim();
                startAxis = startTime.substring(5, 19);

                String logTimeFrameString3 = logTimeFrameArray.get(logTimeFrameArray.size() - 1);
                String[] logTimeFrameStringArray3 = logTimeFrameString3.split(",");
                String endTime = logTimeFrameStringArray3[0].trim();
                endAxis = endTime.substring(5, 19);

                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis + " to " + endAxis + resolutionText);
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                for (int i = 0; i < logTimeFrameArray.size(); i++) {

                    String logTimeFrameString = logTimeFrameArray.get(i);
                    String[] logTimeFrameStringArray = logTimeFrameString.split(",");


                    String data = logTimeFrameStringArray[dataToGraph].trim();   //obtain the specified data to graph
                    double dataValue = Double.parseDouble(data);
                    x = x + 1;
                    y = dataValue;
                    series.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());

                }

                graph.getViewport().setXAxisBoundsManual(true);
                graph.getViewport().setMinX(0.0);
                //double maxX = (double)endindex - (double)startindex;
                graph.getViewport().setMaxX(x);

                graph.getGridLabelRenderer().setNumHorizontalLabels(3);


                //graph.getGridLabelRenderer().setLabelHorizontalHeight(40);
                //graph.getGridLabelRenderer().setHorizontalAxisTitleTextSize(48);

                graph.getViewport().setScalable(true);

                graph.addSeries(series);
                logTimeFrameArray.clear();
            }
        }


    }



    public void graphFromLogDatesVersion (int startIndex, int endIndex, int dataToGraph){



        final SimpleDateFormat s = new SimpleDateFormat( "yyyy:MM:dd:HH:mm:ss");
        if (plotTypeSetting.equals("line")){
            LineGraphSeries<DataPoint> lineSeries;
            lineSeries = new LineGraphSeries<>();

            if (dataToGraph == 1){
                lineSeries.setColor(Color.rgb(255,0,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("CO ppm");    //change for CO
                lastPlottedItem = "CO";
            }
            else if (dataToGraph == 2){
                lineSeries.setColor(Color.rgb(128,128,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("O3 ppb");        //set for O3
                lastPlottedItem = "O3";
            }
            else if (dataToGraph == 3){
                lineSeries.setColor(Color.rgb(0,255,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("Temperature C");        //set for temperature
                lastPlottedItem = "Temp";
            }
            else if (dataToGraph == 4){
                lineSeries.setColor(Color.rgb(0,128,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("%RH");        //set for %RH
                lastPlottedItem = "RH";
            }
            else if (dataToGraph == 5){

                lineSeries.setColor(Color.rgb(128,0,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("AQI");        //set for AQI
                lastPlottedItem = "AQI";
            }



            for (int i = startIndex; i<endIndex;i++){

                    logTimeFrameArray.add(logArray.get(i));

            }

            if(logTimeFrameArray.size() >= 1) {
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                String logTimeFrameString2 = logTimeFrameArray.get(0);
                String[] logTimeFrameStringArray2 = logTimeFrameString2.split(",");
                String startTime = logTimeFrameStringArray2[0].trim();
                startAxis = convertToUSATimeFormat(startTime);

                String logTimeFrameString3 = logTimeFrameArray.get(logTimeFrameArray.size() - 1);
                String[] logTimeFrameStringArray3 = logTimeFrameString3.split(",");
                String endTime = logTimeFrameStringArray3[0].trim();
                endAxis = convertToUSATimeFormat(endTime);

                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis + " to " + endAxis + resolutionText);
                //graph.getGridLabelRenderer().setLabelHorizontalHeight(30);
                //graph.getGridLabelRenderer().setTextSize(30);
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


                for (int i =0; i<logTimeFrameArray.size();i++){
                    //include actual graphing code here
                    String logTimeFrameString = logTimeFrameArray.get(i);
                    String[] logTimeFrameStringArray = logTimeFrameString.split(",");
                    String timeString = logTimeFrameStringArray[0].trim();
                    try {
                        Date mDate = s.parse(timeString);
                        long timeInMillis = mDate.getTime();


                        String voltage = logTimeFrameStringArray[dataToGraph].trim();
                        double counts = Double.parseDouble(voltage);
                        x = (double) timeInMillis;

                        if(i == 0){
                            graph.getViewport().setMinX(x);
                        }

                        if(i == logTimeFrameArray.size()-1){
                            graph.getViewport().setMaxX(x);
                        }

                        y = counts;
                        //series.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());     //need to add some type of exception when trying to add points not in order
                        try{
                            lineSeries.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());     //need to add some type of exception when trying to add points not in order
                        }catch (Exception e){

                        }


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }


                }
            }

            graph.addSeries(lineSeries);


            //graph.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(this));
            final SimpleDateFormat s2 = new SimpleDateFormat( "MMM dd\nhh:mm:ss");
            graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
                @Override
                public String formatLabel(double value, boolean isValueX){
                    if(isValueX){
                        return s2.format(new Date((long)value));
                    }else{
                        return super.formatLabel(value, isValueX);
                    }
                }
            });
            graph.getGridLabelRenderer().setNumHorizontalLabels(3);
            //graph.getGridLabelRenderer().setHumanRounding(false);

            graph.getViewport().setScalable(true);


            logTimeFrameArray.clear();
        }
        else if (plotTypeSetting.equals("points")){
            PointsGraphSeries<DataPoint> pointSeries;
            pointSeries = new PointsGraphSeries<>();
            pointSeries.setSize(4);

            if (dataToGraph == 1){
                pointSeries.setColor(Color.rgb(255,0,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("CO ppm");    //change for CO
                lastPlottedItem = "CO";
            }
            else if (dataToGraph == 2){
                pointSeries.setColor(Color.rgb(128,128,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("O3 ppb");        //set for O3
                lastPlottedItem = "O3";
            }
            else if (dataToGraph == 3){
                pointSeries.setColor(Color.rgb(0,255,0));
                graph.getGridLabelRenderer().setVerticalAxisTitle("Temperature C");        //set for temperature
                lastPlottedItem = "Temp";
            }
            else if (dataToGraph == 4){
                pointSeries.setColor(Color.rgb(0,128,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("%RH");        //set for %RH
                lastPlottedItem = "RH";
            }
            else if (dataToGraph == 5){

                pointSeries.setColor(Color.rgb(128,0,128));
                graph.getGridLabelRenderer().setVerticalAxisTitle("AQI");        //set for AQI
                lastPlottedItem = "AQI";
            }



            for (int i = startIndex; i<endIndex;i++){

                    logTimeFrameArray.add(logArray.get(i));

            }

            if(logTimeFrameArray.size() >= 1) {
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                String logTimeFrameString2 = logTimeFrameArray.get(0);
                String[] logTimeFrameStringArray2 = logTimeFrameString2.split(",");
                String startTime = logTimeFrameStringArray2[0].trim();
                //startAxis = startTime.substring(5, 19);
                startAxis = convertToUSATimeFormat(startTime);

                String logTimeFrameString3 = logTimeFrameArray.get(logTimeFrameArray.size() - 1);
                String[] logTimeFrameStringArray3 = logTimeFrameString3.split(",");
                String endTime = logTimeFrameStringArray3[0].trim();
                //endAxis = endTime.substring(5, 19);
                endAxis = convertToUSATimeFormat(endTime);

                graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis + " to " + endAxis + resolutionText);
                //graph.getGridLabelRenderer().setLabelHorizontalHeight(30);
                //graph.getGridLabelRenderer().setTextSize(30);
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


                for (int i =0; i<logTimeFrameArray.size();i++){
                    //include actual graphing code here
                    String logTimeFrameString = logTimeFrameArray.get(i);
                    String[] logTimeFrameStringArray = logTimeFrameString.split(",");
                    String timeString = logTimeFrameStringArray[0].trim();
                    try {
                        Date mDate = s.parse(timeString);
                        long timeInMillis = mDate.getTime();


                        String voltage = logTimeFrameStringArray[dataToGraph].trim();
                        double counts = Double.parseDouble(voltage);
                        x = (double) timeInMillis;
                        y = counts;


                        if(i == 0){
                            graph.getViewport().setMinX(x);
                        }

                        if(i == logTimeFrameArray.size()-1){
                            graph.getViewport().setMaxX(x);
                        }


                        //series.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());
                        try{
                            pointSeries.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());     //need to add some type of exception when trying to add points not in order
                        }catch (Exception e){

                        }


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }


                }
            }

            graph.addSeries(pointSeries);


            //graph.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(this));
            final SimpleDateFormat s2 = new SimpleDateFormat( "MMM dd\nhh:mm:ss");
            graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
                @Override
                public String formatLabel(double value, boolean isValueX){
                    if(isValueX){
                        return s2.format(new Date((long)value));
                    }else{
                        return super.formatLabel(value, isValueX);
                    }
                }
            });
            graph.getGridLabelRenderer().setNumHorizontalLabels(3);
            //graph.getGridLabelRenderer().setHumanRounding(false);

            graph.getViewport().setScalable(true);
            //graph.getViewport().setScalableY(true);//testing

            logTimeFrameArray.clear();
        }



    }


    public void graphFromLogDatesVersionThread(final long startDateValues, final long endDateValues, final int dataToGraph){
        final ProgressDialog nDialog;
        nDialog = new ProgressDialog(GraphActivity.this);
        nDialog.setMessage("Loading..");
        nDialog.setTitle("Adding Data Points");
        nDialog.setIndeterminate(false);
        nDialog.setCancelable(true);
        nDialog.show();

        Thread t = new Thread() {
            @Override
            public void run() {

                int startIndex1 = getStartIndex(startDateValues);
                int endIndex1 = getEndIndex(endDateValues,startIndex1);

                graphFromLogDatesVersion(startIndex1,endIndex1, dataToGraph);

                nDialog.dismiss();
            }

        };
        t.start();
    }


    public long getDateValue (String text){     //remove last three chars from standard format input text
        long dateValue = 0;
        String[] textArray = text.split(":");
        String year = textArray[0].trim();
        String month = textArray[1].trim();
        String day = textArray[2].trim();
        String hour = textArray[3].trim();
        String minutes = textArray[4].trim();
        String seconds = textArray[5].trim();
        //String[] secondsArray = seconds.split("."); //crash occurs here
        //String second = secondsArray[0].trim();
        //String millis = secondsArray[1].trim();
        String dateValueString = year+month+day+hour+minutes+seconds;
        dateValue = Long.parseLong(dateValueString);

        return dateValue;
    }

    public double getEventYValue (int eventIndex){   //used so that plotting event will not plot directly on x-axis, shifting zoom of the graph

        //use getStartIndex to find closest data point
        //based on lastItemPlotted, parse the correct value from that data point
        //Return the value which is the Y value to be plotted

        double YValue = 0.0;


        String eventDataString = eventsDataArray.get(eventIndex);
        String[] eventStringArray = eventDataString.split(", ");

        if (lastPlottedItem.equals("")){
            //nothing was recently plotted so just plot on x-axis
        }
        else if (lastPlottedItem.equals("CO")){
            YValue = Double.parseDouble(eventStringArray[0]);
        }
        else if (lastPlottedItem.equals("O3")){
            YValue = Double.parseDouble(eventStringArray[1]);
        }
        else if (lastPlottedItem.equals("Temp")){
            YValue = Double.parseDouble(eventStringArray[2]);
        }
        else if (lastPlottedItem.equals("RH")){
            YValue = Double.parseDouble(eventStringArray[3]);
        }
        else if (lastPlottedItem.equals("AQI")){
            YValue = Double.parseDouble(eventStringArray[4]);
        }

        return YValue;
    }



    public int getStartIndex (long startDate){

        int startIndex = 1;     //skip header line in log file
        for (int i = 1; i < logArray.size()-3;i++){
            String first = logArray.get(i);
            String[] firstArray = first.split(",");
            String firstDate = firstArray[0];
            String firstDateFormatted = firstDate.substring(0,19);  //removes milliseconds
            long firstDateValue = getDateValue(firstDateFormatted);

            String third = logArray.get(i+2);
            String[] thirdArray = third.split(",");
            String thirdDate = thirdArray[0];
            String thirdDateFormatted = thirdDate.substring(0,19);  //removes milliseconds
            long thirdDateValue = getDateValue(thirdDateFormatted);

            if (startDate > firstDateValue && startDate < thirdDateValue){
                startIndex = i+1;
                break;
            }
        }
        return startIndex;
    }

    public int getStartIndexThread (final long startDateValue){
        final int[] startIndex = {0};
        Thread t = new Thread() {
            @Override
            public void run() {
                startIndex[0] = getStartIndex(startDateValue);
            }
        };
        t.start();

        return startIndex[0];
    }

    public int getEndIndex (long endDate, int startIndex){

        int endIndex = logArray.size()-1;
        for (int i = startIndex; i < logArray.size()-3;i++){
            String first = logArray.get(i);
            String[] firstArray = first.split(",");
            String firstDate = firstArray[0];
            String firstDateFormatted = firstDate.substring(0,19);  //removes milliseconds
            long firstDateValue = getDateValue(firstDateFormatted);

            String third = logArray.get(i+2);
            String[] thirdArray = third.split(",");
            String thirdDate = thirdArray[0];
            String thirdDateFormatted = thirdDate.substring(0,19);  //removes milliseconds
            long thirdDateValue = getDateValue(thirdDateFormatted);

            if (endDate > firstDateValue && endDate < thirdDateValue){
                endIndex = i+1;

            }
        }
        return endIndex;
    }

    public int getEndIndexThread (final long endDateValue, final int startIndex){
        final int[] endIndex = {0};
        Thread t = new Thread() {
            @Override
            public void run() {
                endIndex[0] = getEndIndex(endDateValue, startIndex);
            }
        };
        t.start();

        return endIndex[0];
    }

    @Override
    public void onBackPressed(){
        SharedPreferences sharedPref = getSharedPreferences("Dates",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        startdateString = startDate.getText().toString();
        endDateString = endDate.getText().toString();
        editor.putString("startDate", startdateString);
        editor.putString("endDate", endDateString);
        editor.apply();

        super.onBackPressed();
    }

    @Override
    public void onResume(){
        super.onResume();

        loadResolutionSettings();

        startAxis = "-";
        endAxis = "-";
        graph.getGridLabelRenderer().setHorizontalAxisTitle(startAxis+" to "+endAxis+resolutionText);
        //graph.removeAllSeries();
    }

    public void loadResolutionSettings (){
        SharedPreferences sharedPrefGraph = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String resolution = sharedPrefGraph.getString("resolution","");
        plotTypeSetting = sharedPrefGraph.getString("plot type", "line");

        if(resolution.equals("1 sec")|| resolution.equals("")){
            //resolutionText = " per 1 sec";
            //mod = 1/logRate;
        }
        else if(resolution.equals("10 sec") ){
            //resolutionText = " per 10 sec";
            //mod = 10/logRate;
        }
        else if (resolution.equals("1 min")){
            //resolutionText = " per 1 min";
            //mod = 60/logRate;
        }
        else if (resolution.equals("10 min")){
            //resolutionText = " per 10 min";
            //mod = 600/logRate;
        }
        else if (resolution.equals("1 hour")){
            //resolutionText = " per 1 hour";
            //mod = 3600/logRate;
        }
        else if (resolution.equals("1 day")){
            //resolutionText = " per 1 day";
            //mod = 86400/logRate;
        }
    }

    public void loadLogSettings(){
        SharedPreferences sharedPrefDefault = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String lograte = sharedPrefDefault.getString("log rate","");

        if(lograte.equals("1 sec")|| lograte.equals("")){
            logRate = 1;
        }
        else if(lograte.equals("10 sec") ){

            logRate = 10;
        }
        else if (lograte.equals("1 min")){
            logRate = 60;
        }
        else if (lograte.equals("10 min")){
            logRate = 600;
        }
        else if (lograte.equals("1 hour")){
            logRate = 3600;
        }
        else if (lograte.equals("1 day")){
            logRate = 86400;
        }
    }

    public void restartLogFile() {
        try {

            String filepath = "SparrowFolder";
            File file = new File(getExternalFilesDir(filepath), "SparrowLog.txt");

            if (file.exists()) {

                if (file.delete()) {

                } else {

                }

            } else {

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        File myLogFile = new File(getExternalFilesDir("SparrowFolder"), "SparrowLog.txt");
        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }



        try {       //check if file is empty
            FileInputStream fis = new FileInputStream(myLogFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            strLine = br.readLine();
            if(strLine == null){        //if empty, create header
                try {
                    FileOutputStream fos = new FileOutputStream(myLogFile, true);
                    String data = "Time, CO ppm, O3 ppb, °C, %RH, AQI \n";
                    fos.write(data.getBytes());
                    //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
                    fos.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void restartEventsFile (){
        try {

            String filepath = "SparrowFolder";
            File file = new File(getExternalFilesDir(filepath), "SparrowEvents.txt");

            if (file.exists()) {

                if (file.delete()) {

                } else {

                }

            } else {

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        File myLogFile = new File(getExternalFilesDir("SparrowFolder"), "SparrowEvents.txt");
        try {   //create file if does not exist
            FileOutputStream fos = new FileOutputStream(myLogFile, true);
            String data = "";
            fos.write(data.getBytes());
            //Toast.makeText(this,"Saved to "+ getFilesDir()+"/SparrowFolder/SparrowLog.txt",Toast.LENGTH_SHORT).show();
            fos.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }

    public void saveDates (){
        SharedPreferences sharedPref = getSharedPreferences("Dates",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        startdateString = startDate.getText().toString();
        endDateString = endDate.getText().toString();
        editor.putString("startDate", startdateString);
        editor.putString("endDate", endDateString);
        editor.apply();
    }

    public String[] calculateDosage (int startIndex, int endIndex){     //assumed sparrrowlograte of 1.3 secs, not reliable
        String[] dosage = new String[4];
        final SimpleDateFormat s = new SimpleDateFormat( "yyyy:MM:dd:HH:mm:ss");

        for (int i = startIndex; i<endIndex;i++){

            logTimeFrameArray.add(logArray.get(i));

        }

        if(logTimeFrameArray.size() >= 1) {
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            String logTimeFrameString2 = logTimeFrameArray.get(0);
            String[] logTimeFrameStringArray2 = logTimeFrameString2.split(",");
            String startTime = logTimeFrameStringArray2[0].trim();
            dosage[0] = startTime;

            String logTimeFrameString3 = logTimeFrameArray.get(logTimeFrameArray.size() - 1);
            String[] logTimeFrameStringArray3 = logTimeFrameString3.split(",");
            String endTime = logTimeFrameStringArray3[0].trim();
            dosage[1] = endTime;


            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

            double COppmSeconds = 0.0;
            double O3ppbSeconds = 0.0;
            double sparrowLogRate = 1.321;
            for (int i =0; i<logTimeFrameArray.size();i++){
                //include actual graphing code here
                String logTimeFrameString = logTimeFrameArray.get(i);
                String[] logTimeFrameStringArray = logTimeFrameString.split(",");

                String COppm = logTimeFrameStringArray[1].trim();
                double COppmDouble = Double.parseDouble(COppm);
                COppmSeconds = COppmSeconds + COppmDouble*sparrowLogRate;

                String O3ppb = logTimeFrameStringArray[2].trim();
                int O3ppbInt = Integer.parseInt(O3ppb);
                O3ppbSeconds = O3ppbSeconds + O3ppbInt*sparrowLogRate;
            }

            double COppmHours = COppmSeconds/3600;
            String COppmHoursFormatted = COppmHours+"";
            if (COppmHoursFormatted.length()>6){
                COppmHoursFormatted = COppmHoursFormatted.substring(0,6);
            }
            dosage[2] = COppmHoursFormatted+" ppm hours CO";

            double O3ppbHours = O3ppbSeconds/3600;
            String O3ppbHoursFormatted = O3ppbHours+"";
            if (O3ppbHoursFormatted.length()>6){
                O3ppbHoursFormatted = O3ppbHoursFormatted.substring(0,6);
            }
            dosage[3] = O3ppbHoursFormatted+" ppb hours O3";

        }
        logTimeFrameArray.clear();
        return dosage;
    }

    public String[] calculateDosage2 (int startIndex, int endIndex){    //used if sparrow app is not logging at the correct rate of once every 1.32 seconds
        String[] dosage = new String[4];
        final SimpleDateFormat s = new SimpleDateFormat( "yyyy:MM:dd:HH:mm:ss");

        for (int i = startIndex; i<endIndex;i++){

            logTimeFrameArray.add(logArray.get(i));

        }

        if(logTimeFrameArray.size() >= 1) {
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            String logTimeFrameString2 = logTimeFrameArray.get(0);
            String[] logTimeFrameStringArray2 = logTimeFrameString2.split(",");
            String startTime = logTimeFrameStringArray2[0].trim();
            dosage[0] = startTime;

            String logTimeFrameString3 = logTimeFrameArray.get(logTimeFrameArray.size() - 1);
            String[] logTimeFrameStringArray3 = logTimeFrameString3.split(",");
            String endTime = logTimeFrameStringArray3[0].trim();
            dosage[1] = endTime;


            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

            double COppmSeconds = 0.0;
            double O3ppbSeconds = 0.0;
            double sparrowLogRate = 1.321;
            for (int i =0; i<logTimeFrameArray.size();i++){
                //include actual graphing code here
                String logTimeFrameString = logTimeFrameArray.get(i);
                String[] logTimeFrameStringArray = logTimeFrameString.split(",");

                String COppm = logTimeFrameStringArray[1].trim();
                double COppmDouble = Double.parseDouble(COppm);
                COppmSeconds = COppmSeconds + COppmDouble;

                String O3ppb = logTimeFrameStringArray[2].trim();
                int O3ppbInt = Integer.parseInt(O3ppb);
                O3ppbSeconds = O3ppbSeconds + O3ppbInt;
            }

            double averageCOppm = COppmSeconds/logTimeFrameArray.size();
            double averageO3ppb = O3ppbSeconds/logTimeFrameArray.size();
            String startingTime = logTimeFrameArray.get(0).substring(0,19);
            String endingTime = logTimeFrameArray.get(logTimeFrameArray.size()-1).substring(0,19);
            long startingTimeMillis = getMilliseconds(startingTime);
            long endingTimeMillis = getMilliseconds(endingTime);
            long runtimeSeconds = (endingTimeMillis - startingTimeMillis)/1000;

            COppmSeconds = runtimeSeconds*averageCOppm;
            O3ppbSeconds = runtimeSeconds*averageO3ppb;


            double COppmHours = COppmSeconds/3600;
            String COppmHoursFormatted = COppmHours+"";
            if (COppmHoursFormatted.length()>6){
                COppmHoursFormatted = COppmHoursFormatted.substring(0,6);
            }
            dosage[2] = COppmHoursFormatted+" ppm hours CO";

            double O3ppbHours = O3ppbSeconds/3600;
            String O3ppbHoursFormatted = O3ppbHours+"";
            if (O3ppbHoursFormatted.length()>6){
                O3ppbHoursFormatted = O3ppbHoursFormatted.substring(0,6);
            }
            dosage[3] = O3ppbHoursFormatted+" ppb hours O3";

        }
        logTimeFrameArray.clear();
        return dosage;
    }

    public void calculateDosageThread (final long startIndexValue, final long endIndexValue){
        final String[][] dosage = {new String[4]};


        final ProgressDialog nDialog;
        nDialog = new ProgressDialog(GraphActivity.this);
        nDialog.setMessage("Loading..");
        nDialog.setTitle("Calculating Exposure");
        nDialog.setIndeterminate(false);
        nDialog.setCancelable(true);
        nDialog.show();



        Thread t = new Thread() {     //thread version
            @Override
            public void run() {
                int startIndex = getStartIndex(startIndexValue);
                int endIndex = getEndIndex(endIndexValue,startIndex);

                dosage[0] = calculateDosage2(startIndex,endIndex);

                String startTime = dosage[0][0].substring(0,19);
                final String startTimeUSA = convertToUSATimeFormat(startTime);
                String endTime = dosage[0][1].substring(0, 19);
                final String endTimeUSA = convertToUSATimeFormat(endTime);
                final String COppmHours = dosage[0][2];
                final String O3ppbHours = dosage[0][3];

                nDialog.dismiss();

                Handler mHandler = new Handler(Looper.getMainLooper());
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        // Your UI updates here
                        AlertDialog.Builder builder;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            builder = new AlertDialog.Builder(GraphActivity.this, android.R.style.Theme_Material_Dialog_Alert);
                        } else {
                            builder = new AlertDialog.Builder(GraphActivity.this);
                        }
                        builder.setTitle("Your Exposure")
                                .setMessage("Your exposure from "+ startTimeUSA + " to "+ endTimeUSA + " is "+ COppmHours)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // do something


                                    }
                                })

                                //.setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                    }
                });


            }

        };
        t.start();


    }

    public void loadEvents (){
        eventsArray = new ArrayList<String>();
        eventsTimeArray = new ArrayList<String>();
        eventsDataArray = new ArrayList<String>();
        eventsArray.add("Events");
        eventsTimeArray.add("-");
        eventsDataArray.add("-");

        myExternalFile = new File(getExternalFilesDir("SparrowFolder"),"SparrowEvents.txt");

        try {
            FileInputStream fis = new FileInputStream(myExternalFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            while((strLine = br.readLine())!= null){
                eventsArray.add(formatEventsString(strLine));
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> adaptor = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, eventsArray);
        adaptor.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        eventsSpinner.setAdapter(adaptor);

        eventsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //plot event time occurance
                if (i != 0){    //do not count defualt "Events" value
                    Toast.makeText(GraphActivity.this, "Event marked at "+convertToUSATimeFormat(eventsTimeArray.get(i)), Toast.LENGTH_LONG).show();
                    PointsGraphSeries<DataPoint> series;
                    series = new PointsGraphSeries<>();
                    series.setSize(12);

                    final SimpleDateFormat s = new SimpleDateFormat( "yyyy:MM:dd:HH:mm:ss");
                    String timeString = eventsTimeArray.get(i);

                    try {
                        Date mDate = s.parse(timeString);
                        long timeInMillis = mDate.getTime();

                        x = (double) timeInMillis;
                        //y = 0.0;   //may be changed
                        y = getEventYValue(i);
                        //series.appendData(new DataPoint(x, y), true, logTimeFrameArray.size());     //need to add some type of exception when trying to add points not in order
                        try{
                            series.appendData(new DataPoint(x, y), true, 1);     //need to add some type of exception when trying to add points not in order
                        }catch (Exception e){

                        }


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    graph.addSeries(series);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public String formatEventsString (String textFileInput){
        String[] input = textFileInput.split("~");

        String eventTime = input[0].trim();
        eventsTimeArray.add(eventTime);

        String eventName = input[1].trim();

        String Data = input[2].trim()+", "+input[3].trim()+", "+input[4].trim()+", "+input[5].trim()+", "+input[6].trim();
        eventsDataArray.add(Data);
        return eventName;
    }

    public String convertToUSATimeFormat(String standardFormat){
        String USAFormat = "";

        SimpleDateFormat standardDateFormat = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        try {
            Date standardDate = standardDateFormat.parse(standardFormat);
            SimpleDateFormat USADateFormat = new SimpleDateFormat("MMM dd, hh:mm:ss");
            USAFormat = USADateFormat.format(standardDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }


        return USAFormat;
    }
    public long getMilliseconds (String dateTimeFormat){
        SimpleDateFormat s = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        long timeInMillis = 0;
        try{
            Date mDate = s.parse(dateTimeFormat);
            timeInMillis = mDate.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return timeInMillis;
    }

}