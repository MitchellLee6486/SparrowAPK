package com.adafruit.bluefruit.le.sparrow.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.adafruit.bluefruit.le.sparrow.Manifest;
import com.adafruit.bluefruit.le.sparrow.R;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback{




    private static final String TAG = "MapActivity";

    private static final String FINE_LOCATION = android.Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = android.Manifest.permission.ACCESS_COARSE_LOCATION;

    private boolean mLocationPermissionGranted = false;
    private static final int LOCATION_REQUEST_CODE = 1234;
    private GoogleMap mMap;
    private LatLng location;

    File myExternalFile;
    private ArrayList<String> alertArrayList;

    private String sensitivityModeSetting;
    private int moderateCO = 15;
    private int unhealthyCO = 35;
    private int hazardousCO = 70;

    private int moderateO3 = 75;
    private int unhealthyO3 = 96;
    private int hazardousO3 = 400;

    private int moderateAQI = 50;
    private int unhealthyAQI = 150;
    private int hazardousAQI = 250;




    @Override
    public void onMapReady(GoogleMap googleMap) {
        //Toast.makeText(this, "Map is ready", Toast.LENGTH_SHORT).show();
        mMap = googleMap;
        //location = new LatLng(37.51631, -122.045);
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        //mMap.addMarker(new MarkerOptions().position(location).title("Marker in Newark2"));

        String displayType = "";
        Intent i = getIntent();
        if (i.hasExtra("display")){
            displayType = i.getStringExtra("display");
        }

        if (displayType.equals("all") || displayType.equals("")){
            plotLocations();
        }
        else if (displayType.equals("single")){
            plotSingleAlert();

        }
        //plotLocations();
    }



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        getSupportActionBar().setSubtitle(" Map View");
        getSupportActionBar().setTitle(" SPARROW");
        getSupportActionBar().setLogo(R.mipmap.sparrow_icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(3);

        getLocationPermission();


        myExternalFile = new File(getExternalFilesDir("SparrowFolder"),"SparrowAlert.txt");

        alertArrayList = new ArrayList<String>();


        try {
            FileInputStream fis = new FileInputStream(myExternalFile);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine;
            while((strLine = br.readLine())!= null){
                alertArrayList.add(formatAlertString(strLine));
            }
            in.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void initMap(){
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(MapActivity.this);
    }



    private void getLocationPermission(){

        String[] permissions = {android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(),COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionGranted = true;
                initMap();
            }
            else{
                ActivityCompat.requestPermissions(this,permissions,LOCATION_REQUEST_CODE);
            }
        }
        else{
            ActivityCompat.requestPermissions(this, permissions, LOCATION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mLocationPermissionGranted = false;

        switch(requestCode){
            case LOCATION_REQUEST_CODE:{
                if(grantResults.length > 0){
                    for(int i = 0; i < grantResults.length;i++){
                        if(grantResults[i] != PackageManager.PERMISSION_GRANTED){
                            mLocationPermissionGranted = false;
                            return;
                        }
                    }
                    mLocationPermissionGranted = true;
                    // initialize map
                    initMap();
                }
            }
        }
    }

    public String formatAlertString2(String string){
        String formatted = "";
        String[] splitString = string.split(",");
        String time = splitString[0].trim()+", "+splitString[1].trim();
        String coordinates = splitString[2].trim()+", "+splitString[3].trim();
        String address = splitString[4].trim()+", "+splitString[5].trim()+", "+splitString[6].trim();
        String concentration = splitString[8].trim();
        formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;


        return formatted;
    }

    public String formatAlertString(String string){
        String formatted = "";
        String[] splitString = string.split(",");
        if (splitString.length == 8){
            String time = splitString[0].trim()+", "+splitString[1].trim();
            String coordinates = splitString[2].trim()+", "+splitString[3].trim();
            String address = splitString[4].trim()+", "+splitString[5].trim();
            String concentration = splitString[7].trim();
            formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;
        }
        else if (splitString.length == 9){
            String time = splitString[0].trim()+", "+splitString[1].trim();
            String coordinates = splitString[2].trim()+", "+splitString[3].trim();
            String address = splitString[4].trim()+", "+splitString[5].trim()+", "+splitString[6].trim();
            String concentration = splitString[8].trim();
            formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;
        }
        else if (splitString.length == 10){
            String time = splitString[0].trim()+", "+splitString[1].trim();
            String coordinates = splitString[2].trim()+", "+splitString[3].trim();
            String address = splitString[4].trim()+", "+splitString[5].trim()+", "+splitString[6].trim()+", "+splitString[7].trim();
            String concentration = splitString[9].trim();
            formatted = time+"\n"+coordinates+"\n"+address+"\n"+concentration;
        }



        return formatted;
    }

    public void plotSingleAlert(){
        Intent i = getIntent();
        String alertData = i.getStringExtra("alertData");
        String[] alertDataArray = alertData.split("\n");
        String time = alertDataArray[0];
        String coords = alertDataArray[1];
        String concentration = alertDataArray[3];

        String[] concentrationArray = concentration.split(" ");
        String concentrationValue = concentrationArray[2];

        String[] coordsArray = coords.split(", ");
        String latString = coordsArray[0].trim();
        String longString = coordsArray[1].trim();
        double lat = Double.parseDouble(latString);
        double lng = Double.parseDouble(longString);

        location = new LatLng(lat, lng);


        mMap.moveCamera(CameraUpdateFactory.newLatLng(location));

        loadSensitivitySettings();
        int concentrationCOInt = Integer.parseInt(concentrationValue);
        if (concentrationCOInt > hazardousCO){
            mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        }
        else if (concentrationCOInt > unhealthyCO){
            mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        }
        else if (concentrationCOInt > moderateCO){
            mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        }
        else{
            mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        }



        CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);
        mMap.animateCamera(zoom);

    }

    public void plotLocations (){

        int numberOfMarkers = 10000;
        int startIndex = alertArrayList.size()-numberOfMarkers;

        if (alertArrayList.size()<numberOfMarkers) {        //less than maximum limit so just add all markers
            for (int i = 0; i < alertArrayList.size(); i++) {
                String currentAlert = alertArrayList.get(i);
                String[] currentAlertArray = currentAlert.split("\n");
                String coordinate = currentAlertArray[1].trim();
                String[] coordsArray = coordinate.split(", ");
                String latString = coordsArray[0].trim();
                String longString = coordsArray[1].trim();
                double lat = Double.parseDouble(latString);
                double lng = Double.parseDouble(longString);

                location = new LatLng(lat, lng);

                String time = currentAlertArray[0];
                String concentration = currentAlertArray[3];

                String[] concentrationArray = concentration.split(" ");

                if (concentrationArray.length < 3){
                    Toast.makeText(MapActivity.this, i+"",Toast.LENGTH_LONG).show();
                }

                String concentrationValue = concentrationArray[2];

                mMap.moveCamera(CameraUpdateFactory.newLatLng(location));

                loadSensitivitySettings();
                int concentrationCOInt = Integer.parseInt(concentrationValue);
                if (concentrationCOInt > hazardousCO){
                    mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                }
                else if (concentrationCOInt > unhealthyCO){
                    mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
                }
                else if (concentrationCOInt > moderateCO){
                    mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
                }
                else{
                    mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
                }

                CameraUpdate zoom = CameraUpdateFactory.zoomTo(12);
                mMap.animateCamera(zoom);
            }
        }
        else if (alertArrayList.size()>numberOfMarkers){        //greater than limit so only add the most recent markers
            for (int i = startIndex; i < alertArrayList.size(); i++) {
                String currentAlert = alertArrayList.get(i);
                String[] currentAlertArray = currentAlert.split("\n");
                String coordinate = currentAlertArray[1].trim();
                String[] coordsArray = coordinate.split(", ");
                String latString = coordsArray[0].trim();
                String longString = coordsArray[1].trim();
                double lat = Double.parseDouble(latString);
                double lng = Double.parseDouble(longString);

                location = new LatLng(lat, lng);

                String time = currentAlertArray[0];
                String concentration = currentAlertArray[3];

                mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
                mMap.addMarker(new MarkerOptions().position(location).title(time + ", " + concentration));

                CameraUpdate zoom = CameraUpdateFactory.zoomTo(12);
                mMap.animateCamera(zoom);
            }
        }
    }

    public void loadSensitivitySettings(){
        SharedPreferences sharedPrefDefault = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        sensitivityModeSetting = sharedPrefDefault.getString("sensitivity mode","");
        if (sensitivityModeSetting.equals("very sensitive")){
            moderateCO = 5;
            unhealthyCO = 9;
            hazardousCO = 15;

            moderateO3 = 25;
            unhealthyO3 = 50;
            hazardousO3 = 100;

            moderateAQI = 20;
            unhealthyAQI = 50;
            hazardousAQI = 100;
        }
        else if (sensitivityModeSetting.equals("sensitive")){
            moderateCO = 9;
            unhealthyCO = 15;
            hazardousCO = 25;

            moderateO3 = 50;
            unhealthyO3 = 75;
            hazardousO3 = 200;

            moderateAQI = 30;
            unhealthyAQI = 80;
            hazardousAQI = 150;
        }
        else if (sensitivityModeSetting.equals("normal") || sensitivityModeSetting.equals("")){
            moderateCO = 15;
            unhealthyCO = 35;
            hazardousCO = 70;

            moderateO3 = 75;
            unhealthyO3 = 96;
            hazardousO3 = 400;

            moderateAQI = 50;
            unhealthyAQI = 150;
            hazardousAQI = 250;
        }
        else if (sensitivityModeSetting.equals("home alert")){
            moderateCO = 30;
            unhealthyCO = 70;
            hazardousCO = 150;

            moderateO3 = 150;
            unhealthyO3 = 200;
            hazardousO3 = 800;

            moderateAQI = 100;
            unhealthyAQI = 300;
            hazardousAQI = 500;
        }
        else if (sensitivityModeSetting.equals("custom")){

            String yellowEditText = sharedPrefDefault.getString("customCOYellow","15");
            String redEditText = sharedPrefDefault.getString("customCORed","35");
            String maroonEditText = sharedPrefDefault.getString("customCOMaroon","70");


            try {
                moderateCO = Integer.parseInt(yellowEditText);
                unhealthyCO = Integer.parseInt(redEditText);
                hazardousCO = Integer.parseInt(maroonEditText);
            }catch (NumberFormatException e){
                moderateCO = 15;
                unhealthyCO = 35;
                hazardousCO = 70;
            }

            if (moderateCO > 50){
                moderateCO = 50;
            }
            if(unhealthyCO > 200){
                unhealthyCO = 200;
            }
            if(hazardousCO > 400){
                hazardousCO = 400;
            }


        }
    }

}
